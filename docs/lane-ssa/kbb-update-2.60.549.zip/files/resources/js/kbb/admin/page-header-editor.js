/**
 * Pages → Page header: the "Edit header" panel on a custom page, and the same
 * controls for the console screen. (Lane PH)
 *
 * The owner: "i must be able to edit the inner page header from the
 * front-end, like super sale page."
 *
 * NEVER FETCHED FOR A SHOPPER. storefront-admin.js imports this only when an
 * admin who holds pageheader.manage presses "Edit header"; the console imports
 * it only on Pages → Page header. Nothing here runs on page load.
 *
 * RULES THIS FILE KEEPS (the same ones storefront-admin.js keeps)
 *  - Every word from a setting or the server is written with textContent or
 *    setAttribute, never innerHTML.
 *  - A picture address is used only if safeSrc() passes it; the server checks
 *    it again with SafeUrl::src() before it is stored or printed.
 *  - Live preview is the page's own header, redrawn by compile() -- the same
 *    function as PageHeaders::compile() -- from data the page already has.
 *    No request until Save. Nothing measures an element.
 *  - Every listener added to the document is removed when the panel closes.
 *  - (Lane SP3) The header area and the strip are ordered by drag and drop:
 *    the HTML5 drag API for a mouse, pointer events from the grip for a finger
 *    or a pen, and ↑ ↓ buttons for the keyboard. A row swaps when the drag
 *    ENTERS the other row -- an event on an element, so nothing is measured.
 */
import css from './page-header-editor.css?inline';
import { compile, topStyle } from './page-header-compile.js';

const TIMEOUT = 20000;
const UPLOAD_TIMEOUT = 90000;
const clone = (o) => JSON.parse(JSON.stringify(o));

function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = v;
        else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
        else el.setAttribute(k, v === true ? '' : String(v));
    }
    for (const kid of kids.flat()) {
        if (kid == null || kid === false) continue;
        el.appendChild(typeof kid === 'string' ? document.createTextNode(kid) : kid);
    }
    return el;
}

/** The address rule SafeUrl::src() applies, so a bad one is never drawn. */
export function safeSrc(value) {
    const v = String(value == null ? '' : value).trim();
    if (v === '' || v.length > 500 || /[\x00-\x20"'<>`\\]/.test(v)) return '';
    if (/^https?:\/\/[^/?#@\s]/i.test(v)) return v;
    if (v.startsWith('/') && !v.startsWith('//')) return v;
    return '';
}

/** A same-origin path, or null. */
function safePath(value) {
    const v = String(value == null ? '' : value);
    return v.startsWith('/') && !v.startsWith('//') && !v.includes('\\') ? v : null;
}

function ensureStyle(id, text) {
    if (document.getElementById(id)) return;
    const st = document.createElement('style');
    st.id = id;
    st.textContent = text;
    document.head.appendChild(st);
}

/** Is this page the Arabic site? The page's own <html lang>, as the server set it. */
function arabicPage() {
    return typeof document !== 'undefined' && String(document.documentElement.lang || '').toLowerCase().startsWith('ar');
}

/**
 * The picture a bag draws: {d, m, alt} or null. Mirrors PageHeaders::picture(),
 * including (Lane PHA) the Arabic pictures on an Arabic page.
 */
export function picture(bag, ar = arabicPage()) {
    let d = safeSrc(bag.img);
    let m = safeSrc(bag.img_m);
    if (ar) {
        const dAr = safeSrc(bag.img_ar);
        let mAr = safeSrc(bag.img_m_ar);
        if (!mAr && dAr && !m) mAr = dAr;
        if (dAr || mAr) {
            const dEn = d || m;
            const mEn = m || d;
            d = dAr || dEn;
            m = mAr || mEn;
        }
    }
    if (!d && !m) return null;
    if (!bag.d.image && !bag.m.image) return null;
    return { d: d || m, m: m || d, alt: String(bag.alt || '') };
}

/** One device's half on both, so a phone look can be previewed at desktop width. */
export function asDevice(bag, dev) {
    if (dev !== 'd' && dev !== 'm') return bag;
    return { ...bag, d: bag[dev], m: bag[dev] };
}

/**
 * Restyle a header region in place: classes, the style attribute, and the
 * picture element. `parts` holds the region's children by role.
 */
export function restyle(parts, bag, kind, breakpoint, crumb) {
    const pic = picture(bag);
    const c = compile(bag, kind, { intro: !!(parts.intro && parts.intro.textContent.trim() !== ''), image: !!pic, crumb: crumb || { d: true, m: true } });

    parts.wrap.className = c.wrap + (parts.wrap.classList.contains('kbb-phe-live') ? ' kbb-phe-live' : '');
    parts.wrap.setAttribute('style', c.style);
    for (const k of ['crumb', 'title', 'count', 'intro', 'button']) {
        if (parts[k]) parts[k].className = c.cls[k];
    }

    if (!pic) {
        if (parts.image) parts.image.remove();
        parts.image = null;
        return;
    }
    if (!parts.image) {
        parts.image = h('picture', {}, h('img', { decoding: 'async', alt: '' }));
        const after = parts.crumb && parts.crumb.parentNode === parts.wrap ? parts.crumb.nextSibling : parts.wrap.firstChild;
        parts.wrap.insertBefore(parts.image, after);
    }
    parts.image.className = c.cls.image;
    let source = parts.image.querySelector('source');
    if (pic.m !== pic.d) {
        if (!source) {
            source = h('source', {});
            parts.image.insertBefore(source, parts.image.firstChild);
        }
        source.setAttribute('media', `(max-width: ${Number(breakpoint) || 900}px)`);
        source.setAttribute('srcset', pic.m);
    } else if (source) {
        source.remove();
    }
    const img = parts.image.querySelector('img');
    img.setAttribute('src', pic.d);
    img.setAttribute('alt', pic.alt);
}

/**
 * A header built from sample parts, for the console's preview stage. The same
 * element names and classes partials/page-header.blade.php prints.
 */
export function stage(sample, bag, kind, breakpoint, crumb) {
    const parts = {};
    parts.wrap = h('div', {});
    parts.crumb = h('nav', {}, h('a', { href: '#', onclick: (e) => e.preventDefault() }, sample.home || 'Home'), ' / ', h('span', { text: sample.title }));
    parts.title = h('h1', {}, sample.title);
    parts.wrap.append(parts.crumb, parts.title);
    if (kind === 'collection') {
        parts.count = h('span', { text: sample.count });
        parts.title.append(' ', parts.count);
        parts.intro = h('p', { text: sample.intro || '' });
        parts.button = h('a', { href: '#', onclick: (e) => e.preventDefault() }, sample.button || 'All products');
        parts.wrap.append(parts.intro, parts.button);
    }
    restyle(parts, bag, kind, breakpoint, crumb);
    return parts.wrap;
}

/* ------------------------------------------------------------- controls */

/**
 * Draw the controls for one bag into `host`.
 *
 * opts: {bag, spec, kind, dev, onChange(), onDevice(dev), pick(done)}
 * `bag` is edited in place. Returns {redraw()}.
 */
export function controls(host, opts) {
    const { spec } = opts;
    ensureStyle('kbb-phe-css', css);
    const kindOk = (kinds) => kinds.includes(opts.kind);

    function redraw() {
        host.replaceChildren(...build());
    }

    function changed(full) {
        if (full) redraw();
        opts.onChange();
    }

    function build() {
        const dev = opts.dev;
        const half = opts.bag[dev];
        const out = [];

        out.push(h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: 'Device' }),
            h('div', { class: 'kbb-phe-seg', role: 'group', 'aria-label': 'Device' },
                [['d', 'Desktop'], ['m', 'Phone']].map(([v, l]) => h('button', {
                    type: 'button', 'aria-pressed': String(dev === v),
                    onclick: () => { opts.dev = v; if (opts.onDevice) opts.onDevice(v); redraw(); },
                }, l))),
            h('p', { class: 'kbb-phe-help', text: `Desktop is wider than ${spec.breakpoint}px; phone is ${spec.breakpoint}px and narrower. Each has its own settings.` }),
            h('div', { class: 'kbb-phe-row' }, h('button', {
                type: 'button', class: 'kbb-phe-btn',
                onclick: () => { opts.bag[dev === 'd' ? 'm' : 'd'] = clone(half); changed(true); },
            }, dev === 'd' ? 'Copy these settings to phone' : 'Copy these settings to desktop'))));

        // (Lane SP3) The order of the two blocks at the top of the page.
        out.push(blocksSection());

        // Show / hide
        out.push(h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: 'Show' }),
            h('div', { class: 'kbb-phe-tog' }, spec.shows.filter((s) => kindOk(s.kinds)).map((s) => h('label', {},
                h('input', {
                    type: 'checkbox', checked: half[s.key] ? true : null,
                    onchange: (e) => { half[s.key] = e.currentTarget.checked; changed(true); },
                }), h('span', { text: s.label })))),
            h('p', { class: 'kbb-phe-help', text: 'A hidden title is hidden from view only: it stays in the page as its heading (H1), so search engines and screen readers still read it. The breadcrumb also follows Appearance › Header › Breadcrumbs, which can hide it on every page.' })));

        // Position
        const order = half.order.filter((k) => opts.kind === 'collection' || ['crumb', 'image', 'title'].includes(k));
        const label = (k) => (spec.elements.find((e) => e.key === k) || { label: k }).label;
        const off = (k) => (k === 'title' ? !half.title : !half[k]);
        const move = (k, by) => {
            const all = half.order;
            const vis = order;
            const j = vis.indexOf(k) + by;
            if (j < 0 || j >= vis.length) return;
            const a = all.indexOf(k);
            const b = all.indexOf(vis[j]);
            [all[a], all[b]] = [all[b], all[a]];
            changed(true);
        };
        out.push(h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: 'Position' }),
            h('ol', { class: 'kbb-phe-ord' }, order.map((k, i) => h('li', { class: off(k) ? 'is-off' : null },
                h('span', { text: label(k) }),
                h('button', { type: 'button', 'aria-label': `Move ${label(k)} up`, disabled: i === 0 ? true : null, onclick: () => move(k, -1) }, '↑'),
                h('button', { type: 'button', 'aria-label': `Move ${label(k)} down`, disabled: i === order.length - 1 ? true : null, onclick: () => move(k, 1) }, '↓')))),
            spec.selects.filter((s) => s.key !== 'fit' && s.key !== 'width' && (s.key !== 'button_at' || opts.kind === 'collection')).map((s) => h('div', { class: 'kbb-phe-sel' },
                h('span', { text: s.label }),
                h('div', { class: 'kbb-phe-seg', role: 'group', 'aria-label': s.label }, s.options.map((o) => h('button', {
                    type: 'button', 'aria-pressed': String(half[s.key] === o.value),
                    onclick: () => { half[s.key] = o.value; changed(true); },
                }, o.label)))))));

        // Picture
        const pic = (key, title) => {
            const v = safeSrc(opts.bag[key]);
            return h('div', { class: 'kbb-phe-pic' },
                h('div', { class: 'kbb-phe-thumb' }, v ? h('img', { src: v, alt: '' }) : ({ img_m: 'Same as desktop', img_ar: 'English picture', img_m_ar: 'English picture' }[key] || 'No picture')),
                h('div', { class: 'kbb-phe-row' },
                    h('span', { text: title, style: 'width:100%;font-weight:600;font-size:12px' }),
                    h('button', {
                        type: 'button', class: 'kbb-phe-btn',
                        onclick: (e) => opts.pick((url) => { if (safeSrc(url)) { opts.bag[key] = url; changed(true); } }, e.currentTarget.closest('.kbb-phe-pic')),
                    }, v ? 'Change' : 'Choose'),
                    v ? h('button', { type: 'button', class: 'kbb-phe-btn', onclick: () => { opts.bag[key] = ''; changed(true); } }, 'Remove') : null));
        };
        const fit = spec.selects.find((s) => s.key === 'fit');
        out.push(h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: 'Header picture' }),
            pic('img', 'Picture'),
            pic('img_m', 'Phone picture (optional)'),
            pic('img_ar', 'Arabic desktop picture'),
            pic('img_m_ar', 'Arabic phone picture'),
            h('p', { class: 'kbb-phe-help', text: 'Shown on the Arabic site (/ar). Empty = the English picture.' }),
            h('label', { class: 'kbb-phe-sel' }, h('span', { text: 'Alt text' }), h('input', {
                type: 'text', maxlength: '160', value: opts.bag.alt || '', placeholder: 'What the picture shows',
                oninput: (e) => { opts.bag.alt = e.currentTarget.value; opts.onChange(); },
            })),
            fit ? h('div', { class: 'kbb-phe-sel' }, h('span', { text: fit.label }), h('div', { class: 'kbb-phe-seg', role: 'group', 'aria-label': fit.label },
                fit.options.map((o) => h('button', {
                    type: 'button', 'aria-pressed': String(half.fit === o.value),
                    onclick: () => { half.fit = o.value; changed(true); },
                }, o.label)))) : null,
            h('p', { class: 'kbb-phe-help', text: 'From the Media Library. “Fill” crops the picture to the height you set; “Whole picture” shows all of it inside that height.' })));

        // Sizes, then (Lane SP3) the top area's spacing for this device:
        // above the header, below it, and between it and the strip.
        const spacing = (spec.spacing || []).map((k) => spec.numbers.find((n) => n.key === k)).filter(Boolean);
        // (Lane FW) Picture width, for this device, beside its height and
        // corners: Normal keeps the page's side gutters, Full width runs the
        // picture to the screen's edges.
        const width = spec.selects.find((s) => s.key === 'width');
        out.push(h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: dev === 'd' ? 'Sizes · desktop' : 'Sizes · phone' }),
            width ? h('div', { class: 'kbb-phe-sel' }, h('span', { text: width.label }), h('div', { class: 'kbb-phe-seg', role: 'group', 'aria-label': width.label },
                width.options.map((o) => h('button', {
                    type: 'button', 'aria-pressed': String(half.width === o.value),
                    onclick: () => { half.width = o.value; changed(true); },
                }, o.label)))) : null,
            width ? h('p', { class: 'kbb-phe-help', text: 'Full width runs the picture to the edges of the screen on this device, with square corners; the title and buttons keep their usual margins.' }) : null,
            spec.numbers.filter((n) => !(spec.spacing || []).includes(n.key)).map((n) => range(half, n)),
            spacing.length ? h('div', { class: 'kbb-phe-space', style: 'display:grid;gap:8px' },
                spacing.map((n) => range(half, n)),
                h('p', { class: 'kbb-phe-help', text: 'Above: from the site header to the first block (the header, or the strip when it is on top); 0 is flush. Below: from the last block to the products or the page text. Between: from the header to the strip, when the strip is on.' })) : null));

        return out;
    }

    function range(half, n) {
        const outEl = h('output', { text: `${half[n.key]}px` });
        return h('label', { class: 'kbb-phe-rng' },
            h('div', {}, h('span', { text: n.label }), outEl),
            h('input', {
                type: 'range', min: n.min, max: n.max, step: '1', value: half[n.key], 'data-k': n.key,
                oninput: (e) => { half[n.key] = Number(e.currentTarget.value); outEl.textContent = `${half[n.key]}px`; opts.onChange(); },
            }));
    }

    /*
     * (Lane SP3) "give facilty to sort header area and strip. by drag n drop
     * up down." One order for both devices, kept on the bag beside the
     * picture, so it follows "Apply to" like every other setting here.
     */
    function blocksSection() {
        if (!Array.isArray(opts.bag.blocks)) opts.bag.blocks = (spec.blocks || []).map((b) => b.key);
        const blocks = opts.bag.blocks;
        const label = (k) => ((spec.blocks || []).find((b) => b.key === k) || { label: k }).label;
        const list = h('ol', { class: 'kbb-phe-ord kbb-phe-blocks', 'aria-label': 'Order of the header area and the strip' });
        const rows = {};
        let dragging = null;
        // 'mouse' (the browser's drag and drop) or 'touch' (pointer events).
        // Kept apart because Chromium fires pointercancel the moment a native
        // drag starts, and that must not end the drag it is part of.
        let mode = null;

        const moveTo = (k, to) => {
            const from = blocks.indexOf(k);
            if (from < 0 || to < 0 || to >= blocks.length || from === to) return false;
            blocks.splice(from, 1);
            blocks.splice(to, 0, k);
            return true;
        };
        // A drag ENTERED another row: take its place. The dragged row is moved,
        // not redrawn, so the drag in progress keeps its source element.
        const enter = (k) => {
            if (!dragging || dragging === k || !moveTo(dragging, blocks.indexOf(k))) return;
            for (const key of blocks) list.appendChild(rows[key]);
            opts.onChange();
        };
        const end = (how) => {
            if (!dragging || mode !== how) return;
            dragging = null;
            mode = null;
            changed(true);
        };

        blocks.forEach((k, i) => {
            const grip = h('span', { class: 'kbb-phe-grip', 'aria-hidden': 'true', text: '⠿' });
            const li = h('li', {
                'data-block': k, draggable: 'true',
                class: k === 'strip' && opts.stripOn === false ? 'is-off' : null,
            }, grip, h('span', { text: label(k) }),
            h('button', { type: 'button', 'aria-label': `Move ${label(k)} up`, disabled: i === 0 ? true : null, onclick: () => { if (moveTo(k, i - 1)) changed(true); } }, '↑'),
            h('button', { type: 'button', 'aria-label': `Move ${label(k)} down`, disabled: i === blocks.length - 1 ? true : null, onclick: () => { if (moveTo(k, i + 1)) changed(true); } }, '↓'));
            // A mouse: the browser's own drag and drop.
            li.addEventListener('dragstart', (e) => {
                dragging = k;
                mode = 'mouse';
                li.classList.add('is-drag');
                if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', k); }
            });
            li.addEventListener('dragenter', (e) => { if (mode === 'mouse') { e.preventDefault(); enter(k); } });
            li.addEventListener('dragover', (e) => { if (dragging) e.preventDefault(); });
            li.addEventListener('drop', (e) => e.preventDefault());
            li.addEventListener('dragend', () => end('mouse'));
            // A finger or a pen, from the grip: a touch is captured to the
            // element it started on, so the capture is released (below) and
            // the row under the finger hears pointerenter.
            grip.addEventListener('pointerdown', (e) => {
                if (e.pointerType === 'mouse') return;
                e.preventDefault();
                dragging = k;
                mode = 'touch';
                li.classList.add('is-drag');
            });
            // The browser captures a touch to the grip AFTER pointerdown has
            // run, so the capture is let go here, when it actually arrives.
            grip.addEventListener('gotpointercapture', (e) => { if (mode === 'touch') grip.releasePointerCapture(e.pointerId); });
            li.addEventListener('pointerenter', (e) => { if (mode === 'touch' && e.pointerType !== 'mouse') enter(k); });
            rows[k] = li;
            list.appendChild(li);
        });
        list.addEventListener('pointerup', () => end('touch'));
        list.addEventListener('pointercancel', () => end('touch'));
        list.addEventListener('pointerleave', (e) => { if (e.pointerType !== 'mouse') end('touch'); });

        return h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: 'Order · header area and strip' }),
            list,
            h('p', { class: 'kbb-phe-help', text: opts.stripOn === undefined
                ? 'Drag a row, or use ↑ ↓. The strip shows only on a page where it is switched on: that page’s Edit header panel, or Pages › Page banners.'
                : 'Drag a row, or use ↑ ↓. The strip is shown only when “Show the strip” above is on.' }));
    }

    redraw();
    return { redraw };
}

/* --------------------------------------------------------- the storefront */

let open = null;

async function send(url, csrf, body) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), TIMEOUT);
    try {
        const res = await fetch(url, {
            method: body === undefined ? 'GET' : 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
                ...(body === undefined ? {} : { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf }),
            },
            body: body === undefined ? undefined : JSON.stringify(body),
            signal: ctl.signal,
        });
        let json = null;
        try { json = await res.json(); } catch (e) { json = null; }
        return { status: res.status, ok: res.ok, body: json };
    } catch (e) {
        return { status: 0, ok: false, body: { message: ctl.signal.aborted ? 'That took too long. Try again.' : 'The connection dropped. Try again.' } };
    } finally {
        clearTimeout(timer);
    }
}

function messageOf(res, fallback) {
    const b = res && res.body;
    if (b && typeof b.message === 'string' && b.message) return b.message;
    if (b && b.errors && typeof b.errors === 'object') {
        const first = Object.values(b.errors)[0];
        if (Array.isArray(first) && first[0]) return String(first[0]);
    }
    if (res && res.status === 419) return 'Your session has expired. Reload the page and try again.';
    if (res && res.status === 403) return 'Your role cannot change the page header.';
    if (res && res.status === 401) return 'You are no longer signed in to the admin.';
    return fallback;
}

/**
 * Find the header on this page and put it in the configurable shape, if it is
 * not in it already. Returns {parts, restore()} or null when the page has no
 * header this panel understands.
 */
function takeHeader(ctx) {
    const wrapNow = document.querySelector('.kbb-home [data-kbb-ph]');
    if (wrapNow) {
        const saved = wrapNow.cloneNode(true);
        return {
            parts: partsOf(wrapNow),
            restore: () => { const live = document.querySelector('.kbb-home [data-kbb-ph]'); if (live) live.replaceWith(saved); },
        };
    }

    const crumb = document.querySelector('.kbb-home .sec > .wrap > nav.crumb');
    if (ctx.kind === 'collection') {
        const sh = document.querySelector('.kbb-home .sec > .wrap > .sh');
        if (!crumb || !sh) return null;
        const savedCrumb = crumb.cloneNode(true);
        const savedSh = sh.cloneNode(true);
        const wrap = h('div', { 'data-kbb-ph': ctx.key });
        sh.replaceWith(wrap);
        const title = sh.querySelector('h1');
        wrap.append(crumb, ...[title, sh.querySelector('p'), sh.querySelector('a.lnk')].filter(Boolean));
        return {
            parts: partsOf(wrap),
            restore: () => {
                const live = document.querySelector('.kbb-home [data-kbb-ph]');
                if (!live) return;
                live.replaceWith(savedCrumb, document.createTextNode('\n\n    '), savedSh);
            },
        };
    }

    const article = document.querySelector('.kbb-home article.policy');
    const title = article && article.querySelector(':scope > h1');
    if (!crumb || !title) return null;
    const savedCrumb = crumb.cloneNode(true);
    const savedTitle = title.cloneNode(true);
    const marker = crumb.previousSibling;
    const parent = crumb.parentNode;
    const wrap = h('div', { 'data-kbb-ph': ctx.key });
    title.replaceWith(wrap);
    wrap.append(crumb, title);
    return {
        parts: partsOf(wrap),
        restore: () => {
            const live = document.querySelector('.kbb-home [data-kbb-ph]');
            if (!live) return;
            live.replaceWith(savedTitle);
            parent.insertBefore(savedCrumb, marker ? marker.nextSibling : parent.firstChild);
        },
    };
}

function partsOf(wrap) {
    const title = wrap.querySelector(':scope > h1');
    return {
        wrap,
        crumb: wrap.querySelector(':scope > nav'),
        image: wrap.querySelector(':scope > picture'),
        title,
        count: title ? title.querySelector('.cnt, span') : null,
        intro: wrap.querySelector(':scope > p'),
        button: wrap.querySelector(':scope > a'),
    };
}

const SVG = 'http://www.w3.org/2000/svg';

/** App\Services\PageBanners::ICON, built as nodes. */
function tick() {
    const svg = document.createElementNS(SVG, 'svg');
    svg.setAttribute('class', 'kbb-pb-ic');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    const c = document.createElementNS(SVG, 'circle');
    for (const [k, v] of [['cx', '12'], ['cy', '12'], ['r', '10'], ['fill', 'none'], ['stroke', 'currentColor'], ['stroke-width', '2']]) c.setAttribute(k, v);
    const p = document.createElementNS(SVG, 'path');
    for (const [k, v] of [['d', 'm7.5 12.3 3 3 6-6.4'], ['fill', 'none'], ['stroke', 'currentColor'], ['stroke-width', '2.2'], ['stroke-linecap', 'round'], ['stroke-linejoin', 'round']]) p.setAttribute(k, v);
    svg.append(c, p);
    return svg;
}

/**
 * (Lane SP3) A banner as partials/page-banner.blade.php draws it, from the
 * view PageBanners::view() already resolved on the server. Words go in as
 * text; the picture only if safeSrc() passes it; the preview's picture is not
 * a link, so nothing in the panel navigates away.
 */
export function bannerEl(v) {
    if (!v) return null;
    const box = h('div', { class: 'kbb-pb', style: String(v.style || ''), 'data-banner': String(v.id || '') });
    const d = v.img ? safeSrc(v.img.d) : '';
    if (d) {
        const m = safeSrc(v.img.m);
        box.appendChild(h('div', { class: 'kbb-pb-img' }, h('picture', {},
            v.img.two && m ? h('source', { media: String(v.media || ''), srcset: m }) : null,
            h('img', { src: d, alt: String(v.img.alt || ''), decoding: 'async' }))));
    }
    const items = Array.isArray(v.items) ? v.items : [];
    if (items.length) {
        box.appendChild(h('ul', { class: 'kbb-pb-strip' }, items.map((t, i) => h('li', { class: { d: 'kbb-pb-d', m: 'kbb-pb-m' }[(v.devs || [])[i]] || null },
            tick(), h('span', { text: String(t) })))));
    }
    return box;
}

/**
 * (Lane SP3) The top area this page draws, or the one the panel builds for
 * the preview: <div class="kbb-pt"> holding the strip and the header area's
 * <div class="sec kbb-pt-s">, exactly as partials/page-top.blade.php prints
 * them. Returns {pt, holder, strip, restore()}.
 */
function takeTop(parts, ctx) {
    const home = parts.wrap.closest('.kbb-home') || document.querySelector('.kbb-home');
    const pt = home ? home.querySelector(':scope > .kbb-pt') : null;
    if (pt) {
        const style = pt.getAttribute('style');
        const kids = [...pt.childNodes];
        return {
            pt,
            holder: pt.querySelector(':scope > .kbb-pt-s'),
            strip: pt.querySelector(':scope > .kbb-pb'),
            restore: () => { pt.setAttribute('style', style || ''); pt.replaceChildren(...kids); },
        };
    }
    ensureStyle('kbb-pt-css', ctx.spec.top_css || '');
    const mark = document.createComment('kbb-pt');
    parts.wrap.before(mark);
    const inner = ctx.kind === 'page' ? h('div', { class: 'policy' }) : null;
    const wrapEl = h('div', { class: 'wrap' }, inner);
    (inner || wrapEl).appendChild(parts.wrap);
    const holder = h('div', { class: 'sec kbb-pt-s' }, wrapEl);
    const built = h('div', { class: 'kbb-pt', 'data-kbb-pt': ctx.key }, holder);
    home.insertBefore(built, home.firstChild);
    return { pt: built, holder, strip: null, restore: () => { mark.replaceWith(parts.wrap); built.remove(); } };
}

/** The storefront panel. Called by storefront-admin.js with the context's `pageheader`. */
export function openPanel(ctx, csrf, opener, toast) {
    if (open) { open.focus(); return; }
    ensureStyle('kbb-phe-css', css);
    ensureStyle('kbb-ph-css', ctx.spec.css);

    const taken = takeHeader(ctx);
    if (!taken) {
        if (toast) toast('This page has no header the panel can edit.');
        return;
    }
    const { parts } = taken;
    parts.wrap.classList.add('kbb-phe-live');

    const strip = ctx.strip || null;
    const top = takeTop(parts, ctx);
    // One element per banner, built once and reused as the switch moves.
    const stripEls = {};
    if (top.strip && strip && strip.on) stripEls[strip.on] = top.strip;

    const st = {
        scope: ctx.own ? 'page' : 'global',
        strip: strip ? strip.on : '',
        // (2.60.396) The strip on a laptop / on a phone, per strip.
        sdev: strip ? Object.fromEntries(strip.banners.map((b) => [b.id, { d: b.d !== false, m: b.m !== false }])) : {},
        bag: clone(ctx.bag),
        dev: window.matchMedia(`(max-width: ${ctx.spec.breakpoint}px)`).matches ? 'm' : 'd',
        dirty: false,
        busy: false,
    };
    const atPhone = () => window.matchMedia(`(max-width: ${ctx.spec.breakpoint}px)`).matches;
    // Previewing one device's look at the other's width: that device's
    // breadcrumb switch goes with it.
    const crumbFor = (dev) => (dev === 'd' || dev === 'm' ? { d: ctx.spec.crumb[dev], m: ctx.spec.crumb[dev] } : ctx.spec.crumb);
    // (Lane SP3) The top area: the strip on or off, the two blocks in order,
    // the spacing as the style attribute. Moves elements; measures nothing.
    const drawTop = (bag) => {
        top.pt.setAttribute('style', topStyle(bag));
        let el = null;
        if (st.strip && strip) {
            if (!(st.strip in stripEls)) {
                const b = strip.banners.find((x) => x.id === st.strip);
                stripEls[st.strip] = bannerEl(b ? b.view : null);
            }
            el = stripEls[st.strip];
            if (el) ensureStyle('kbb-pb-css', strip.css);
            const ul = el ? el.querySelector('.kbb-pb-strip') : null;
            const dv = st.sdev[st.strip];
            if (ul && dv) { ul.classList.toggle('kbb-pb-xd', !dv.d); ul.classList.toggle('kbb-pb-xm', !dv.m); }
        }
        for (const e of Object.values(stripEls)) if (e && e !== el) e.remove();
        for (const k of el ? bag.blocks : ['header']) top.pt.appendChild(k === 'strip' ? el : top.holder);
    };
    const live = () => {
        const same = (st.dev === 'm') === atPhone();
        const bag = same ? st.bag : asDevice(st.bag, st.dev);
        restyle(parts, bag, ctx.kind, ctx.spec.breakpoint, same ? ctx.spec.crumb : crumbFor(st.dev));
        drawTop(bag);
    };

    const err = h('p', { class: 'kbb-phe-err', role: 'alert' });
    const body = h('div', {});
    const scopeHost = h('div', {});
    const stripHost = h('div', {});
    const saveBtn = h('button', { type: 'button', class: 'kbb-phe-btn is-primary', onclick: () => save() }, 'Save');
    const pickerHost = h('div', {});
    const panel = h('div', { class: 'kbb-phe', role: 'dialog', 'aria-label': `Edit the header of ${ctx.label}`, tabindex: '-1' },
        h('div', { class: 'kbb-phe-in' },
            h('div', { class: 'kbb-phe-head' }, h('b', { text: `Page header · ${ctx.label}` }),
                h('button', { type: 'button', class: 'kbb-phe-x', 'aria-label': 'Close', onclick: () => close() }, '×')),
            scopeHost, stripHost, pickerHost, body, err,
            h('div', { class: 'kbb-phe-foot' }, saveBtn,
                h('button', { type: 'button', class: 'kbb-phe-btn', onclick: () => close() }, 'Cancel'),
                safePath(ctx.console) ? h('a', { href: safePath(ctx.console) }, 'Pages › Page header') : null)));

    function drawScope() {
        scopeHost.replaceChildren(h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: 'Apply to' }),
            h('div', { class: 'kbb-phe-seg', role: 'group', 'aria-label': 'Apply to' },
                [['page', 'This page only'], ['global', 'All custom pages']].map(([v, l]) => h('button', {
                    type: 'button', 'aria-pressed': String(st.scope === v),
                    onclick: () => { st.scope = v; drawScope(); },
                }, l))),
            h('p', { class: 'kbb-phe-help', text: st.scope === 'page'
                ? 'Saves a look for this page alone. Every other custom page keeps the global look.'
                : 'Saves the global look for every custom page that has no look of its own, and this page follows it from now on.' }),
            ctx.own ? h('div', { class: 'kbb-phe-row' }, h('button', {
                type: 'button', class: 'kbb-phe-btn',
                onclick: () => { st.bag = clone(ctx.global); st.dirty = true; ui.redraw(); live(); save('inherit'); },
            }, 'Use the global look on this page')) : null));
    }

    /*
     * (Lane SP3) "allow to turn ON on any page from the edit panel on the
     * front-end". This page's own switch, whatever "Apply to" says: the
     * assignment in Pages → Page banners, written by the same Save.
     */
    function drawStrip() {
        if (!strip) { stripHost.replaceChildren(); return; }
        const usable = strip.banners.filter((b) => b.view);
        const set = (id) => { st.strip = id; st.dirty = true; drawStrip(); ui.redraw(); live(); };
        stripHost.replaceChildren(h('div', { class: 'kbb-phe-sec kbb-phe-strip' },
            h('p', { class: 'kbb-phe-h', text: 'Strip' }),
            h('div', { class: 'kbb-phe-tog' }, h('label', { style: 'grid-column:1/-1' },
                h('input', {
                    type: 'checkbox', checked: st.strip ? true : null, disabled: !strip.can || !usable.length ? true : null,
                    onchange: (e) => set(e.currentTarget.checked ? (usable.some((b) => b.id === strip.on) ? strip.on : usable[0].id) : ''),
                }), h('span', { text: 'Show the strip on this page' }))),
            st.strip && usable.length > 1 ? h('label', { class: 'kbb-phe-sel' }, h('span', { text: 'Which strip' }),
                h('select', { onchange: (e) => { if (usable.some((b) => b.id === e.currentTarget.value)) set(e.currentTarget.value); } },
                    usable.map((b) => h('option', { value: b.id, selected: b.id === st.strip ? true : null }, b.name)))) : null,
            st.strip && st.sdev[st.strip] ? h('div', { class: 'kbb-phe-tog' }, ['d', 'm'].map((k) => h('label', {},
                h('input', {
                    type: 'checkbox', checked: st.sdev[st.strip][k] ? true : null, disabled: !strip.can ? true : null,
                    onchange: (e) => { st.sdev[st.strip][k] = e.currentTarget.checked; st.dirty = true; ui.redraw(); live(); },
                }), h('span', { text: k === 'd' ? 'On desktop' : 'On mobile' })))) : null,
            h('p', { class: 'kbb-phe-help', text: !strip.can
                ? 'Your role cannot switch the strip. An owner, manager or editor can.'
                : (usable.length ? 'For this page only, whatever “Apply to” says. Off on every page unless you switch it on here.' : 'There is no strip with any lines in it yet.') }),
            safePath(strip.console) ? h('a', { href: safePath(strip.console), class: 'kbb-phe-help' }, 'Its lines, colours and sizes: Pages › Page banners') : null));
    }

    const ui = controls(body, {
        get stripOn() { return strip ? st.strip !== '' : undefined; },
        get bag() { return st.bag; },
        spec: ctx.spec,
        kind: ctx.kind,
        get dev() { return st.dev; },
        set dev(v) { st.dev = v; },
        onDevice: () => live(),
        onChange: () => { st.dirty = true; live(); },
        pick: (done, at) => picker(done, at),
    });

    /* -- the Media Library, in the panel: one page of 24 at a time.
       (2.60.392) It opens UNDER the picture row whose Choose was pressed and is
       scrolled into view. It used to open in a host at the top of the panel,
       above where the owner was looking, so on a laptop "Choose" seemed to do
       nothing at all. */
    let openBox = null;
    function picker(done, at) {
        let page = 1;
        const grid = h('div', { class: 'kbb-phe-grid' });
        const note = h('p', { class: 'kbb-phe-help', text: 'Loading the Media Library…' });
        const more = h('button', { type: 'button', class: 'kbb-phe-btn', hidden: true, onclick: () => { page += 1; load(); } }, 'More');
        const file = h('input', { type: 'file', accept: (ctx.upload.types || []).join(','), hidden: true, onchange: (e) => upload(e.currentTarget.files[0]) });
        const box = h('div', { class: 'kbb-phe-sec' },
            h('p', { class: 'kbb-phe-h', text: 'Choose a picture' }), note, grid,
            h('div', { class: 'kbb-phe-row' }, more,
                h('button', { type: 'button', class: 'kbb-phe-btn', onclick: () => file.click() }, 'Upload new'), file,
                h('button', { type: 'button', class: 'kbb-phe-btn', onclick: () => close() }, 'Cancel')));
        const close = () => { box.remove(); if (openBox === box) openBox = null; };
        if (openBox) openBox.remove();
        if (at && at.parentNode) at.after(box); else pickerHost.replaceChildren(box);
        openBox = box;
        box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });

        const choose = (url) => { close(); done(url); };

        async function load() {
            more.hidden = true;
            const res = await send(`${ctx.endpoints.media}?page=${page}`);
            if (!res.ok || !res.body || !Array.isArray(res.body.items)) {
                note.textContent = messageOf(res, 'The Media Library could not be read.');
                return;
            }
            note.textContent = res.body.total ? 'Tap a picture to use it.' : 'The Media Library is empty. Upload a picture.';
            res.body.items.forEach((it) => {
                const url = safeSrc(it.url);
                const thumb = safeSrc(it.thumb) || url;
                if (!url) return;
                grid.appendChild(h('button', { type: 'button', 'aria-label': String(it.name || it.filename || 'Picture'), onclick: () => choose(url) },
                    h('img', { src: thumb, alt: '', loading: 'lazy' })));
            });
            more.hidden = !(res.body.pages > page);
        }

        function upload(f) {
            if (!f) return;
            if ((ctx.upload.types || []).length && !ctx.upload.types.includes(f.type)) { note.textContent = 'Use a JPG, PNG, WebP or GIF.'; return; }
            if (f.size > ctx.upload.max_bytes) { note.textContent = `That picture is over ${Math.round(ctx.upload.max_bytes / 1048576)} MB.`; return; }
            const form = new FormData();
            form.append('file', f);
            form.append('folder', ctx.upload.folder);
            const req = new XMLHttpRequest();
            req.open('POST', ctx.endpoints.upload);
            req.timeout = UPLOAD_TIMEOUT;
            req.withCredentials = true;
            req.setRequestHeader('Accept', 'application/json');
            req.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            req.setRequestHeader('X-CSRF-TOKEN', csrf);
            note.textContent = 'Uploading…';
            req.onload = () => {
                let b = null;
                try { b = JSON.parse(req.responseText); } catch (e) { b = null; }
                const url = b && b.ok ? safeSrc(b.url) : '';
                if (req.status >= 200 && req.status < 300 && url) choose(url);
                else note.textContent = messageOf({ status: req.status, body: b }, 'The picture could not be uploaded.');
            };
            req.onerror = () => { note.textContent = 'The upload stopped. Try again.'; };
            req.ontimeout = () => { note.textContent = 'The upload took too long. Try a smaller picture.'; };
            req.send(form);
        }

        load();
    }

    async function save(scope) {
        if (st.busy) return;
        st.busy = true;
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving…';
        err.textContent = '';
        const which = scope || st.scope;
        const payload = { key: ctx.key, scope: which, bag: which === 'inherit' ? null : st.bag };
        if (strip && st.strip !== strip.on) payload.strip = st.strip;
        const was = strip && st.strip ? strip.banners.find((b) => b.id === st.strip) : null;
        const dv = was ? st.sdev[st.strip] : null;
        if (dv && (dv.d !== (was.d !== false) || dv.m !== (was.m !== false))) {
            payload.strip = st.strip;
            payload.strip_dev = { d: dv.d, m: dv.m };
        }
        const res = await send(ctx.endpoints.apply, csrf, payload);
        st.busy = false;
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save';
        if (!res.ok || !res.body || res.body.ok !== true) {
            err.textContent = messageOf(res, 'That could not be saved.');
            return;
        }
        ctx.own = !!res.body.own;
        ctx.bag = res.body.bag;
        ctx.global = res.body.global;
        st.bag = clone(ctx.bag);
        if (strip) { strip.on = String(res.body.strip || ''); st.strip = strip.on; }
        if (was && dv && payload.strip_dev) { was.d = dv.d; was.m = dv.m; }
        st.scope = ctx.own ? 'page' : 'global';
        st.dirty = false;
        if (toast) toast(String(res.body.message || 'Saved'));
        finish(false);
    }

    function onKey(e) {
        if (e.key === 'Escape') close();
    }

    function close() {
        if (st.dirty && !window.confirm('Close without saving? The header goes back to how it was.')) return;
        finish(true);
    }

    function finish(revert) {
        document.removeEventListener('keydown', onKey);
        panel.remove();
        open = null;
        if (revert) {
            // The page's own strip element had its device classes moved by the
            // preview; put them back before it goes back on the page.
            const own = strip && strip.on ? stripEls[strip.on] : null;
            const ul = own ? own.querySelector('.kbb-pb-strip') : null;
            const b = ul ? strip.banners.find((x) => x.id === strip.on) : null;
            if (b) { ul.classList.toggle('kbb-pb-xd', b.d === false); ul.classList.toggle('kbb-pb-xm', b.m === false); }
            top.restore();
            taken.restore();
        } else {
            parts.wrap.classList.remove('kbb-phe-live');
            restyle(parts, ctx.bag, ctx.kind, ctx.spec.breakpoint, ctx.spec.crumb);
            drawTop(ctx.bag);
        }
        if (opener && opener.isConnected) opener.focus({ preventScroll: true });
    }

    drawScope();
    drawStrip();
    document.addEventListener('keydown', onKey);
    document.body.appendChild(panel);
    open = panel;
    live();
    panel.focus({ preventScroll: true });
}
