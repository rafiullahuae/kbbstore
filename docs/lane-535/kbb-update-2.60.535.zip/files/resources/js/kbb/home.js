/**
 * Homepage behaviour: the hero slider.
 *
 * Everything else on the page is server-rendered — the grids, the quiz form and
 * the section visibility — so this is deliberately small.
 */
import { t } from './i18n.js';

export function initHome() {
    initMobileChrome();
    initHeaderScroll();

    const slider = document.getElementById('slider');
    if (!slider) return;

    const track = document.getElementById('slides');
    const slides = track ? track.children.length : 0;
    if (slides < 2) return;

    const dots = slider.querySelector('.sdots');
    let index = 0;
    let timer = null;

    dots.innerHTML = Array.from({ length: slides }, (_, i) =>
        `<i data-go="${i}"${i ? '' : ' class="on"'}></i>`).join('');

    /*
     * WHICH WAY THE TRACK TRAVELS IS THE DOCUMENT'S DIRECTION, NOT A CONSTANT.
     *
     * `.slides` is a flex row, so in a `dir="rtl"` document the slides queue
     * leading-edge-right: slide 1 sits to the LEFT of slide 0, at -100% of the
     * frame, slide 2 at -200%, and so on. Pulling slide i into view is
     * therefore a POSITIVE translation in Arabic and a negative one in English
     * — the same arithmetic with the sign the direction chooses.
     *
     * Before this, the sign was hard-coded negative and `kbb.css` handed the
     * track a left-to-right coordinate system with
     * `[dir="rtl"] .kbb-home .slides{direction:ltr}` so that the hard-coded
     * sign still found the slides. That made the carousel WORK and left it
     * travelling the wrong way: ▸ pushed the next slide in from the left in a
     * document being read from the right. Both of those CSS rules are deleted
     * with this change (rtl-audit §13.5) — two fixes for one defect is worse
     * than either, and RtlMirrorTest fails if they come back.
     *
     * THE SIGN IS A STRING, NOT ARITHMETIC, and deliberately so: `-index*100`
     * at index 0 is negative zero, which a template literal prints as "0", so
     * the English page's very first inline transform would have gone from
     * `translateX(-0%)` to `translateX(0%)`. Identical to the pixel and to
     * getComputedStyle, and still a byte this lane has no business moving.
     *
     * Read per call rather than once at boot, so that flipping
     * `document.documentElement.dir` on a live page — which is how every RTL
     * measurement in docs/rtl-audit.md was taken — reorients the slider without
     * a reload. It is one attribute read per click, and it measures nothing:
     * `dir` is what the server printed from Locale::direction(), not a layout
     * query.
     */
    const rtl = () => document.documentElement.dir === 'rtl';

    const go = (i) => {
        index = (i + slides) % slides;
        track.style.transform = `translateX(${rtl() ? '' : '-'}${index * 100}%)`;
        dots.querySelectorAll('i').forEach((d, j) => d.classList.toggle('on', j === index));
    };

    const play = () => { timer = setInterval(() => go(index + 1), 6000); };
    const stop = () => clearInterval(timer);
    const restart = () => { stop(); play(); };

    slider.querySelector('.sarr.prev')?.addEventListener('click', () => { go(index - 1); restart(); });
    slider.querySelector('.sarr.next')?.addEventListener('click', () => { go(index + 1); restart(); });
    dots.addEventListener('click', (e) => {
        const d = e.target.closest('[data-go]');
        if (d) { go(Number(d.dataset.go)); restart(); }
    });

    // Pause while the pointer is over it, and while the tab is hidden — an
    // unattended slider advancing in a background tab is wasted work.
    slider.addEventListener('mouseenter', stop);
    slider.addEventListener('mouseleave', play);
    document.addEventListener('visibilitychange', () => document.hidden ? stop() : restart());

    // Swipe on touch. The track follows the finger, so the drag that advances
    // it is the one that moves it the way `go()` moves it — leftward in
    // English, rightward in Arabic. In an LTR document this is `dx < 0`, to the
    // character, which is what it has always been.
    let startX = null;
    slider.addEventListener('pointerdown', (e) => { startX = e.clientX; });
    slider.addEventListener('pointerup', (e) => {
        if (startX === null) return;
        const dx = e.clientX - startX;
        const forward = rtl() ? dx > 0 : dx < 0;
        if (Math.abs(dx) > 50) { go(forward ? index + 1 : index - 1); restart(); }
        startX = null;
    });

    play();
}

/**
 * The mobile slide-in menu.
 *
 * Lives here rather than in its own file because it is a dozen lines and only
 * ever appears alongside the tab bar.
 */
function initMobileChrome() {
    const menu = document.getElementById('mmenu');
    const scrim = document.getElementById('mscrim');
    const burger = document.getElementById('burger');
    if (!menu || !scrim) return;

    const singleOpen = menu.dataset.singleOpen !== '0';

    /*
     * Appearance → Mobile menu → Panel → "Menu opens from" (Lane MN). Left is
     * the glass side panel and is what the server prints by default; Bottom is
     * the sheet exactly as it was. Everything below that only the side panel
     * does sits behind `side`, so with Bottom this function behaves as it
     * always has.
     */
    const side = menu.classList.contains('mm-left');
    if (side) menu.tabIndex = -1;

    /*
     * KEYBOARD OR TOUCH (17 October 2026). The owner: "the mobile menu icon,
     * when we click, it left one weird outer blue border". Moving focus by
     * script after a TAP -- into the panel on open, back to ☰ on close -- lets
     * a phone's Chrome draw its blue focus ring round the icon. So focus moves
     * only when the menu was opened or shut from the keyboard (Enter/Space on
     * a button arrives as a CLICK with detail 0 -- a swipe's pointerup has
     * detail 0 too, so the type is checked; Escape is a key), where it is
     * what keeps a keyboard user's place. A tap moves nothing, and a button
     * left focused inside the shut panel is let go. No header CSS changes.
     */
    const byKeys = (event) => !!event && (event.type === 'keydown' || (event.type === 'click' && event.detail === 0));

    const open = (event) => {
        menu.classList.add('on');
        scrim.classList.add('on');
        document.body.classList.add('menu-open');
        document.body.style.overflow = 'hidden';
        burger?.setAttribute('aria-expanded', 'true');
        // Into the panel, on the close button rather than the search field,
        // so a phone's keyboard does not jump up over the menu.
        if (side && byKeys(event)) (document.getElementById('mmx') || menu).focus({ preventScroll: true });
    };
    const shut = (event) => {
        const was = menu.classList.contains('on');
        menu.classList.remove('on');
        scrim.classList.remove('on');
        document.body.classList.remove('menu-open');
        document.body.style.overflow = '';
        burger?.setAttribute('aria-expanded', 'false');
        // Back to the burger that opened it -- only when it really was open,
        // because Escape anywhere on the page calls this too.
        if (side && was && byKeys(event)) burger?.focus({ preventScroll: true });
        else if (was && menu.contains(document.activeElement)) document.activeElement.blur();
    };

    burger?.addEventListener('click', (event) => (menu.classList.contains('on') ? shut(event) : open(event)));
    document.getElementById('mmx')?.addEventListener('click', shut);
    scrim.addEventListener('click', shut);
    document.addEventListener('keydown', (e) => e.key === 'Escape' && shut(e));

    menu.addEventListener('click', (event) => {
        if (event.target.closest('[data-mm-close]')) { shut(event); return; }

        const parent = event.target.closest('.mm-par');
        if (parent) {
            const node = parent.parentElement;
            const wasOpen = node.classList.contains('on');

            // Only one section open at a time, so the highlight keeps meaning
            // something. Siblings only — a nested section stays put.
            if (singleOpen) {
                [...node.parentElement.children].forEach((sib) => {
                    if (sib !== node) sib.classList?.remove('on');
                });
            }

            node.classList.toggle('on', !wasOpen);
            return;
        }

        // Following a link should close the sheet, or it is still open on return.
        if (event.target.closest('a')) shut(event);
    });

    if (side) initSidePanel(menu, shut);
    initMenuFilter(menu);
}

/**
 * What only the side panel does: keep Tab inside it while it is open, and close
 * it on a swipe toward the edge it came from (the left, the right in Arabic).
 *
 * Nothing here measures the page. The swipe reads pointer coordinates and sets
 * a transform; the panel's size is the stylesheet's business.
 */
function initSidePanel(menu, shut) {
    const rtl = () => document.documentElement.dir === 'rtl';

    // A row is reachable unless the filter hid it or it sits in a closed section.
    const reachable = () => [...menu.querySelectorAll('a[href], button, input')]
        .filter((el) => !el.closest('.mm-hide, [hidden], .mm-node:not(.on) > .mm-kid, .mm-grab'));

    menu.addEventListener('keydown', (e) => {
        if (e.key !== 'Tab' || !menu.classList.contains('on')) return;
        const f = reachable();
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1], at = document.activeElement;
        if (e.shiftKey && (at === first || at === menu)) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && at === last) { e.preventDefault(); first.focus(); }
    });

    let pid = null, x0 = 0, y0 = 0, t0 = 0, dx = 0, axis = '', dragged = false;

    menu.addEventListener('pointerdown', (e) => {
        // Nor the quick-link row (V4, Lane M4): it scrolls sideways itself.
        if (!menu.classList.contains('on') || e.target.closest('input, .mm-chips')) return;
        if (e.pointerType === 'mouse' && e.button !== 0) return;
        pid = e.pointerId; x0 = e.clientX; y0 = e.clientY; t0 = e.timeStamp; dx = 0; axis = '';
    });
    menu.addEventListener('pointermove', (e) => {
        if (e.pointerId !== pid) return;
        // Toward the edge the panel came from is negative, in both directions.
        const mx = (e.clientX - x0) * (rtl() ? -1 : 1);
        if (!axis) {
            if (Math.abs(mx) < 10 && Math.abs(e.clientY - y0) < 10) return;
            axis = Math.abs(mx) > Math.abs(e.clientY - y0) * 1.2 ? 'x' : 'y';
            if (axis === 'x') { try { menu.setPointerCapture(pid); } catch (_) { /* gone */ } menu.classList.add('mm-drag'); }
        }
        if (axis !== 'x') return;
        dx = Math.min(0, mx);
        menu.style.transform = `translateX(${rtl() ? -dx : dx}px)`;
    });
    const end = (e) => {
        if (e.pointerId !== pid) return;
        pid = null;
        if (axis !== 'x') return;
        dragged = true;
        setTimeout(() => { dragged = false; }, 60);
        menu.classList.remove('mm-drag');
        menu.style.transform = '';
        if (dx < -60 || dx / Math.max(1, e.timeStamp - t0) < -0.45) shut(e);
    };
    menu.addEventListener('pointerup', end);
    menu.addEventListener('pointercancel', end);
    // A drag that ends over a link is a swipe, not a tap on the link.
    menu.addEventListener('click', (e) => { if (dragged) { e.preventDefault(); e.stopPropagation(); } }, true);
}

/**
 * Filter the menu as you type.
 *
 * Matches on the row's own text, and keeps a parent visible when any of its
 * children match — otherwise searching for a brand would hide the section it
 * lives in. Sections holding a match are opened so the result is on screen.
 */
function initMenuFilter(menu) {
    const input = document.getElementById('mmFilter');
    const empty = document.getElementById('mmEmpty');
    if (!input) return;

    const rows = [...menu.querySelectorAll('.mm-it, .mm-si, .mm-grp')];
    const nodes = [...menu.querySelectorAll('.mm-node')];

    const run = () => {
        const q = input.value.trim().toLowerCase();

        if (!q) {
            rows.forEach((r) => r.classList.remove('mm-hide'));
            nodes.forEach((n) => { n.classList.remove('mm-hide'); n.classList.remove('on'); });
            if (empty) empty.hidden = true;
            return;
        }

        let hits = 0;

        // Leaves first, then a section is shown if it or anything inside matched.
        rows.forEach((row) => {
            if (row.classList.contains('mm-par') || row.classList.contains('mm-grp')) return;
            const match = row.textContent.toLowerCase().includes(q);
            row.classList.toggle('mm-hide', !match);
            if (match) hits++;
        });

        nodes.slice().reverse().forEach((node) => {
            const label = node.querySelector('.mm-par');
            const selfMatch = label && label.textContent.toLowerCase().includes(q);
            const childMatch = node.querySelector('.mm-si:not(.mm-hide), .mm-it:not(.mm-hide), .mm-node:not(.mm-hide)');

            if (selfMatch) {
                node.querySelectorAll('.mm-si, .mm-it').forEach((r) => r.classList.remove('mm-hide'));
                node.querySelectorAll('.mm-node').forEach((n) => n.classList.remove('mm-hide'));
                hits++;
            }

            const show = selfMatch || !!childMatch;
            node.classList.toggle('mm-hide', !show);
            node.classList.toggle('on', show);
            if (label) label.classList.remove('mm-hide');
        });

        menu.querySelectorAll('.mm-grp').forEach((g) => g.classList.add('mm-hide'));
        if (empty) empty.hidden = hits > 0;
    };

    let timer;
    input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 90); });
}


/**
 * Collapse the trending row once the page moves.
 *
 * The bar and the category nav stay pinned; the trending chips are a discovery
 * aid, so they give their row back as soon as someone starts reading. The
 * listener is passive and only touches the DOM when the state actually
 * changes, so it costs nothing while scrolling.
 */
function initHeaderScroll() {
    const header = document.querySelector('header');
    if (!header) return;

    /*
     * Two thresholds, not one.
     *
     * The trending row is up to 52px tall and collapsing it shortens the page,
     * which can drop the scroll position back below a single threshold — the
     * row reopens, the page lengthens, and it crosses again. That feedback
     * loop is what made the header shudder on a small scroll.
     *
     * Collapsing at 120 and reopening only below 40 leaves an 80px gap, wider
     * than the row itself, so a collapse can never undo its own trigger.
     */
    const COLLAPSE_AT = 120;
    const EXPAND_AT = 40;

    let scrolled = false;
    let ticking = false;

    const apply = () => {
        ticking = false;
        const y = window.scrollY;

        // Only the crossing of a threshold changes anything; between the two
        // the current state simply holds.
        const next = scrolled ? y > EXPAND_AT : y > COLLAPSE_AT;

        if (next !== scrolled) {
            scrolled = next;
            header.classList.toggle('scrolled', next);
        }
    };

    // One read per frame at most, so a fast scroll cannot queue up work.
    const onScroll = () => {
        if (!ticking) {
            ticking = true;
            requestAnimationFrame(apply);
        }
    };

    apply();
    window.addEventListener('scroll', onScroll, { passive: true });
}


/**
 * The account panel.
 *
 * Hover opens it on a pointer device; a tap opens it on a phone, where it
 * becomes a sheet with a backdrop. The trigger is a link, so a tap must be
 * stopped from navigating before the panel has a chance to appear.
 */
export function initAccountPanel() {
    const host = document.querySelector('[data-acct]');
    if (!host) return;

    const panel = host.querySelector('.acct');
    const link = host.querySelector('a.ib');
    if (!panel || !link) return;

    const phone = () => window.matchMedia('(max-width: 900px)').matches;
    let scrim = null;
    let timer;

    const open = () => {
        clearTimeout(timer);
        panel.hidden = false;
        link.setAttribute('aria-expanded', 'true');

        if (phone() && !scrim) {
            scrim = document.createElement('div');
            scrim.className = 'acct-scrim';
            scrim.addEventListener('click', close);
            document.body.appendChild(scrim);
        }
    };

    const close = () => {
        panel.hidden = true;
        link.setAttribute('aria-expanded', 'false');
        scrim?.remove();
        scrim = null;
    };

    // Hover or click, as chosen. A phone is always a tap, since hover there
    // either does not exist or fires on the tap anyway.
    const byHover = 'click' !== host.dataset.acctOpen;

    if (byHover) {
        // A short grace period, so crossing the gap does not close it.
        host.addEventListener('mouseenter', () => { if (!phone()) open(); });
        host.addEventListener('mouseleave', () => { if (!phone()) timer = setTimeout(close, 180); });
    }

    link.addEventListener('click', (event) => {
        if (!phone() && byHover) return;   // the link works as a link
        event.preventDefault();
        panel.hidden ? open() : close();
    });

    document.addEventListener('keydown', (e) => { if ('Escape' === e.key) close(); });
    document.addEventListener('pointerdown', (e) => {
        if (!host.contains(e.target) && !e.target.closest('.acct')) close();
    }, true);

    // Sign in / create account
    panel.addEventListener('click', (event) => {
        const tab = event.target.closest('[data-acct-tab]');
        if (!tab) return;
        const which = tab.dataset.acctTab;
        panel.querySelectorAll('[data-acct-tab]').forEach((t) => t.classList.toggle('on', t === tab));
        panel.querySelectorAll('[data-acct-pane]').forEach((p) => p.classList.toggle('on', p.dataset.acctPane === which));
    });

    // A fresh sum after a failed submission, since each one is single-use.
    panel.addEventListener('submit', async (event) => {
        const form = event.target;
        if (!form.querySelector('[data-hc-token]')) return;

        setTimeout(async () => {
            try {
                const r = await fetch('/api/human-check', { headers: { Accept: 'application/json' } });
                if (!r.ok) return;
                const q = await r.json();
                form.querySelector('[data-hc-token]').value = q.token;
                form.querySelector('[data-hc-q]').textContent = q.question;
            } catch (e) { /* the page is navigating anyway */ }
        }, 1200);
    });
}


/** Sign in / create account tabs on the account page. */
export function initAccountPage() {
    const tabs = document.querySelectorAll('[data-acw-tab]');
    if (!tabs.length) return;

    tabs.forEach((tab) => tab.addEventListener('click', () => {
        const which = tab.dataset.acwTab;
        tabs.forEach((t) => t.classList.toggle('on', t === tab));
        document.querySelectorAll('[data-acw-pane]').forEach((p) =>
            p.classList.toggle('on', p.dataset.acwPane === which));
    }));
}


/** Show or hide a password. */
export function initReveal() {
    document.addEventListener('click', (event) => {
        const button = event.target.closest('[data-reveal]');
        if (!button) return;

        const input = document.getElementById(button.dataset.reveal);
        if (!input) return;

        const shown = 'text' === input.type;
        input.type = shown ? 'password' : 'text';
        button.classList.toggle('on', !shown);
        button.setAttribute('aria-label', shown
            ? t('store.account.show_password', 'Show password')
            : t('store.js.hide_password', 'Hide password'));
        input.focus();
    });
}


/**
 * Password strength.
 *
 * Four bands, judged on length and variety with the obvious weaknesses
 * subtracted: a single repeated character, a run off the keyboard, a date, or
 * one of the passwords that turn up at the top of every breach list. It is a
 * hint rather than a gate — the form still enforces its eight-character
 * minimum on the server.
 */
const WEAK_WORDS = [
    'password', 'qwerty', 'abc123', 'letmein', 'welcome', 'admin', 'iloveyou',
    'monkey', 'dragon', 'football', 'princess', 'sunshine', 'kbeauty', 'skincare',
];

function passwordScore(value) {
    if (!value) return { score: 0, label: '' };

    const lower = value.toLowerCase();

    // Anything on this list is weak whatever else it contains.
    if (WEAK_WORDS.some((w) => lower.includes(w))) return { score: 1, label: t('store.js.password_common', 'Too common') };

    // A single character repeated, or a straight run, is length without variety.
    if (/^(.)\1+$/.test(value)) return { score: 1, label: t('store.js.password_simple', 'Too simple') };
    if (/^(?:0123|1234|2345|3456|4567|5678|6789|abcd|qwer|asdf)/i.test(value)) {
        return { score: 1, label: t('store.js.password_simple', 'Too simple') };
    }

    let score = 0;
    if (value.length >= 8) score += 1;
    if (value.length >= 12) score += 1;
    if (value.length >= 16) score += 1;

    let variety = 0;
    if (/[a-z]/.test(value)) variety += 1;
    if (/[A-Z]/.test(value)) variety += 1;
    if (/[0-9]/.test(value)) variety += 1;
    if (/[^A-Za-z0-9]/.test(value)) variety += 1;

    if (variety >= 3) score += 1;
    if (variety === 4) score += 1;

    // Only digits, however many, is a date or a phone number.
    if (/^\d+$/.test(value)) score = Math.min(score, 1);

    if (value.length < 8) score = Math.min(score, 1);

    score = Math.max(1, Math.min(4, score));

    return {
        score,
        label: [
            '',
            t('store.js.password_weak', 'Weak'),
            t('store.js.password_fair', 'Fair'),
            t('store.js.password_good', 'Good'),
            t('store.js.password_strong', 'Strong'),
        ][score],
    };
}

export function initPasswordMeter() {
    const meter = document.querySelector('.meter');
    if (!meter) return;

    /*
     * Every password field on the form, not just the first.
     *
     * A browser filling saved details often puts the value in the confirmation
     * field and leaves the first one empty, which left the bar at zero with a
     * password plainly on screen. Whichever field holds something is the one
     * worth judging.
     */
    const fields = Array.from(document.querySelectorAll('input[type="password"]'));
    if (!fields.length) return;

    const label = meter.querySelector('.meter-label');

    const update = () => {
        const filled = fields.find((f) => f.value);
        const { score, label: text } = passwordScore(filled ? filled.value : '');
        meter.dataset.score = String(score);
        if (label) label.textContent = text;
    };

    meter.dataset.score = '0';

    fields.forEach((f) => {
        f.addEventListener('input', update);
        // A field the browser fills never fires `input`.
        f.addEventListener('change', update);
    });

    /*
     * Autofill lands without an event and without a fixed delay, so the first
     * couple of seconds are polled and then left alone, rather than running a
     * timer for the life of the page.
     */
    let tries = 0;
    const settle = setInterval(() => {
        update();
        if (++tries > 8) clearInterval(settle);
    }, 250);
}
