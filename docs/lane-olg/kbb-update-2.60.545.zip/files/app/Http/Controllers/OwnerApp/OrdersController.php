<?php

declare(strict_types=1);

namespace App\Http\Controllers\OwnerApp;

use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AdminOrderController;
use App\Http\Controllers\Admin\OrderDetailController;
use App\Http\Controllers\Admin\OrdersApiController;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\OwnerApp\OwnerAppEvents;
use App\Support\ImageVariants;
use App\Support\Money;
use App\Support\OrderEmirate;
use App\Support\OrderPaymentPanel;
use App\Support\StoreTime;
use Carbon\CarbonImmutable;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Orders in the owner app (Lane MAC): the list, one order, and the four
 * things a member does to an order from a phone.
 *
 * ── THE WRITES ARE THE ADMIN'S OWN ─────────────────────────────────────────
 *
 * Status (one or many), notes and "mark as paid" are not reimplemented here.
 * Each is handed to the exact controller method the admin console calls —
 * OrdersApiController::bulkStatus(), AdminController::updateOrderStatus(),
 * AdminOrderController::addNote(), OrderDetailController::markPaid() — after
 * this class has checked the member's capability. So the revenue guard, the
 * stock that goes back on the shelf, the coupon that is released, the email
 * the customer gets and the order note all behave exactly as they do in the
 * admin, because they ARE the admin's. Only the response is rebuilt: the app
 * gets its own allowlisted shape, never the admin payload.
 *
 * ── THE READS ARE AN ALLOWLIST ─────────────────────────────────────────────
 *
 * Every row is built field by field from a query that selects named columns.
 * `orders.ip_address`, `customers.password` and the WooCommerce ids are never
 * selected, so they cannot be returned by mistake. Customer email, phone and
 * address ARE returned — to a member holding orders.view, the same people who
 * see them in the admin.
 */
final class OrdersController extends Controller
{
    use Concerns;

    public const PER_PAGE = 30;

    public const STATUSES = ['pending', 'processing', 'onhold', 'shipped', 'completed', 'cancelled', 'refunded', 'failed', 'draft'];

    /** What the bulk bar and the status sheet may set: the admin's own BULK_SETTABLE. */
    public const SETTABLE = ['pending', 'processing', 'onhold', 'shipped', 'completed', 'cancelled'];

    private const LIKE_ESCAPE = '!';

    /* ----------------------------------------------------------------- list */

    public function index(Request $request): JsonResponse
    {
        if ($r = $this->refuse($request, 'orders.view')) {
            return $r;
        }

        try {
            return $this->listing($request);
        } catch (\Illuminate\Database\QueryException $e) {
            // Lane EM: new code against the old schema for the seconds an
            // update takes -- the list without emirates rather than a 500.
            if (! OrderEmirate::ready() || ! OrderEmirate::isMissingColumn($e)) {
                throw $e;
            }

            OrderEmirate::markMissing();

            return $this->listing($request);
        }
    }

    private function listing(Request $request): JsonResponse
    {
        $byEmirate = OrderEmirate::ready();

        $base = $this->filtered($request);
        $status = (string) $request->query('status', '');
        $before = max(0, (int) $request->query('before', 0));
        $emirate = $byEmirate ? OrderEmirate::filterValue($request->query('emirate')) : null;

        /*
         * Lane EM: with the first page, the chip counts are grouped by emirate
         * too, in the SAME statement. An order whose emirate nobody has read
         * yet (the checkout does not write the column) is a NULL group there;
         * only then are the newest such orders read and the counts taken again,
         * BEFORE the rows and the emirate filter use them. Nothing new costs
         * nothing.
         */
        $grouped = null;
        if ($before === 0 && $byEmirate) {
            $group = fn () => (clone $base)->groupBy('o.status', 'o.ship_emirate')
                ->selectRaw('o.status as s, o.ship_emirate as e, COUNT(*) as n')->get();
            $grouped = $group();

            if ($grouped->contains(fn ($g) => $g->e === null) && OrderEmirate::fillMissing() > 0) {
                $grouped = $group();
            }
        }

        $rows = (clone $base)
            ->when(in_array($status, self::STATUSES, true), fn (Builder $q) => $q->where('o.status', $status))
            ->when($emirate !== null, fn (Builder $q) => $q->where('o.ship_emirate', $emirate))
            ->when($before > 0, fn (Builder $q) => $q->where('o.id', '<', $before))
            ->leftJoin('customers as c', 'c.id', '=', 'o.customer_id')
            ->orderByDesc('o.id')
            ->limit(self::PER_PAGE + 1)
            ->get(array_merge([
                'o.id', 'o.order_number', 'o.status', 'o.total', 'o.created_at', 'o.payment_method',
                'o.payment_method_title', 'o.billing_address', 'c.name as c_name',
                'o.src_channel', 'o.src_campaign',
                // Lane OLG: the order's language, for the EN / AR badge.
                'o.locale',
                DB::raw('(SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) as items_n'),
            ], $byEmirate ? ['o.ship_emirate'] : []));

        $more = $rows->count() > self::PER_PAGE;
        $rows = $rows->take(self::PER_PAGE);

        $out = [
            'ok' => true,
            'orders' => $rows->map(fn ($o) => self::row($o))->values(),
            'next' => $more ? (int) $rows->last()->id : null,
            'today' => StoreTime::today()->format('Y-m-d'),
            'yesterday' => StoreTime::today()->subDay()->format('Y-m-d'),
        ];

        // The chip counts only with the first page: one GROUP BY over the same
        // filters, not one per status and not one per page.
        if ($grouped !== null) {
            // Lane EM: the status chips count the emirate picked; "By emirate"
            // counts the status picked -- each shows every choice while the
            // other is set.
            [$out['counts'], $out['emirates']] = self::countsByEmirate(
                $grouped,
                in_array($status, self::STATUSES, true) ? $status : null,
                $emirate,
            );
            $out['emirate'] = $emirate === null ? null : ($emirate === '' ? OrderEmirate::OTHER : $emirate);
            $out['payments'] = self::paymentMethods();
            $out['emails'] = OrdersApiController::emailingStatuses();
        } elseif ($before === 0) {
            $out['counts'] = (clone $base)->groupBy('o.status')->selectRaw('o.status as s, COUNT(*) as n')
                ->pluck('n', 's')->map(fn ($n) => (int) $n);
            $out['payments'] = self::paymentMethods();
            // Which statuses email the customer, for the bulk confirmation
            // (Lane ORD). From the admin's own answer, so the two never differ.
            $out['emails'] = OrdersApiController::emailingStatuses();
        }

        return response()->json($out);
    }

    /**
     * Lane EM: the status chips and the "By emirate" chips from one grouped
     * result of (status, emirate, n). Every emirate is listed, busiest first,
     * then Other ('' -- abroad or unreadable) and the rows not read yet.
     *
     * @param  iterable<object>  $rows
     * @return array{0: array<string,int>, 1: array{rows: list<array{key:string,code:string,orders:int}>, other:int, unread:int}}
     */
    private static function countsByEmirate(iterable $rows, ?string $status, ?string $emirate): array
    {
        $counts = [];
        $places = array_fill_keys(array_keys(OrderEmirate::CODES), 0);
        $other = 0;
        $unread = 0;

        foreach ($rows as $r) {
            $s = (string) $r->s;
            $e = $r->e === null ? null : (string) $r->e;
            $n = (int) $r->n;

            if ($emirate === null || $e === $emirate) {
                $counts[$s] = ($counts[$s] ?? 0) + $n;
            }

            if ($status === null || $s === $status) {
                if ($e === null) {
                    $unread += $n;
                } elseif (isset($places[$e])) {
                    $places[$e] += $n;
                } else {
                    $other += $n;
                }
            }
        }

        arsort($places);

        return [$counts, [
            'rows' => array_map(fn (string $k, int $n) => ['key' => $k, 'code' => OrderEmirate::CODES[$k], 'orders' => $n], array_keys($places), array_values($places)),
            'other' => $other,
            'unread' => $unread,
        ]];
    }

    /** The list's filters, shared by the rows and the counts. */
    private function filtered(Request $request): Builder
    {
        $q = DB::table('orders as o')->whereNull('o.deleted_at')->where('o.status', '!=', 'checkout-draft');

        $from = self::dayStart((string) $request->query('from', ''));
        $to = self::dayStart((string) $request->query('to', ''), 1);
        if ($from !== null) {
            $q->where('o.created_at', '>=', $from);
        }
        if ($to !== null) {
            $q->where('o.created_at', '<', $to);
        }

        $payment = trim((string) $request->query('payment', ''));
        if ($payment !== '' && preg_match('/^[a-z0-9_\-]{1,40}$/i', $payment)) {
            $q->where('o.payment_method', $payment);
        }

        $term = trim(mb_substr((string) $request->query('q', ''), 0, 80));
        if ($term !== '') {
            self::search($q, $term);
        }

        return $q;
    }

    /**
     * Number, name, email, phone or a product on the order.
     *
     * "#33447" or a bare number goes straight to the order-number index; an
     * address with @ looks at email; a run of digits also looks at phones; a
     * word looks at names (customer row and the billing name of a guest) and
     * at the order's lines, by product name or SKU.
     */
    private static function search(Builder $q, string $term): void
    {
        $plain = ltrim($term, '#');
        $like = '%'.self::escape($term).'%';

        if ($plain !== '' && ctype_digit($plain) && strlen($plain) <= 9) {
            $q->where(function (Builder $w) use ($plain) {
                $w->where('o.order_number', $plain)
                    ->orWhere('o.order_number', 'like', self::escape($plain).'%')
                    ->orWhere('o.phone', 'like', '%'.self::escape($plain).'%');
            });

            return;
        }

        $q->where(function (Builder $w) use ($like) {
            foreach (['o.email', 'o.phone', 'o.order_number', 'o.billing_address'] as $col) {
                $w->orWhereRaw($col." like ? escape '".self::LIKE_ESCAPE."'", [$like]);
            }
            $w->orWhereExists(function (Builder $c) use ($like) {
                $c->selectRaw('1')->from('customers as cs')->whereColumn('cs.id', 'o.customer_id')
                    ->where(fn (Builder $n) => $n->whereRaw("cs.name like ? escape '".self::LIKE_ESCAPE."'", [$like])
                        ->orWhereRaw("cs.phone like ? escape '".self::LIKE_ESCAPE."'", [$like]));
            });
            $w->orWhereExists(function (Builder $i) use ($like) {
                $i->selectRaw('1')->from('order_items as oi')->whereColumn('oi.order_id', 'o.id')
                    ->where(fn (Builder $n) => $n->whereRaw("oi.name like ? escape '".self::LIKE_ESCAPE."'", [$like])
                        ->orWhereRaw("oi.sku like ? escape '".self::LIKE_ESCAPE."'", [$like]));
            });
        });
    }

    /** @return array<string,mixed> */
    public static function row(object $o): array
    {
        $billing = is_string($o->billing_address ?? null) ? (json_decode($o->billing_address, true) ?: []) : (array) ($o->billing_address ?? []);
        $name = trim((string) ($o->c_name ?? ''));
        if ($name === '') {
            $name = trim(($billing['first_name'] ?? '').' '.($billing['last_name'] ?? ''));
        }

        return [
            'id' => (int) $o->id,
            'number' => (string) ($o->order_number ?: $o->id),
            'status' => (string) $o->status,
            'status_label' => OwnerAppEvents::statusWord((string) $o->status),
            'total' => (int) $o->total,
            'total_display' => Money::plain((int) $o->total),
            'name' => $name !== '' ? $name : 'Guest',
            'payment' => self::paymentKind((string) $o->payment_method),
            'payment_title' => (string) ($o->payment_method_title ?: ''),
            'created_at' => StoreTime::iso($o->created_at),
            'day' => StoreTime::dayKey($o->created_at),
            'items' => isset($o->items_n) ? (int) $o->items_n : null,
            // Lane AN: the Source chip; null where the row carried no column
            // (customer history, dashboard), so nothing is shown there.
            'source' => property_exists($o, 'src_channel') ? \App\Services\Analytics\Attribution::chip($o->src_channel, $o->src_campaign ?? null) : null,
            // Lane EM: the owner's short code (DXB, AUH, ALAIN ...); null abroad,
            // unread, or where the row carried no column (history, dashboard).
            'emirate_code' => property_exists($o, 'ship_emirate') ? OrderEmirate::code($o->ship_emirate) : null,
            // Lane OLG: 'en' / 'ar', the language the order was placed in; null
            // where the row carried no column (history, dashboard), so nothing
            // is shown there.
            'locale' => property_exists($o, 'locale') ? OrdersApiController::orderLocale($o->locale) : null,
        ];
    }

    public static function paymentKind(string $method): string
    {
        $m = strtolower($method);

        return match (true) {
            $m === 'tabby' => 'tabby',
            $m === 'tamara' => 'tamara',
            $m === 'cod' => 'cod',
            in_array($m, ['stripe', 'card', 'stripe_cc', 'apple_pay', 'google_pay'], true) => 'card',
            $m === '' => 'none',
            default => 'other',
        };
    }

    /** @return list<array{id:string,title:string}> the methods orders actually carry */
    private static function paymentMethods(): array
    {
        return DB::table('orders')->whereNotNull('payment_method')->where('payment_method', '!=', '')
            ->groupBy('payment_method')->orderBy('payment_method')->limit(12)
            ->selectRaw('payment_method as id, MAX(payment_method_title) as title')
            ->get()->map(fn ($r) => ['id' => (string) $r->id, 'title' => (string) ($r->title ?: ucfirst((string) $r->id))])->all();
    }

    /* --------------------------------------------------------------- detail */

    public function show(Request $request, int $id): JsonResponse
    {
        if ($r = $this->refuse($request, 'orders.view')) {
            return $r;
        }

        $order = Order::query()->with([
            'items:id,order_id,product_id,product_variant_id,name,sku,variant_attributes,quantity,unit_price,total',
            'items.product:id,image',
            'notes:id,order_id,author,is_customer_note,content,created_at',
            'customer:id,name,email,phone',
        ])->find($id);

        if ($order === null) {
            return response()->json(['ok' => false, 'code' => 'not_found'], 404);
        }

        $refunded = (int) DB::table('refunds')->where('order_id', $order->id)
            ->whereIn('status', \App\Services\Payments\PaymentRefunder::COUNTED)->sum('amount');

        $history = $order->customer_id
            ? DB::table('orders')->whereNull('deleted_at')->where('customer_id', $order->customer_id)
            : DB::table('orders')->whereNull('deleted_at')->where('email', (string) $order->email);
        $history = $history->selectRaw('COUNT(*) as n, SUM(CASE WHEN status IN (?,?,?,?) THEN total ELSE 0 END) as spent', Order::REAL_STATUSES)->first();

        $prev = DB::table('orders')->whereNull('deleted_at')->where('id', '<', $order->id)->where('status', '!=', 'checkout-draft')->max('id');
        $next = DB::table('orders')->whereNull('deleted_at')->where('id', '>', $order->id)->where('status', '!=', 'checkout-draft')->min('id');

        // Customise app switches (Lane OA4) fold into `can`: the app hides what
        // the server would refuse (OwnerAppUiGate).
        $mayPay = $this->may($request, 'orders.payment') && \App\Services\OwnerApp\OwnerAppUi::functionOn('mark_paid')
            && in_array((string) $order->status, OrderPaymentPanel::UNPAID_STATUSES, true);

        // Lane EM: the stored emirate, or read from the addresses while it is
        // not stored yet (or the column is not there yet). No query.
        $emirate = is_string($order->ship_emirate) ? $order->ship_emirate : OrderEmirate::read($order->shipping_address, $order->billing_address);

        return response()->json([
            'ok' => true,
            'order' => [
                'id' => (int) $order->id,
                'number' => (string) ($order->order_number ?: $order->id),
                'status' => (string) $order->status,
                'status_label' => OwnerAppEvents::statusWord((string) $order->status),
                'created_at' => self::iso($order->created_at),
                'paid_at' => self::iso($order->paid_at),
                'completed_at' => self::iso($order->completed_at),
                'email' => (string) $order->email,
                'phone' => (string) ($order->phone ?? ''),
                'billing' => self::address($order->billing_address),
                'shipping' => self::address($order->shipping_address),
                // Lane EM: stored, or read from the addresses while it is not.
                'emirate' => $emirate === '' ? null : $emirate,
                'emirate_code' => OrderEmirate::code($emirate),
                // Lane OLG: the language the order was placed in, 'en' or 'ar'.
                'locale' => OrdersApiController::orderLocale($order->locale),
                'shipping_method' => (string) ($order->shipping_method ?? ''),
                'payment' => self::payment($order),
                // (Lane TM) the Payment journey card. See App\Support\PaymentJourney.
                'payment_journey' => \App\Support\PaymentJourney::for($order),
                'customer_journey' => \App\Support\CustomerJourney::for($order),
                'emails' => \App\Support\OrderEmails::for($order),
                'items' => $order->items->map(fn ($i) => [
                    'name' => (string) $i->name,
                    'sku' => (string) ($i->sku ?? ''),
                    'variant' => self::variantText($i->variant_attributes),
                    'qty' => (int) $i->quantity,
                    'unit_display' => Money::plain((int) $i->unit_price),
                    'total_display' => Money::plain((int) $i->total),
                    'product_id' => $i->product_id === null ? null : (int) $i->product_id,
                    'thumb' => self::thumb($i->product?->image),
                ])->values(),
                'totals' => [
                    'subtotal' => Money::plain((int) $order->subtotal),
                    'discount' => (int) $order->discount_total > 0 ? Money::plain((int) $order->discount_total) : null,
                    'coupon' => (string) ($order->coupon_code ?? ''),
                    'shipping' => Money::plain((int) $order->shipping_total),
                    'fees' => (int) $order->fee_total > 0 ? Money::plain((int) $order->fee_total) : null,
                    'tax' => (int) $order->tax_total > 0 ? Money::plain((int) $order->tax_total) : null,
                    'total' => Money::plain((int) $order->total),
                    'refunded' => $refunded > 0 ? Money::plain($refunded) : null,
                ],
                'customer_note' => (string) ($order->customer_note ?? ''),
                'origin' => (string) ($order->origin ?? ''),
                'customer' => [
                    'id' => $order->customer?->id,
                    'name' => (string) ($order->customer?->name ?: trim(($order->billing_address['first_name'] ?? '').' '.($order->billing_address['last_name'] ?? ''))),
                    /*
                     * (Lane TM) The number to ring, shown as text under the
                     * name. Exactly as stored on the order: shipping, then
                     * billing, then the order's own column. Behind this
                     * endpoint's `orders.view` gate only; no /api route
                     * carries it.
                     */
                    'phone' => self::orderPhone($order),
                    'orders' => (int) ($history->n ?? 0),
                    'spent_display' => Money::plain((int) ($history->spent ?? 0)),
                ],
                'notes' => $order->notes->map(fn ($n) => self::noteRow($n))->values(),
                'prev_id' => $prev === null ? null : (int) $prev,
                'next_id' => $next === null ? null : (int) $next,
                'can' => [
                    'status' => $this->may($request, 'orders.manage'),
                    'note' => $this->may($request, 'orders.manage') && \App\Services\OwnerApp\OwnerAppUi::functionOn('order_notes'),
                    'paid' => $mayPay,
                ],
                // (Lane OL) "Send order link". Allowlisted by OrderPayLink::panel(): eligibility and
                // the last send, never the link; the ability rides here because `can` is pinned whole.
                'pay_link' => \App\Services\Orders\OrderPayLink::panel($order) + ['can' => $this->may($request, 'orders.paylink')],
                'paid_methods' => $mayPay ? app(\App\Services\Orders\ManualPayment::class)->methodsFor($order) : [],
                'settable' => self::SETTABLE,
            ],
        ]);
    }

    /* --------------------------------------------------------------- writes */

    public function bulkStatus(Request $request): JsonResponse
    {
        if ($r = $this->refuse($request, 'orders.manage')) {
            return $r;
        }

        $sub = self::subRequest($request, [
            'ids' => array_values(array_filter((array) $request->input('ids', []), 'is_numeric')),
            'status' => (string) $request->input('status', ''),
        ] + self::optional($request, ['notify', 'force']));

        $res = $this->delegate(fn () => app(OrdersApiController::class)->bulkStatus($sub));
        if ($res instanceof JsonResponse && $res->getStatusCode() !== 200) {
            return $res;
        }

        $d = $res->getData(true);

        return response()->json([
            'ok' => true,
            'status' => (string) ($d['status'] ?? ''),
            'changed' => (int) ($d['changed'] ?? 0),
            // Lane ORD: the rows move in place, and "1 already Completed" is
            // said rather than silently counted out.
            'changed_ids' => array_map('intval', (array) ($d['changed_ids'] ?? [])),
            'unchanged_ids' => array_map('intval', (array) ($d['unchanged_ids'] ?? [])),
            'skipped' => array_map(fn ($s) => [
                'id' => (int) ($s['id'] ?? 0),
                'number' => (string) ($s['label'] ?? ''),
                'reason' => (string) ($s['reason'] ?? ''),
                'forceable' => (bool) ($s['forceable'] ?? false),
            ], (array) ($d['skipped'] ?? [])),
        ]);
    }

    public function status(Request $request, int $id): JsonResponse
    {
        if ($r = $this->refuse($request, 'orders.manage')) {
            return $r;
        }

        $status = (string) $request->input('status', '');
        if (! in_array($status, self::SETTABLE, true)) {
            return response()->json(['ok' => false, 'message' => 'Choose one of the listed statuses.'], 422);
        }

        $sub = self::subRequest($request, ['status' => $status] + self::optional($request, ['notify']), 'PUT');
        $res = $this->delegate(fn () => app(AdminController::class)->updateOrderStatus($sub, $id));

        return $this->relay($res, fn ($d) => ['status' => (string) ($d['status'] ?? $status)]);
    }

    public function note(Request $request, int $id): JsonResponse
    {
        if ($r = $this->refuse($request, 'orders.manage')) {
            return $r;
        }

        $sub = self::subRequest($request, ['content' => (string) $request->input('content', '')]);
        $res = $this->delegate(fn () => app(AdminOrderController::class)->addNote($sub, $id));

        return $this->relay($res, fn ($d) => ['note' => [
            'id' => (int) ($d['note']['id'] ?? 0),
            'author' => (string) ($d['note']['author'] ?? ''),
            'customer' => false,
            'content' => (string) ($d['note']['content'] ?? ''),
            'tone' => '',
            'at' => $d['note']['created_at'] ?? null,
        ]]);
    }

    public function markPaid(Request $request, int $id): JsonResponse
    {
        if ($r = $this->refuse($request, 'orders.payment')) {
            return $r;
        }

        $sub = self::subRequest($request, [
            'payment_method' => (string) $request->input('payment_method', ''),
            'reference' => $request->input('reference'),
            'paid_at' => (string) ($request->input('paid_at') ?: StoreTime::now()->format('Y-m-d H:i:s')),
            'status' => $request->input('status'),
        ] + self::optional($request, ['notify']));

        $res = $this->delegate(fn () => app()->call([app(OrderDetailController::class), 'markPaid'], ['request' => $sub, 'id' => $id]));

        return $this->relay($res, fn ($d) => ['status' => (string) ($d['status'] ?? ''), 'message' => (string) ($d['message'] ?? '')]);
    }

    /**
     * (Lane OL) "Send order link": the admin's own OrderPayLinkController::share(),
     * after this member's capability. Only the fields the app draws go back.
     */
    public function payLink(Request $request, int $id): JsonResponse
    {
        if ($r = $this->refuse($request, 'orders.paylink')) {
            return $r;
        }

        $via = (string) $request->input('via', '');
        $sub = self::subRequest($request, ['via' => in_array($via, \App\Services\Orders\OrderPayLink::VIA, true) ? $via : '']);
        $res = $this->delegate(fn () => app(\App\Http\Controllers\Admin\OrderPayLinkController::class)->share($sub, $id));

        return $this->relay($res, fn ($d) => [
            'url' => (string) ($d['url'] ?? ''),
            'expires_label' => (string) ($d['expires_label'] ?? ''),
            'whatsapp_url' => (string) ($d['whatsapp_url'] ?? ''),
            'has_phone' => (bool) ($d['has_phone'] ?? false),
            'email' => (string) ($d['email'] ?? ''),
            'last' => isset($d['last']) && is_array($d['last']) ? [
                'via' => (string) ($d['last']['via'] ?? ''),
                'label' => (string) ($d['last']['label'] ?? ''),
                'at_label' => (string) ($d['last']['at_label'] ?? ''),
                'by' => (string) ($d['last']['by'] ?? ''),
            ] : null,
            'problems' => array_values(array_map('strval', (array) ($d['problems'] ?? []))),
            'message' => (string) ($d['message'] ?? ''),
        ]);
    }

    /* -------------------------------------------------------------- helpers */

    /**
     * A copy of the request carrying only the fields the admin method reads.
     * The member's other input never reaches it.
     */
    private static function subRequest(Request $request, array $input, string $method = 'POST'): Request
    {
        $sub = Request::create($request->getRequestUri(), $method, [], [], [], $request->server->all());
        $sub->headers->set('Accept', 'application/json');
        $sub->setJson(new \Symfony\Component\HttpFoundation\InputBag($input));
        $sub->request = new \Symfony\Component\HttpFoundation\InputBag($input);
        $sub->setUserResolver(fn () => auth('admin')->user());

        return $sub;
    }

    /** @return array<string,mixed> */
    private static function optional(Request $request, array $keys): array
    {
        $out = [];
        foreach ($keys as $k) {
            if ($request->has($k) && $request->input($k) !== null) {
                $out[$k] = (bool) $request->boolean($k);
            }
        }

        return $out;
    }

    private function delegate(\Closure $call): \Symfony\Component\HttpFoundation\Response
    {
        try {
            $res = $call();
        } catch (ValidationException $e) {
            return response()->json(['ok' => false, 'message' => collect($e->errors())->flatten()->first() ?? 'Check the form.', 'errors' => $e->errors()], 422);
        }

        return $res instanceof \Symfony\Component\HttpFoundation\Response ? $res : response()->json(['ok' => false], 500);
    }

    private function relay(\Symfony\Component\HttpFoundation\Response $res, \Closure $shape): JsonResponse
    {
        $d = $res instanceof JsonResponse ? (array) $res->getData(true) : [];

        if ($res->getStatusCode() !== 200 || (isset($d['ok']) && $d['ok'] === false)) {
            return response()->json([
                'ok' => false,
                'code' => (string) ($d['error'] ?? $d['code'] ?? 'refused'),
                'message' => (string) ($d['message'] ?? 'That did not go through.'),
            ], $res->getStatusCode() === 200 ? 422 : $res->getStatusCode());
        }

        return response()->json(['ok' => true] + $shape($d));
    }

    /**
     * How the order was paid, for the Payment card. Tabby splits a purchase in
     * four and Tamara in three (their standard plans); the shop is paid in full
     * by the provider at checkout, and the card says so. The instalment dates
     * are a month apart from the day it was paid.
     *
     * @return array<string,mixed>
     */
    private static function payment(Order $order): array
    {
        $kind = self::paymentKind((string) $order->payment_method);
        $paid = in_array((string) $order->status, OrderPaymentPanel::PAID_STATUSES, true) || $order->paid_at !== null;
        $out = ['kind' => $kind, 'title' => $order->paymentLabel(), 'paid' => $paid, 'paid_at' => self::iso($order->paid_at), 'instalments' => null];

        if ($kind === 'tabby' || $kind === 'tamara') {
            $n = $kind === 'tabby' ? 4 : 3;
            $each = intdiv((int) $order->total, $n);
            $start = StoreTime::display($order->paid_at ?? $order->created_at) ?? StoreTime::now();
            $out['instalments'] = [
                'plan' => $kind === 'tabby' ? 'Pay in 4' : 'Split in 3',
                'each_display' => Money::plain($each),
                'parts' => array_map(fn ($i) => [
                    'amount' => Money::plain($i === $n - 1 ? (int) $order->total - $each * ($n - 1) : $each),
                    'date' => $start->addMonthsNoOverflow($i)->format('j M'),
                    'done' => $paid && $i === 0,
                ], range(0, $n - 1)),
            ];
        }

        return $out;
    }

    /** One timeline entry. `tone` marks money taken (g) and things that went wrong (w). */
    private static function noteRow(object $n): array
    {
        $text = (string) $n->content;
        $tone = match (true) {
            (bool) preg_match('/fail|declin|error|refused|timeout|could not|cancel/i', $text) => 'w',
            (bool) preg_match('/captur|paid|payment (received|complete)|marked as paid/i', $text) => 'g',
            default => '',
        };

        return [
            'id' => (int) $n->id,
            'author' => (string) ($n->author ?? ''),
            'customer' => (bool) $n->is_customer_note,
            'content' => $text,
            'tone' => $tone,
            'at' => self::iso($n->created_at),
        ];
    }

    /** @return array<string,string>|null */
    private static function address(mixed $a): ?array
    {
        if (! is_array($a) || $a === []) {
            return null;
        }
        $pick = static fn (string $k) => trim((string) ($a[$k] ?? ''));

        return [
            'name' => trim($pick('first_name').' '.$pick('last_name')),
            'company' => $pick('company'),
            'line1' => $pick('line1') ?: $pick('address_1'),
            'line2' => $pick('line2') ?: $pick('address_2'),
            'city' => $pick('city'),
            'state' => $pick('state'),
            'country' => \App\Support\Countries::NAMES[strtoupper($pick('country'))] ?? $pick('country'),
            'phone' => $pick('phone'),
        ];
    }

    /** The order's phone as stored: shipping, then billing, then orders.phone. */
    private static function orderPhone(Order $order): string
    {
        foreach ([$order->shipping_address, $order->billing_address] as $addr) {
            $p = is_array($addr) ? trim((string) ($addr['phone'] ?? '')) : '';

            if ($p !== '') {
                return $p;
            }
        }

        return trim((string) ($order->phone ?? ''));
    }

    private static function variantText(mixed $attrs): string
    {
        if (is_string($attrs)) {
            $attrs = json_decode($attrs, true);
        }
        if (! is_array($attrs)) {
            return '';
        }

        $parts = [];
        foreach ($attrs as $k => $v) {
            if (is_scalar($v) && trim((string) $v) !== '') {
                $parts[] = (is_string($k) ? ucfirst(str_replace(['attribute_pa_', 'pa_', '_', '-'], ['', '', ' ', ' '], $k)).': ' : '').$v;
            }
        }

        return implode(' · ', $parts);
    }

    public static function thumb(?string $image): ?string
    {
        $image = trim((string) $image);

        return $image === '' ? null : ImageVariants::variantUrl($image, 200);
    }

    private static function escape(string $s): string
    {
        return str_replace([self::LIKE_ESCAPE, '%', '_'], [self::LIKE_ESCAPE.self::LIKE_ESCAPE, self::LIKE_ESCAPE.'%', self::LIKE_ESCAPE.'_'], $s);
    }

    private static function dayStart(string $day, int $plusDays = 0): ?CarbonImmutable
    {
        if (! preg_match('/^\d{4}-\d{2}-\d{2}$/', $day)) {
            return null;
        }
        try {
            return CarbonImmutable::createFromFormat('Y-m-d', $day, StoreTime::timezone())->startOfDay()->addDays($plusDays)->utc();
        } catch (\Throwable) {
            return null;
        }
    }
}
