@extends('layouts.store')
@php use App\Support\Url; $pageTitle = \App\Support\PageTitle::decoded($page->t('title')); @endphp

@section('title', __('store.page.page_title', ['title' => $pageTitle]))
{{-- The page header in the brand page's design (Lane PH): its stylesheet, only when the page draws it. At column 0 and on this comment's line, so a page on "Normal page banner" renders byte for byte as before. --}}@if (! empty($pagePanel))
@push('styles')
@include('store.partials.page-panel-head')
@endpush
@endif

@section('content')
<div class="kbb-home">
{{-- The top of the page (Lane SP3): the header area and the strip in the owner's order; the breadcrumb is inside the header. Null = the original markup below, byte for byte. The title is the admin's own HTML, printed raw as it always was. --}}@if (! empty($pageTop))
@include('partials.page-top', ['ph' => ['home' => Url::to('/'), 'crumb' => new \Illuminate\Support\HtmlString($page->t('title')), 'title' => new \Illuminate\Support\HtmlString($page->t('title'))]])
@endif
<section class="sec"><div class="wrap">
@if (empty($pageTop))
    <nav class="crumb"><a href="{{ Url::to('/') }}">{{ __('store.breadcrumb.home') }}</a> / <span>{!! $page->t('title') !!}</span></nav>
@endif
{{-- Lane PH: the brand page's header, under the breadcrumb, carrying the page's one <h1> (BrandPanel::forPage). The same partial a brand and a category draw; `panelCategory` picks its category branch -- the words from $panel, the picture with its img-cache srcset. --}}@if (! empty($pagePanel))
<div class="kbb-cbw">
@include('store.partials.brand-panel', ['panel' => $pagePanel, 'panelCategory' => $page])
</div>
@endif

    <article class="policy">
@if (empty($pageTop) && empty($pagePanel))
        <h1>{!! $page->t('title') !!}</h1>
@endif
{{-- The contact page's cards (Lane CT), under the page's title whichever header draws it: only /contact-us/ has a $contactHub, so every other page renders byte for byte as before. The page's own stylesheet rides along, inline, from here. --}}@if (! empty($contactHub))
@push('styles')
@include('store.partials.contact-hub-head')
@endpush
@include('store.partials.contact-hub-cards', ['hub' => $contactHub])
@endif
        {{-- Content is authored in the admin, so it is trusted HTML.

             @shortcodes, not {!! !!}. AppServiceProvider has registered this
             directive since the Phase 0 baseline, with the comment "renders
             [kbb_products ...] anywhere: pages, posts, HTML blocks" — and no
             view in this repo had ever used it, so a shortcode written into a
             page was printed to the shopper verbatim, brackets and all. That
             is checked, not assumed: `@shortcodes` and `Shortcodes::render`
             appear nowhere under resources/views at the tip this lane branched
             from. Content -> HTML Blocks is the screen that makes writing one
             easy, so this is the line that has to mean something first. --}}
        {{-- BodyHeadings::demoteH1 wraps the shortcode expansion rather than
             the raw column, because a [kbb_block] can itself carry an h1. The
             <h1> above is this page's own. See App\Support\BodyHeadings.

             t(), not the column. `content` is one of
             TranslationStore::LONG_FIELDS — deliberately not in the map every
             Arabic page loads, and read by the one page that prints it. --}}
        <div class="policy-body">{!! \App\Support\DescriptionGallery::expand(\App\Support\BodyHeadings::demoteH1(\App\Support\Shortcodes::render($page->t('content')))) !!}</div>

        @if ($page->updated_at)
            <p class="policy-date">{{ __('store.page.last_updated', ['date' => (class_exists(\App\Support\LocalDate::class) ? \App\Support\LocalDate::format($page->updated_at, 'j F Y') : (($kbbD = $page->updated_at) ? $kbbD->format('j F Y') : ''))]) }}</p>
        @endif
    </article>
{{-- The inquiry form, the social icons and the opening hours (Lane CT). --}}@if (! empty($contactHub))
@include('store.partials.contact-hub-form', ['hub' => $contactHub])
@endif
</div></section>
</div>
@endsection
