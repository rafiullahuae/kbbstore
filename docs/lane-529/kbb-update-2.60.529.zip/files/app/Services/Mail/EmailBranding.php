<?php

declare(strict_types=1);

namespace App\Services\Mail;

use App\Services\HeaderSettings;
use App\Services\SettingsService;
use App\Support\Url;

/**
 * The store's own face, as an order email prints it.
 *
 * The owner asked for two things that both land here: the confirmation should
 * feel "a little bit colourful, joyful/happy about skincare", and it should
 * "focus more on support by showing our WhatsApp, email, Instagram etc, so the
 * user will feel more trust and comfort". A support block is a promise — chat
 * to us here, write to us there — so every value in it is a real business fact
 * read from settings, and NOTHING in this file or in any template is a
 * hardcoded number or handle. A receipt advertising a WhatsApp number nobody
 * answers does the opposite of building trust.
 *
 * WHERE EACH VALUE COMES FROM, and in what order:
 *
 *   WhatsApp   Store → Mail, else `brand_whatsapp` (the footer and the phone
 *              menu already use it), else `whatsapp` (the header block).
 *   Email      Store → Mail's support email, else the Reply-To address, else
 *              the From address AS TYPED. Never the `no-reply@<domain>` that
 *              MailSettings::fromAddress() derives from APP_URL when the From
 *              box is blank — see support() for the measurement.
 *   Instagram  Store → Mail, else `social_instagram` from Store → Business
 *              Details, which is where the SEO screen already saves it.
 *   Logo       `org_logo`, the one logo image this store keeps — the same file
 *              the schema.org Organization block publishes. A second upload
 *              would mean two logos to keep in step and one of them wrong.
 *   Wordmark   `logo_text` + `logo_accent` from Header settings, so an email
 *              signs itself with the same two words as the site header.
 *
 * A channel with no value anywhere is simply not printed. There is no
 * placeholder and no "coming soon" — an empty row in a support block is worse
 * than a shorter block.
 *
 * NOTHING HERE IS ESCAPED, and that is deliberate and matches
 * OrderEmailPresenter: escaping belongs at the point of output, where Blade's
 * {{ }} does it in the HTML parts, and a pre-escaped string would render as a
 * literal &amp;amp; in the text parts. The one thing this class does sanitise is
 * the logo URL, because a `src` attribute is not a text node — see logoUrl().
 */
class EmailBranding
{
    /**
     * The module switch for the logo, and the reason it is a module.
     *
     * Store → Mail's form has exactly three field types (text, secret, and a
     * choice whose options come from MailApiController::optionsFor — a file this
     * lane does not own). There is no checkbox, so an on/off that lived in
     * MailSettings::SCHEMA would render as a text box the owner had to type
     * "yes" into. Store → Modules already renders real switches, already has an
     * "Order emails" group holding the five email toggles, and is already the
     * screen the owner knows for turning a piece of an email on and off.
     */
    public const LOGO_MODULE = 'email_show_logo';

    /**
     * The palette, taken from the storefront's own :root block in
     * resources/css/kbb/kbb.css rather than invented here.
     *
     * Named so a template never carries a bare hex, and so the next person can
     * see at a glance that these are the site's colours and not a designer's
     * mood. Restrained on purpose: two pinks, a cream and the site's ink. The
     * owner asked for "a little bit colourful", which is not a licence for a
     * rainbow in a document somebody reads to check what they were charged.
     *
     * Every one is a flat colour. Gradients, shadows and rounded corners are
     * dropped by Outlook's Word renderer without a fallback, so nothing here
     * depends on one to stay legible.
     */
    public const PALETTE = [
        'cream' => '#FFF8F5',
        'pinkSoft' => '#FFF0F4',
        'blush' => '#FCE0E8',
        'pink' => '#E0567B',
        'pinkDeep' => '#C13E63',
        'ink' => '#2A2228',
        'ink2' => '#5E545A',
        'muted' => '#8C828A',
        'line' => '#F0E4E9',
        'green' => '#2E9E6B',
        'white' => '#FFFFFF',
    ];

    public function __construct(
        private SettingsService $settings,
        private MailSettings $mail,
        private HeaderSettings $header,
    ) {}

    /**
     * Everything the templates print, decided once.
     *
     * @return array<string, mixed>
     */
    /**
     * The branding array a Mailable needs, with the failure already handled.
     *
     * Every mailable that renders `emails.layout` needs a `$brand`, and the
     * layout reads its wordmark, its colours and its support block straight out
     * of it -- so a mailable that does not build one renders a masthead with no
     * store name in it. That is not hypothetical: OrderInvoice extends Mailable
     * directly rather than OrderMail, and the moment the layout grew a branded
     * masthead its invoice email started going out with an empty wordmark,
     * which is what this method exists to make impossible to repeat.
     *
     * The try/catch is the same contract OrderMail already had and the reason
     * this is a method rather than a constructor call: branding is decoration,
     * and decoration that throws must never be why a customer hears silence
     * about an order they paid for. The failure is logged rather than swallowed
     * -- a silent catch is how a broken support block becomes an email that
     * goes out for months looking slightly wrong with nobody able to say why.
     *
     * @return array<string, mixed>
     */
    public static function forMailable(bool $customerFacing, string $mailable): array
    {
        try {
            /*
             * Resolved from the container rather than newed up: this class
             * reads SettingsService, MailSettings and HeaderSettings, all bound
             * scoped so one request shares one decrypted credential row and one
             * settings snapshot. Newing it here would build a second set.
             */
            return app(self::class)->present($customerFacing);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning(
                'order email branding failed; falling back to the plain header',
                [
                    'mailable' => $mailable,
                    'exception' => class_basename($e),
                    'message' => $e->getMessage(),
                ]
            );

            $name = \App\Support\BrandName::appName();

            return [
                'customerFacing' => $customerFacing,
                'storeName' => $name,
                'wordmark' => [$name, ''],
                'logoUrl' => null,
                'support' => [],
                'hasSupport' => false,
                'signature' => [],
                // No address means no invitation to reply. The safe answer when
                // branding could not be read is the one that promises nothing.
                'replyTo' => '',
                'addresses' => [],
                'colours' => self::PALETTE,
            ];
        }
    }

    public function present(bool $customerFacing = true): array
    {
        $support = $customerFacing ? $this->support() : [];

        return [
            'customerFacing' => $customerFacing,
            'storeName' => $this->storeName(),
            'wordmark' => $this->wordmark(),
            'logoUrl' => $this->logoUrl(),
            'support' => $support,
            'hasSupport' => $support !== [],
            'signature' => $customerFacing ? $this->signature() : [],
            /*
             * WHETHER THE FOOTER MAY INVITE A REPLY.
             *
             * The layout used to invite one unconditionally, and the audit lane
             * removed the sentence because nothing in this application set a
             * Reply-To: the reply went to the From address, which is
             * `no-reply@<domain>` on an install that has left the From box
             * empty — the shipped state. MailSettings::replyToAddress() answers
             * '' until the owner enters an address, and the sentence is printed
             * only when it does not.
             *
             * The address itself, not a boolean, so the template can name it if
             * it ever wants to and so a test can read back what was configured.
             *
             * CUSTOMER-FACING ONLY. The merchant's new-order alert goes to the
             * person who packs the boxes, and telling him he may reply to
             * himself is the same nonsense as telling him an order was placed
             * using his email address — which the footer already declines to do.
             */
            'replyTo' => $customerFacing ? $this->mail->replyToAddress() : '',
            'addresses' => $customerFacing ? $this->addresses() : [],
            // Fonts and brand colours (Lane RK). Stored for the Look A
            // restyle; no template reads this key yet.
            'look' => $this->look(),
            // The small print's data for the restyle (Lane RK): addresses,
            // legal links, unsubscribe. No template reads this key yet.
            'footer' => $customerFacing ? $this->footer() : [],
            'colours' => self::PALETTE,
        ];
    }

    /** The store's name, for the wordmark fallback and the signature. */
    public function storeName(): string
    {
        $name = trim((string) ($this->settings->get('store_name', '') ?? ''));

        return $name !== '' ? $name : \App\Support\BrandName::appName();
    }

    /**
     * The two-part wordmark the site header shows, as [ink half, accent half].
     *
     * Printed when there is no logo image, and beside it when there is not
     * enough room for one. Read from Header settings so the email and the site
     * cannot drift apart.
     *
     * @return array{0:string,1:string}
     */
    public function wordmark(): array
    {
        $text = trim((string) ($this->header->get('logo_text') ?? ''));
        $accent = trim((string) ($this->header->get('logo_accent') ?? ''));

        if ($text === '' && $accent === '') {
            return [$this->storeName(), ''];
        }

        return [$text, $accent];
    }

    /**
     * The store logo, absolute, or null.
     *
     * Null whenever the switch is off or no logo has been uploaded — which is
     * the ordinary case and not an error. A broken image in a receipt reads as a
     * broken store, so nothing is printed rather than an <img> that 404s.
     *
     * ABSOLUTE, ALWAYS. A mail client has no origin to resolve "/img/logo.png"
     * against; a site-relative src arrives as a dead image in every one of them.
     *
     * AND http(s) ONLY. This is operator input arriving in an attribute rather
     * than a text node, so Blade's {{ }} is not the whole answer: it escapes the
     * quotes but would happily print a `javascript:` or `data:` src. Anything
     * that is not a plain http(s) URL or a site path is dropped.
     */
    public function logoUrl(): ?string
    {
        // Literal key: Phase3ModuleSwitchesTest greps the source for exactly
        // this call to prove the registry's `live` status is not a claim.
        if (! $this->settings->moduleEnabled('email_show_logo', true)) {
            return null;
        }

        // The email's own logo (Emails → Design & branding, Lane RK) first,
        // re-checked on the way out; then Store → Business Details' org_logo.
        $raw = (string) (EmailLook::clean(EmailLook::LOGO, $this->settings->get(EmailLook::LOGO, '')) ?? '');

        if ($raw === '') {
            $raw = trim((string) ($this->settings->get('org_logo', '') ?? ''));
        }

        if ($raw === '') {
            return null;
        }

        if (preg_match('#^https?://#i', $raw) === 1) {
            return $raw;
        }

        // A site path, the shape the media library stores. Anything else — a
        // scheme we did not name, a bare word — is not a logo.
        if (str_starts_with($raw, '/')) {
            return Url::external($raw);
        }

        return null;
    }

    /**
     * The support channels, in the order the owner listed them.
     *
     * @return list<array{kind:string,label:string,value:string,url:string}>
     */
    public function support(): array
    {
        $out = [];

        $whatsapp = $this->firstFilled([
            $this->mail->get('mail_support_whatsapp'),
            (string) ($this->settings->get('brand_whatsapp', '') ?? ''),
            (string) ($this->settings->get('whatsapp', '') ?? ''),
        ]);

        if ($whatsapp !== '') {
            $digits = preg_replace('/\D+/', '', $whatsapp) ?? '';

            if ($digits !== '') {
                $out[] = [
                    'kind' => 'whatsapp',
                    'label' => 'WhatsApp',
                    'value' => $whatsapp,
                    'url' => 'https://wa.me/' . $digits,
                ];
            }
        }

        /*
         * ── "EMAIL US · no-reply@…" — Lane DG ───────────────────────────────
         *
         * This chain ended in $this->mail->fromAddress(), and fromAddress()
         * DERIVES `no-reply@<domain>` from APP_URL whenever the From box is
         * empty — which is the shipped state of Store → Mail, deliberately,
         * because the server transport needs nothing filled in.
         *
         * MEASURED, not read off the code, because on the test box APP_URL has
         * no dot and fromAddress() returns '' — so the whole defect is
         * invisible to this suite unless APP_URL is set to a real domain first.
         * With `https://kbeautybliss.com` and nothing else configured, the
         * support block rendered, verbatim:
         *
         *     Email us   no-reply@kbeautybliss.com
         *     <a href="mailto:no-reply@kbeautybliss.com">no-reply@kbeautybliss.com</a>
         *
         * A block headed "We are here if you need us", inviting a customer to
         * write, with a live mailto: to a mailbox named for not being read.
         * That is the same claim the footer's "reply to this message" sentence
         * was removed for — the invitation was taken out of the layout and left
         * standing two rows above it.
         *
         * WORSE, AND THIS IS WHAT DECIDED THE SHAPE OF THE FIX: setting
         * `mail_reply_to` did not help. The owner naming the mailbox he
         * actually reads, in the box whose own help text says "Where a
         * customer's reply to an order email goes", still printed
         * no-reply@kbeautybliss.com under "Email us".
         *
         * So two changes, and they answer different states:
         *
         *   `mail_reply_to` JOINS THE CHAIN, second. It is a real mailbox the
         *       owner named for this exact purpose, it is already validated on
         *       the way in and again on the way out, and preferring it is
         *       strictly better than printing nothing.
         *
         *   THE DERIVED ADDRESS LEAVES IT. `get('mail_from_address')` is the
         *       address the owner TYPED; fromAddress() is that value OR a
         *       no-reply@ synthesised from APP_URL. Reading the stored row
         *       keeps every shop that typed a From address exactly as it was
         *       and drops only the synthesised one — which is not a mailbox
         *       anybody chose and not one anybody answers.
         *
         * Showing nothing is the right answer in that last case rather than a
         * softer label: this file's own header says a channel with no value is
         * simply not printed, because an empty row in a support block is worse
         * than a shorter block. An address nobody reads is an empty row that
         * looks full.
         *
         * A SHOP THAT HAS SET A REAL SUPPORT EMAIL IS UNAFFECTED — that value
         * is still first and nothing below it is consulted.
         */
        $email = $this->firstFilled([
            $this->mail->get('mail_support_email'),
            $this->mail->replyToAddress(),
            $this->mail->get('mail_from_address'),
        ]);

        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false) {
            $out[] = [
                'kind' => 'email',
                // Keyed (Lane AE): the one English label in an Arabic help box.
                'label' => (string) __('email.kit.help_email_label'),
                'value' => $email,
                'url' => 'mailto:' . $email,
            ];
        }

        $instagram = $this->firstFilled([
            $this->mail->get('mail_support_instagram'),
            (string) ($this->settings->get('social_instagram', '') ?? ''),
        ]);

        if ($instagram !== '') {
            $handle = $this->instagramHandle($instagram);

            if ($handle !== '') {
                $out[] = [
                    'kind' => 'instagram',
                    'label' => 'Instagram',
                    'value' => '@' . $handle,
                    'url' => 'https://www.instagram.com/' . $handle . '/',
                ];
            }
        }

        return $out;
    }

    /**
     * The owner's sign-off, as lines.
     *
     * Lines rather than one string, because the HTML part has to turn a break
     * into a <br> and the text part into a newline, and the only safe way to do
     * that is to split here and let each template join with {{ }} around every
     * piece. Handing a template one string containing "<br>" would mean either
     * an unescaped signature — operator input rendered as markup, which is the
     * hole this project has already patched twice — or a literal "&lt;br&gt;".
     *
     * A pipe is the break character because Store → Mail's fields are
     * single-line inputs (MailApiController renders `text` as <input type=text>)
     * and the owner cannot type a newline into one. Real newlines are honoured
     * too, for a value that arrived from anywhere else.
     *
     * @return list<string>
     */
    /**
     * The shop's two addresses, for the small print (Lane RK, package E1).
     *
     * "we have two addresses, one in dubai, one in Korea ... allow us to
     * change these details anytime." Set under Emails → Design & branding.
     *
     * Each entry is ['place' => 'dubai'|'korea', 'lines' => string[]]. Lines
     * are split on | or a newline, exactly as the signature is, and handed to
     * the template as an array so it supplies the line breaks and escapes
     * every line -- operator text never reaches the email as markup.
     *
     * NEITHER HAS A FALLBACK (Lane EM, at the owner's word): "the Dubai and
     * Korea addresses are not known yet ... hide each one while it is empty.
     * Never invent an address." Dubai used to fall back to Store → Business
     * Details' street and city, which printed an address under "Dubai" that
     * nobody had typed into the Dubai box -- for a shop whose registered
     * address is not its Dubai pickup point, a wrong address on every receipt.
     * Each place now prints only once somebody types it on Emails → Design &
     * branding → Footer addresses.
     *
     * @return list<array{place: string, lines: list<string>}>
     */
    public function addresses(): array
    {
        $out = [];

        $dubai = $this->lines($this->mail->get('mail_address_dubai'));

        if ($dubai !== []) {
            $out[] = ['place' => 'dubai', 'lines' => $dubai];
        }

        $korea = $this->lines($this->mail->get('mail_address_korea'));

        if ($korea !== []) {
            $out[] = ['place' => 'korea', 'lines' => $korea];
        }

        return $out;
    }

    /** @return list<string> */
    private function lines(string $raw): array
    {
        $parts = preg_split('/\s*[|\r\n]+\s*/', trim($raw)) ?: [];

        return array_values(array_filter(
            array_map(static fn ($line) => trim((string) $line), $parts),
            static fn (string $line) => $line !== '',
        ));
    }

    /**
     * The pages the bottom footer links to: the shop's real routes
     * (routes/web.php), with the trailing slash the storefront links with.
     */
    public const FOOTER_LINKS = [
        'terms' => ['Terms & conditions', '/terms-and-conditions/'],
        'privacy' => ['Privacy policy', '/privacy-policy/'],
        // NO returns link (Lane EM, at the owner's word): the shop does not
        // offer returns, and a footer link to a returns policy promises one.
    ];

    /**
     * WHAT THE VERY BOTTOM FOOTER CARRIES (Lane RK, at the owner's word):
     *
     *   "in very bottom footer, don't include phone email, what is repeated in
     *    in the questions? box. just keep address, terms pages, un-subscribe
     *    option etc."
     *
     * So: the two addresses, the two legal pages, and the unsubscribe —
     * and NOT WhatsApp, email or Instagram, which belong to the "Questions?"
     * help box (support() above). Data only: the Look A restyle draws it.
     *
     * `unsubscribe` is null here on purpose. A transactional email (an order
     * receipt) carries no unsubscribe; a marketing email gets a per-recipient
     * one-click link from the E3 campaign sender, which is the only thing
     * that can sign it. The key exists so the template has one place to look.
     *
     * @return array{addresses: list<array{place: string, lines: list<string>}>, links: list<array{kind: string, label: string, url: string}>, unsubscribe: ?string}
     */
    public function footer(): array
    {
        $links = [];

        foreach (self::FOOTER_LINKS as $kind => [$label, $path]) {
            $links[] = ['kind' => $kind, 'label' => $label, 'url' => Url::external($path)];
        }

        return [
            'addresses' => $this->addresses(),
            'links' => $links,
            'unsubscribe' => null,
        ];
    }

    /** See EmailLook: the chosen fonts, colours and the @font-face rule. */
    public function look(): array
    {
        return app(EmailLook::class)->present();
    }

    public function signature(): array
    {
        /*
         * IN THE EMAIL'S LANGUAGE (Lane AE). An Arabic order's email signed off
         * "With love, / the K-Beauty Bliss UAE team" under an Arabic body.
         * Arabic reads the owner's Arabic box (Emails -> Design & branding ->
         * Footer of every email -> Signature — Arabic) and, when that is blank,
         * the built-in Arabic sign-off -- never his English one, which is the
         * line this fixes. English is untouched, byte for byte.
         */
        if (\App\Support\Locale::current() !== \App\Support\Locale::DEFAULT) {
            $raw = trim($this->mail->get('mail_signature_ar'));

            if ($raw === '') {
                return [
                    (string) __('email.kit.signoff_love'),
                    (string) __('email.kit.signoff_team', ['store' => \App\Support\ArabicWording::of($this->storeName())]),
                ];
            }

            return $this->signatureLines($raw);
        }

        $raw = trim($this->mail->get('mail_signature'));

        if ($raw === '') {
            return ['With love,', 'the ' . $this->storeName() . ' team'];
        }

        return $this->signatureLines($raw);
    }

    /** @return list<string> */
    private function signatureLines(string $raw): array
    {
        $lines = preg_split('/\s*[|\r\n]+\s*/', $raw) ?: [];

        $lines = array_values(array_filter(
            array_map(static fn ($line) => trim((string) $line), $lines),
            static fn (string $line) => $line !== '',
        ));

        return $lines === [] ? [$this->storeName()] : $lines;
    }

    /** @param list<string> $candidates */
    private function firstFilled(array $candidates): string
    {
        foreach ($candidates as $candidate) {
            $candidate = trim($candidate);

            if ($candidate !== '') {
                return $candidate;
            }
        }

        return '';
    }

    /**
     * "@kbeauty.bliss", "kbeauty.bliss" and
     * "https://www.instagram.com/kbeauty.bliss/" all reduced to the handle.
     *
     * Reduced rather than passed through, so the block can print the handle and
     * link to the profile whichever form the owner typed — and so a stray query
     * string or tracking parameter on a pasted URL does not end up on the page.
     */
    private function instagramHandle(string $value): string
    {
        // A tilde delimiter, not a hash: the character class has to exclude a
        // literal # (the fragment marker on a pasted profile URL), and a # inside
        // a #-delimited pattern ends the pattern.
        if (preg_match('~instagram\.com/([^/?#\s]+)~i', $value, $m) === 1) {
            $value = $m[1];
        }

        $value = ltrim(trim($value), '@');

        return preg_match('/^[A-Za-z0-9._]{1,30}$/', $value) === 1 ? $value : '';
    }
}
