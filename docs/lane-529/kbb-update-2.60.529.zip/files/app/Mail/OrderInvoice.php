<?php

declare(strict_types=1);

namespace App\Mail;

use App\Models\Order;
use App\Services\Invoices\InvoiceDocument;
use App\Services\Mail\EmailBranding;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;

/**
 * "Here is your invoice" — sent by the owner, on purpose, from the order screen.
 *
 * NOT ONE OF THE FOUR AUTOMATIC ORDER EMAILS, and deliberately not a subclass of
 * OrderMail. Those four render OrderEmailPresenter, which describes an order as a
 * receipt describes it. This one renders InvoiceDocument, which describes the same
 * order as an accounting document does — with an invoice number, an issue date and
 * the seller's own business details on it — and there must be exactly one
 * definition of that, shared with the printable page, or the emailed invoice and
 * the printed one can quietly disagree.
 *
 * NOT QUEUED, like every other mail in this app. There is no queue worker on this
 * host; a queued Mailable would be written to the jobs table and never sent, which
 * looks like success and is not. See OrderMail's header.
 *
 * THE INVOICE IS THE BODY, NOT AN ATTACHMENT. There is no PDF to attach — the
 * host cannot carry a PDF library through the updater (InvoiceController explains
 * why) — and an .html attachment is the kind of thing mail filters strip, quarantine
 * or refuse to preview on a phone. Rendered inline it is legible everywhere, it
 * prints from the mail client, and there is nothing to fail to open.
 *
 * THE SUBJECT CARRIES THE INVOICE NUMBER AND THE ORDER NUMBER AND NOTHING ELSE.
 * No total, no link, no token: subjects are quoted in notification previews, in
 * shared screenshots and in every mail server's log along the way.
 */
class OrderInvoice extends Mailable
{
    use BrandedSubject;

    /** @var array<string, mixed> */
    public array $doc;

    /**
     * Branding for `emails.layout`, which this template extends.
     *
     * Not inherited: this mailable extends Mailable directly rather than
     * OrderMail, because an invoice is not an order-status email and does not
     * carry an OrderEmailPresenter payload. That is fine right up until the
     * shared layout grows something every mailable must supply -- which is what
     * happened when it gained a branded masthead, and this email went out with
     * an empty store name in it until the array below was added.
     *
     * TRUE, because this one is read by the customer: it prints the support
     * block and the sign-off, unlike the merchant alert.
     *
     * @var array<string, mixed>
     */
    public array $brand;

    public function __construct(Order $order)
    {
        $this->doc = app(InvoiceDocument::class)->present($order);
        $this->brand = EmailBranding::forMailable(true, class_basename(static::class));
    }

    public function envelope(): Envelope
    {
        $reference = (string) $this->doc['invoiceReference'];

        $store = $this->brandName();

        return new Envelope(
            // Keyed (Lane AE), the English word for word what it was.
            subject: $reference !== ''
                ? (string) __('email.invoice.subject_ref', ['reference' => $reference, 'store' => $store, 'number' => (string) $this->doc['orderNumber']])
                : (string) __('email.invoice.subject', ['store' => $store, 'number' => (string) $this->doc['orderNumber']]),
        );
    }

    public function content(): Content
    {
        return new Content(
            view: 'emails.order-invoice',
            text: 'emails.order-invoice-text',
            // The <title> of the look-A document: the subject (Lane EM).
            with: ['kitTitle' => (string) $this->envelope()->subject],
        );
    }
}
