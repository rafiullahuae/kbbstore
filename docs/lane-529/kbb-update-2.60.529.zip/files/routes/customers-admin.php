<?php

declare(strict_types=1);

/*
|------------------------------------------------------------------------------
| Store → Customers  (Lane T)
|------------------------------------------------------------------------------
|
| WIRED. This file is required from routes/web.php (or routes/api.php) and
| its routes serve live traffic. The wiring note below is kept as the
| record of where that require belongs.
|
| CLAUDE.md forbade this lane from editing routes/web.php, so the
| file shipped unmounted and the integrator added ONE line, inside the EXISTING
| admin-api group in routes/web.php — the group that already carries
| `auth:admin` and NoStoreAdminApi — beside the other requires:
|
|     Route::prefix('admin-api')->middleware(\App\Http\Middleware\NoStoreAdminApi::class)->group(function () {
|         ...
|         require __DIR__.'/customers-admin.php';
|     });
|
| THAT GROUP, AND NOTHING ELSE. Everything below reads and writes personal data
| for every shopper the store has — name, email, phone, home city, order history
| — and /customers/export hands the whole filtered list over as a file in one
| request. Mounted outside `auth:admin` this is a customer-database leak with a
| download button on it, and /api/* in this app is unauthenticated by design, so
| it must never be mounted there. AdminCustomersTest asserts the refusal on
| every route below, mounted exactly as this header describes.
|
| Routes added:
|
|     GET    /admin-api/customers/list          the paginated, filtered list
|     GET    /admin-api/customers/export        CSV of the CURRENT filtered view
|     GET    /admin-api/customers/{id}          one customer: orders, addresses
|     POST   /admin-api/customers/{id}/note     the owner's private note
|     POST   /admin-api/customers/{id}/restore  undo a trashing
|     POST   /admin-api/customers/bulk-delete   trash a selection (guarded)
|     DELETE /admin-api/customers/{id}          trash one (guarded)
|
| WHY /list AND NOT /customers. routes/web.php already registers
| `GET /admin-api/customers` → AdminController@customers, the old unpaginated
| endpoint this screen replaces. Laravel matches the first route registered, so
| a second `GET admin-api/customers` here would silently never be reached and
| the new screen would keep rendering the old broken payload. Naming the list
| endpoint /customers/list means these coexist with no ordering hazard and no
| edit to a file this lane does not own.
|
| The old route is now dead code — nothing in the admin console calls it — and
| can be deleted from routes/web.php whenever the integrator likes, together
| with AdminController::customers(). It is left alone here deliberately: it is
| admin-gated, so leaving it costs nothing but a method, and removing a route
| someone else may still be pointing at is not this lane's call to make.
|
| The literal segments are registered before the {id} route so that /list and
| /export are never swallowed by it; whereNumber() on {id} makes that explicit
| rather than order-dependent.
|
*/

use App\Http\Controllers\Admin\CustomerInvitesController;
use App\Http\Controllers\Admin\CustomersApiController;
use Illuminate\Support\Facades\Route;

Route::get('/customers/list', [CustomersApiController::class, 'index']);
Route::get('/customers/export', [CustomersApiController::class, 'export']);

Route::post('/customers/bulk-delete', [CustomersApiController::class, 'bulkDestroy']);

/*
|------------------------------------------------------------------------------
| Send account invite (Lane PQ)
|------------------------------------------------------------------------------
|
| Added to THIS file rather than a new one so that no require line has to be
| added to routes/web.php: this file is already mounted inside the admin-api
| group, which is exactly where these belong — they email every guest the shop
| has, so being outside `auth:admin` would make this an open mail cannon.
|
|     GET  /admin-api/customers/invites/template         the saved wording
|     POST /admin-api/customers/invites/template         save it (refused without {set_password_link})
|     POST /admin-api/customers/invites/prepare          counts for a selection
|     POST /admin-api/customers/invites/preview          the real email, rendered
|     POST /admin-api/customers/invites/send             create a run
|     GET  /admin-api/customers/invites/runs/current     the unfinished run, if any
|     GET  /admin-api/customers/invites/runs/{run}       progress + failure reasons
|     POST /admin-api/customers/invites/runs/{run}/step  send the next batch
|     POST /admin-api/customers/invites/runs/{run}/cancel
|
| All of them `customers.invite` (owner, manager) in AdminCapabilities::RULES.
| Registered before /customers/{id}; the two-segment paths could not match it
| anyway, and whereNumber() on {id} makes that explicit.
*/
Route::get('/customers/invites/template', [CustomerInvitesController::class, 'template']);
Route::post('/customers/invites/template', [CustomerInvitesController::class, 'saveTemplate']);
Route::post('/customers/invites/prepare', [CustomerInvitesController::class, 'prepare']);
Route::post('/customers/invites/preview', [CustomerInvitesController::class, 'preview'])->middleware('throttle:120,1');
Route::post('/customers/invites/send', [CustomerInvitesController::class, 'send'])->middleware('throttle:10,1');
Route::get('/customers/invites/runs/current', [CustomerInvitesController::class, 'current']);
Route::get('/customers/invites/runs/{run}', [CustomerInvitesController::class, 'show'])->whereNumber('run');
Route::post('/customers/invites/runs/{run}/step', [CustomerInvitesController::class, 'step'])->whereNumber('run');
Route::post('/customers/invites/runs/{run}/cancel', [CustomerInvitesController::class, 'cancel'])->whereNumber('run');

Route::get('/customers/{id}', [CustomersApiController::class, 'show'])->whereNumber('id');
Route::post('/customers/{id}/note', [CustomersApiController::class, 'saveNote'])->whereNumber('id');
// Lane AE: the customer's language (Arabic / English / Automatic). Its own
// capability, customers.language, in AdminCapabilities.
Route::post('/customers/{id}/language', [\App\Http\Controllers\Admin\CustomerLanguageController::class, 'update'])
    ->whereNumber('id')
    ->middleware('throttle:30,1,customer-language');
Route::post('/customers/{id}/restore', [CustomersApiController::class, 'restore'])->whereNumber('id');
Route::delete('/customers/{id}', [CustomersApiController::class, 'destroy'])->whereNumber('id');

/*
|------------------------------------------------------------------------------
| Edit email / phone, and re-send a confirmation (Lane CE)
|------------------------------------------------------------------------------
|
| Store -> Customers -> (a customer) -> Edit email / phone, and the order
| screen's Customer -> "Edit email / phone". Added to THIS file, as Lane PQ's
| invites were, so it inherits the mount inside the admin-api group (auth:admin,
| NoStoreAdminApi, the web group's CSRF) and routes/web.php does not change:
| these rewrite a customer's sign-in address and send mail.
|
|     GET  /admin-api/customers/{id}/contact              the dialog's data
|     POST /admin-api/customers/{id}/contact              save the correction
|     POST /admin-api/customers/{id}/resend-confirmation  re-send one receipt
|
| All three are `customers.edit` in AdminCapabilities::RULES (owner, manager).
|
| EACH WRITE HAS ITS OWN NAMED LIMITER. An unnamed `throttle:N,1` shares one
| counter with every other unnamed throttle on the same signature, so a busy
| screen elsewhere would eat this one's allowance (routes/checkout-line.php,
| 'checkout-coupon', is where that was paid for). The resend is the tighter of
| the two: it sends mail to a customer.
|
*/
Route::get('/customers/{id}/contact', [\App\Http\Controllers\Admin\CustomerContactController::class, 'show'])
    ->whereNumber('id');
Route::post('/customers/{id}/contact', [\App\Http\Controllers\Admin\CustomerContactController::class, 'update'])
    ->whereNumber('id')
    ->middleware('throttle:30,1,customer-contact');
Route::post('/customers/{id}/resend-confirmation', [\App\Http\Controllers\Admin\CustomerContactController::class, 'resend'])
    ->whereNumber('id')
    ->middleware('throttle:6,1,customer-resend');
