{{--
    Site header.

    Every part is switchable from Appearance → Header; appearance arrives as
    custom properties on the element, so the stylesheet stays static and
    cacheable and only this short block differs per shop.
--}}
@php
    use App\Support\Url;
    $hd = app(\App\Services\HeaderSettings::class);
    $h = $hd->all();
    /*
     * The chip is a WhatsApp button, so it DIALS the WhatsApp number and PRINTS
     * the number the rest of the chrome prints. Both used to come from
     * `whatsapp` — a setting nothing seeds and nothing writes, so the literal
     * beside it was what every shop showed. See App\Support\SupportContact.
     */
    $whatsapp = \App\Support\SupportContact::phone();
    $whatsappDigits = \App\Support\SupportContact::whatsappDigits();

    /*
     * Lane HLB, 17 October 2026 -- the design the owner approved in the round-3
     * live preview ("ok proceed to the patch, but with super care without
     * distubing anything else"). Appearance → Header → Icons → Language switch.
     * App\Support\LangSwitch prints '' while Arabic is off, so a shop without
     * it gets no byte from this. Every byte it prints is a constant or e().
     *
     * $kbbWcp: the phone capsule takes the heart's slot (the approved design),
     * so while it is printed AND Appearance → Cart panel → Content → Wishlist
     * tab (phones) is on, the heart hides at 900px and under (kbb.css,
     * `.ib-wcp`) and lives in the cart panel; the computer keeps it. With no
     * capsule (Arabic off) the heart stays where it is: the empty slot would
     * otherwise go to the logo, which grows at 320-360px, and the header is
     * frozen ("logo previous size").
     */
    $kbbLsw = \App\Support\LangSwitch::header((string) $h['lang_switch']);
    $kbbWcp = $kbbLsw['phone'] && app(\App\Services\CartPanel::class)->wishTab();
@endphp

@php
    // Phone spacing and the divider above the search field, from
    // Appearance → Mobile Header. Everything it sets is read inside the existing
    // 900px media query, so the desktop header is untouched by it.
    $mhd = app(\App\Services\MobileHeader::class);
@endphp
<header class="{{ $hd->bodyClass() }}{{ $h['search_group_rule'] ? ' sg-rule' : '' }}{{ $h['search_row_rule'] ? ' sg-rowrule' : '' }}{{ 'compact' === $h['search_row_size'] ? ' sg-compact' : '' }} {{ $mhd->bodyClass() }}"
        style="{{ $hd->cssVariables() }};{{ $mhd->cssVariables() }}">
  <div class="wrap">
    <div class="hin{{ $kbbLsw['computer'] ? ' has-lswd' : '' }}">
      @include('partials.menu-icon')

@if ($hd->logoLockup())
      @include('partials.logo-lockup', ['href' => Url::to('/'), 'art' => 'def'])
@else
      <a class="logo" href="{{ Url::to('/') }}"><bdi>{{ $h['logo_text'] }}<span>{{ $h['logo_accent'] }}</span></bdi></a>
@endif

      @if ($h['search_show'])
        {{-- The script binds to `.search-in input[type=search]` and renders into
             `#kbbSuggest`; the stylesheet dresses `.sugg`. All three have to be
             here or suggestions silently never appear.

             data-starter carries the trending words, so a tap on the field
             paints them at once instead of after a round trip to
             /api/search/starter (the owner: "showing with little delays upon
             click"). Settings only: no query. search.js refreshes the rest
             behind it. --}}
        <form class="sbox" method="get" action="{{ Url::to('/shop/') }}" role="search">
          <div class="search-in {{ 'compact' === $h['search_row_size'] ? 'rs-compact' : 'rs-regular' }}{{ $h['search_native_clear'] ? '' : ' no-native-clear' }}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m21 21-4-4"/></svg>
            <input type="search" name="s" autocomplete="off" aria-label="{{ __('store.header.search_label') }}"
                   value="{{ request('s') }}"
                   placeholder="{{ str_replace('{n}', number_format($kbbProductCount ?? 0), $h['search_text']) }}">
          </div>
          <div class="sugg" id="kbbSuggest" role="listbox" aria-label="{{ __('store.header.suggestions_label') }}"
               data-brands-phone="{{ $h['search_brands_phone'] ? '1' : '0' }}"
               data-max="{{ (int) $h['search_results_max'] }}"
               data-starter="{{ json_encode(['trending' => $hd->trendingWords(), 'mobile' => (int) $h['trending_limit_mobile'], 'layout' => $h['search_panel']], JSON_UNESCAPED_UNICODE) }}"></div>
        </form>
      @endif

      <div class="hact">{!! $kbbLsw['html'] !!}
        @if ($h['icon_account'])
          @php
              // A panel needs someone to show it to. Guests go to the sign-in
              // page unless the shop has asked for the form in a panel.
              // The panel's own screen decides what a guest gets, so there is one
              // answer rather than two settings that could disagree.
              $apGuest = 'panel' === app(\App\Services\AccountPanel::class)->get('guest_mode');
              $acctPanel = $h['account_menu'] && (auth()->guard()->check() || $apGuest);

              /*
               * `mh-signedin` below is the whole of how the green is decided:
               * the class is on or it is not, and both colours come from
               * Appearance → Mobile Header rather than from a hex in a
               * stylesheet.
               *
               * ON THE `customer` GUARD, which is the one a shopper signs in
               * on — see config/auth.php and the note at the top of
               * tests/Feature/AccountAreaTest.php.
               *
               * ▲ AND SO IS `account_dot` NOW, WHICH IT WAS NOT. The dot on
               * this same icon read the DEFAULT guard, `web` — the staff
               * table — so it was true for nobody who had ever bought
               * anything, and the signed-in dot had never once lit on this
               * shop for a shopper. Nothing errored and nothing logged; the
               * icon simply always looked signed out. Found while adding the
               * green beside it, which is the tell: two indicators of the same
               * state, one on each guard, three characters apart.
               *
               * $acctPanel on line 61 STILL READS THE DEFAULT GUARD and is
               * left alone deliberately. It decides whether the account panel
               * opens or the icon is a plain link to /my-account/, so
               * correcting it changes what a signed-in shopper's tap DOES, not
               * how it looks. That is a behaviour change nobody asked for; it
               * is flagged rather than smuggled in beside a colour fix.
               *
               * Not driven off `account_dot` either way: the dot is a switch a
               * shop can turn off while still being signed in.
               *
               * Written here, inside the @php block, rather than as a Blade
               * comment between the tags. A `{{-- --}}` on its own lines
               * leaves its newlines in the output, and every storefront page
               * is compared byte for byte by StorefrontEnglishUnchangedTest —
               * a note is not worth a diff on thirty pages.
               */
          @endphp
          <span class="ib-acct" @if ($acctPanel) data-acct data-acct-open="{{ app(\App\Services\AccountPanel::class)->get('panel_open') }}" @endif>
            <a class="ib{{ auth('customer')->check() && $h['account_dot'] ? ' in' : '' }}@auth('customer') mh-signedin @endauth"
               href="{{ Url::to('/my-account/') }}" aria-label="{{ __('store.header.account_label') }}"
               @if ($acctPanel) aria-haspopup="true" aria-expanded="false" @endif>
              {!! \App\Support\HeaderIcons::account() !!}
            </a>
            @if ($acctPanel)@include('partials.account-panel')@endif
          </span>
        @endif

        @if ($h['icon_wishlist'])
          <a class="ib{{ $kbbWcp ? ' ib-wcp' : '' }}" href="{{ Url::to('/my-wishlist/') }}" aria-label="{{ __('store.header.wishlist_label') }}">{!! \App\Support\HeaderIcons::wishlist() !!}<i id="kbbWishCt" style="display:{{ ($kbbWishlistCount ?? 0) > 0 ? '' : 'none' }}">{{ $kbbWishlistCount ?? 0 }}</i></a>
        @endif

        @if ($h['icon_cart'])
          <a class="ib" href="{{ Url::to('/cart/') }}" data-kbb-open="cart" data-kbb-cart aria-label="{{ __('store.header.cart_label') }}">{!! \App\Support\HeaderIcons::cart() !!}<i id="cartCt" style="display:{{ ($kbbCartCount ?? 0) > 0 ? 'grid' : 'none' }}">{{ $kbbCartCount ?? 0 }}</i></a>
        @endif
      </div>

      @if ($h['support_show'])
        <div class="hinfo">
          <a class="hi hiwa" href="https://wa.me/{{ $whatsappDigits }}">
            <span class="ic"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15l-1.3 4.7 4.8-1.3A10 10 0 1 0 12 2Zm0 18a8 8 0 0 1-4.1-1.1l-.3-.2-2.8.7.8-2.8-.2-.3A8 8 0 1 1 12 20Zm4.4-6c-.2-.1-1.4-.7-1.6-.8-.2-.1-.4-.1-.5.1l-.7.9c-.1.2-.3.2-.5.1a6.5 6.5 0 0 1-3.2-2.8c-.1-.2 0-.4.1-.5l.4-.5c.1-.1.1-.3 0-.4l-.7-1.7c-.2-.4-.4-.4-.5-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2c0 1.3 1 2.6 1.1 2.8.1.2 1.9 3 4.7 4.1 1.7.6 2.3.7 3.1.6.5-.1 1.4-.6 1.6-1.1.2-.6.2-1 .1-1.1 0-.1-.2-.2-.4-.3Z"/></svg></span>
            <span class="tx"><b>{{ $h['support_label'] }}</b><span>{{ $whatsapp }}</span></span>
          </a>
        </div>
      @endif
    </div>

    @if ($h['trending_show'] && ! empty($kbbTrending))
      <div class="trend"><b>{{ __('store.header.trending_heading') }}</b>
        @foreach (array_slice($kbbTrending, 0, (int) $h['trending_limit']) as $term)
          <a href="{{ Url::to('/shop/') }}?s={{ urlencode($term) }}">{{ $term }}</a>
        @endforeach
      </div>
    @endif
  </div>

  @if ($h['nav_show'])
    @include('partials.nav-bar')
  @endif
</header>
