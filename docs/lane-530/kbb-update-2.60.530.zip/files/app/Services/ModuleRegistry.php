<?php

declare(strict_types=1);

namespace App\Services;

/**
 * The module registry.
 *
 * Ported from KBB Modules v2.39.0 — 29 modules in 8 groups, with the plugin's
 * own names, descriptions and default states carried across verbatim. The list
 * was extracted from the plugin source rather than retyped, so a module cannot
 * quietly go missing or change its default in translation.
 *
 * Two things the plugin does that this keeps:
 *
 *  - A module is an independent on/off switch. The storefront renders with every
 *    one of them off; nothing here is load-bearing.
 *  - Sixteen modules own their settings, twelve defer to a settings screen that
 *    already exists in this app, and one has no settings at all. The fifth field
 *    below is where that screen lives, so the admin can link straight to it
 *    instead of duplicating controls.
 *
 * Per-device visibility is this app's addition: the plugin is desktop-and-phone
 * or nothing, and the storefront here already treats those separately
 * everywhere else.
 *
 * On/off is NOT stored here. It lives in `module_toggles`, read through
 * SettingsService::moduleEnabled() — the mechanism eleven places in this app
 * already use, and the table the original schema created with the comment
 * "29 ids from the registry". This class is the catalogue and the admin's view
 * of it, not a second store. Only the per-device choice, which that table has no
 * column for, is kept alongside it in settings.
 */
class ModuleRegistry
{
    /** group key => label, in the order the plugin lists them. */
    public const GROUPS = [
        'checkout'    => 'Checkout',
        'cart'        => 'Cart & mini-cart',
        'store'       => 'Store & content',
        'payship'     => 'Payments & shipping',
        'email'       => 'Order emails',
        'catalogue'   => 'Catalogue',
        /*
         * Its own group, for one row, deliberately. Reviews was filed under
         * Catalogue on the reasoning that a review hangs off a product — true,
         * and useless to the person looking for it. The owner went to this
         * screen specifically to find Reviews, scanned the group headings, and
         * reported it missing. It was not missing; it was under a heading they
         * had no reason to open.
         *
         * Reviews is its own section in the console's own nav, with its own
         * eight screens. A reader who thinks of it that way is right, and this
         * page should agree with the nav rather than with the schema.
         */
        'reviews'     => 'Reviews',
        'marketing'   => 'Marketing',
        'performance' => 'Performance',
        'seo'         => 'SEO',
        'extra'       => 'This app only',
    ];

    /** key => [group, name, description, default on, settings screen, console route, surface, band, where, status]. */

    /*
     * Status is the honest bit.
     *
     *   live      — something on the storefront reads moduleEnabled() for this
     *               key, so the switch here works.
     *   elsewhere — the feature is real but is already switched on another
     *               screen. A second switch for the same thing is how a control
     *               ends up half working, so this one is shown but not offered.
     *   todo      — the feature is not ported yet. A switch would do nothing.
     *   screen    — not a switch at all. A built admin screen that this page
     *               lists so the owner can see it exists and open it. Always
     *               on; there is nothing to turn off.
     *   inherent   — the work this module describes is already done, for every
     *               page, with no switch — and a switch could only make the
     *               shop worse. Listed so the row is not silently deleted from
     *               a page the owner reads as a catalogue, and so the answer to
     *               "what happened to Performance?" is on the screen rather
     *               than in a document.
     *
     * It is maintained by hand as each module is wired, and the alternative — a
     * toggle that silently does nothing — is exactly the fault this project has
     * hit three times.
     *
     * WHY `screen` EXISTS, added with the Media Library (Lane AX).
     *
     * The owner asked why Media and Reviews are missing from this page. They
     * were missing because REGISTRY had no key for either — an omission, not a
     * status — and this page iterates REGISTRY and nothing else, so neither
     * could ever appear however well built it was.
     *
     * The two turned out to need DIFFERENT answers, which is the whole point of
     * having a status field at all:
     *
     *   - Reviews already has a switch, on Appearance → Product page. It is
     *     `elsewhere`, and the long note on that row says where and why.
     *
     *   - The Media Library has no switch anywhere, and should not get one.
     *     It could not be `live`: `live` means a switch something reads, and
     *     Phase3ModuleSwitchesTest enforces exactly that — it greps app/ and
     *     resources/views/ for moduleEnabled('<key>') and fails any `live` row
     *     without one. Writing a reader purely to satisfy that grep would be
     *     fabricating the evidence the test exists to check, and gating an
     *     admin screen behind a toggle the owner could switch off and then not
     *     find is hostile. It could not be `elsewhere` either: the console
     *     renders that as "Switched in <screen>", and there is no switch on the
     *     Media Library to be switched in, so the owner would be told something
     *     false.
     *
     * `screen` says the true thing — this is built, it is always on, here is
     * the way to it — and the console renders it as that, with no switch drawn
     * at all rather than an inert one sitting in the grey "off" position beside
     * the words "always on".
     */
    public const REGISTRY = [
        // ── Checkout ──
        /*
         * `elsewhere` since Lane QK7. This row used to say "Appearance → Cart
         * panel" and point at the drawer — which never read it: the drawer's
         * bar shows whenever a free-delivery amount is set. What it did gate
         * was the checkout's bar, and only that, so the owner turned "the
         * delivery bar" off and still saw it on the cart page. The cart page
         * and the checkout now share ONE switch on Appearance → Checkout page,
         * and a second switch here for the same thing is how a control ends
         * up half working.
         */
        'freeship_bar' => ['checkout', 'Free-shipping progress bar', 'The “AED X away from free delivery” / “You\'ve unlocked free delivery” bar on the cart page and the checkout.', false, 'Appearance → Checkout page → Delivery labels', 'checkoutpage', 'checkout', 'aside', 'On the cart page and the checkout — both of the checkout\'s order summaries, and in place after a coupon, quantity or country change — switched by “Free-delivery bar on the cart and checkout pages” (off, as asked). The cart panel\'s own bar is not switched here: it shows whenever a free-delivery amount is set.', 'elsewhere'],
        'vat_line' => ['checkout', 'Inclusive VAT line', 'Shows the VAT already included in the total.', true, 'Store → Ecommerce → Checkout', 'ecommerce', 'checkout', 'aside', 'A line in the order summary showing the VAT already included.', 'elsewhere'],
        'cod_fee' => ['checkout', 'Cash-on-delivery fee', 'Adds the COD surcharge when Cash on delivery is chosen.', true, 'Store → Ecommerce → Checkout', 'ecommerce', 'checkout', 'aside', 'A surcharge row in the order summary when Cash on delivery is chosen.', 'elsewhere'],
        'delivery_line' => ['checkout', 'Delivery-info line', 'Country-aware “fast delivery” message under the summary.', true, 'Store → Ecommerce', 'ecommerce', 'checkout', 'aside', 'The delivery message under the order summary.', 'live'],
        'coupon_hint' => ['checkout', 'Checkout coupon hint', 'Editable, clickable promo-code hint on the discount box.', true, 'Store → Ecommerce', 'ecommerce', 'checkout', 'mid', 'A clickable promo-code hint on the discount box.', 'live'],
        /*
         * PORTED IN LANE EH, and previously `todo`.
         *
         * §2 of the master plan filed this under "blocked on a missing source":
         * the plugin's own entry is a settings LINK pointing at kbb-theme, which
         * was never supplied, so there is no implementation to copy. That is
         * still true and this is still not a copy — it is the module's
         * description built against what this app already has. The two pages it
         * links to, /terms-and-conditions/ and /privacy-policy/, are the two the
         * register form has always linked to.
         *
         * On by default, as the plugin ships it, and with no wording of its own:
         * with nothing saved this renders no element at all, so applying the
         * package changes no live checkout. App\Support\CheckoutLegalNotice
         * carries the full reasoning for that split.
         *
         * The route is 'ecommerce:checkout' and not 'ecommerce': the Checkout
         * tab is one of five on that screen, and `product_sorting` already
         * established that a row may name its sub-tab so the owner does not have
         * to guess which one the module meant.
         */
        'legal_notice' => ['checkout', 'Checkout legal notice', 'An editable notice above the Place order button, with links to your terms and privacy pages. On by default, and shows nothing until you write it.', true, 'Store → Ecommerce → Checkout', 'ecommerce:checkout', 'checkout', 'bottom', 'The privacy and terms notice above the place-order button.', 'live'],
        'reassurance' => ['checkout', 'Reassurance block', 'Rating + authenticity block above the order summary.', true, 'Store → Ecommerce', 'ecommerce', 'checkout', 'aside', 'The rating and authenticity block above the order summary.', 'live'],
        'checkout_thumbs' => ['checkout', 'Mobile order thumbnails', 'Circular product thumbnails on the mobile place-order box.', true, 'Store → Ecommerce', 'ecommerce', 'checkout', 'bottom', 'Round product thumbnails on the mobile place-order box.', 'live'],
        /*
         * PORTED IN LANE M, and previously `todo` with default `true`.
         *
         * BOTH OF THOSE CHANGED, and the default is the one that mattered.
         * ModuleSeeder has always seeded this key `true`, copied from the
         * plugin with the rest of the checkout group, while nothing read it —
         * so adding the reader without 2027_01_05_000001 would have switched
         * address autocomplete ON, on the form the shop is paid through, for
         * every install the seeder has ever run against, at the moment the
         * package applied. That is the landmine Lane FI defused for
         * `inline_validation` and flagged in docs/FI-PHASE3-MODULE-INVENTORY.md
         * as still armed for this key. It is now defused the same way.
         *
         * It is `false` here for the reason the rest of this file uses: the
         * default is measured against what the store does WITHOUT the switch,
         * and without it the address box has no suggestions at all.
         *
         * NOT FINISHED, and the row does not claim it is. The module is `live`
         * because the storefront genuinely reads the switch and the settings
         * genuinely change the page — that is what `live` means here. But it
         * cannot DO anything until somebody supplies a Google Places API key
         * and answers the privacy question on Store → Ecommerce → Checkout,
         * and with either missing it renders nothing and sends nothing. The
         * description says so rather than leaving the owner to switch it on and
         * wonder why the box looks the same.
         */
        'address_autocomplete' => ['checkout', 'Address autocomplete', 'Google suggests a full address as the shopper types. Needs a Google Places API key of your own, and needs you to agree that what shoppers type is sent to Google — both are on Store → Ecommerce → Checkout. Off by default, and sends nothing until all three are set.', false, 'Store → Ecommerce → Checkout', 'ecommerce:checkout', 'checkout', 'mid', 'Suggestions as the shopper types the address field.', 'live'],
        /*
         * PORTED IN LANE FI, and previously `todo` with no settings screen at
         * all — the row the console renders as "Not ported yet".
         *
         * §2 of the master plan files this under "blocked on a missing source",
         * and that half is still true: the plugin's own entry is a settings LINK
         * pointing at kbb-theme, which was never supplied, so there is nothing
         * to copy. This is `legal_notice`'s shape — the module's description
         * built against what this app already has — and what it already has is
         * the CONTRACT: components/checkout/field.blade.php writes WooCommerce's
         * validate-required / validate-email / validate-state / validate-phone
         * classes onto every checkout row, and its own header records that
         * nothing in this repo has ever read them. This module is that reader,
         * and it puts back Woo's own woocommerce-invalid / woocommerce-validated
         * rather than a second vocabulary for the same idea.
         *
         * THE DEFAULT FLIPS FROM THE PLUGIN'S, from true to false, and the
         * reasoning is the same rule `seo_engine`, `brands` and the order emails
         * each use pointed the other way: the default is measured against what
         * this store does WITHOUT the switch. Without it this checkout shows no
         * marks whatsoever — only the browser's own bubble on Place order — so
         * shipping ON would start colouring in the one form the shop is paid
         * through, on apply, without anybody asking. OFF, and applying this
         * package changes the checkout by nothing.
         *
         * The route is 'ecommerce:checkout' and not 'ecommerce' for the reason
         * `legal_notice` and `product_sorting` already established: the Checkout
         * tab is one of five on that screen, and a row may name its sub-tab so
         * the owner is not left guessing which one the module meant.
         */
        'inline_validation' => ['checkout', 'Inline field validation', 'Marks each checkout field as the shopper fills it in, using the shop’s existing form rules — a red mark and a short line on a field that needs attention, a green one on a field that is done. Off by default: without it the checkout says nothing until Place order is pressed.', false, 'Store → Ecommerce → Checkout', 'ecommerce:checkout', 'checkout', 'mid', 'Green and red marks on each field as it is filled in.', 'live'],
        'single_name' => ['checkout', 'Single “Full name” field', 'One name field instead of first + last (auto-split on save).', true, 'Store → Ecommerce → Checkout', 'ecommerce', 'checkout', 'mid', 'One Full name field in place of first and last name.', 'elsewhere'],
        // ── Cart & mini-cart ──
        'minicart_promo' => ['cart', 'Mini-cart promo', 'Editable promo line in the cart drawer.', true, 'Appearance → Cart panel', 'cartpanel', 'drawer', 'bottom', 'The promo line above the subtotal in the cart panel.', 'live'],
        'back_to_cart' => ['cart', '“Go back to cart” link', 'Return-to-cart control beside the Checkout heading.', true, 'Store → Ecommerce', 'ecommerce', 'checkout', 'top', 'A return-to-cart link beside the Checkout heading.', 'live'],
        /*
         * The cart page's own discount-code box, and only that one.
         *
         * Not to be confused with `coupon_hint`, which governs the clickable
         * promo-code SUGGESTION printed under the box; the box itself has never
         * had a switch. Turning this off hides the input and the Apply button
         * on /cart/ and, with them, the hint that only makes sense beside them.
         * The checkout page keeps its own coupon box — that is a separate
         * surface and is not gated here.
         *
         * Off by default, which is the plugin-style default for anything this
         * registry adds: a fresh install shows no cart-page coupon box until
         * the owner asks for one. Existing installs are unaffected either way,
         * because a store that has explicitly saved Store → Modules already has
         * a `module_toggles` row and moduleEnabled() returns that row rather
         * than this default. No migration writes a value for this key, so no
         * store's decision is overwritten.
         *
         * Nothing is removed: coupons still apply, an already-applied coupon
         * still shows and can still be removed, and /cart/coupon still works.
         */
        'mobile_tabbar' => ['store', 'Floating bottom menu (mobile)', 'The floating bar pinned to the bottom of the screen on phones — Home, Shop, Quiz, Saved and Bag. Off by default; the header, its cart icon and the mobile menu all keep working without it.', false, 'No settings screen', '', 'mobile', 'mid', 'The floating Home / Shop / Quiz / Saved / Bag bar at the bottom of every page on a phone.', 'live'],
        'cart_coupon_field' => ['cart', 'Cart-page discount code box', 'The “Discount code” input and Apply button in the cart page order summary. Off by default; the checkout page has its own box and is not affected.', false, 'No settings screen', '', 'cartpage', 'mid', 'The discount code box in the order summary on the cart page.', 'live'],
        // ── Store & content ──
        /*
         * SETTINGS PATH AND ROUTE KEY CORRECTED — Lane FO, Phase 15.
         *
         * This row said its settings were on 'Appearance → Homepage', and that
         * screen has never carried a banner control of any kind: it owns which
         * sections render, per device, and their grid skins. The hero's words
         * lived in `home_banners`, a setting HomeController READ and nothing in
         * the tree WROTE, so the Open button sent the owner to a screen that
         * could not change the thing the row describes. Both fields now name
         * Appearance → Homepage content, which is where the slides actually
         * are; ModuleRegistrySettingsPathTest resolves the path through this
         * lane's kbbAddNavEntry() call, so the claim is checked rather than
         * asserted.
         *
         * THE DESCRIPTION IS TRIMMED TO WHAT THE SCREEN DOES. "Floating product
         * pods", "the offer badge" and "supports scheduling" came across from
         * the KBB Modules plugin verbatim and describe none of this app: the
         * slide has an eyebrow, a headline, a supporting line, a button and two
         * gradients, and there is no schedule anywhere. A row promising three
         * features the screen behind it does not have is the same defect as a
         * path naming a screen that does not exist.
         *
         * The DEFAULT is untouched and still off, and nothing on the storefront
         * reads this toggle — see docs/FO-HOMEPAGE-INVENTORY.md, which reports
         * that as an open gap rather than quietly wiring it up: switching a
         * module off must remove it from the storefront, and making that true
         * for `banners` is a decision about whether a shop with the module off
         * has a hero at all.
         */
        'banners' => ['store', 'Banners', 'The homepage hero slider — the eyebrow, headline, supporting line, button and colours of each slide, and the order they rotate in. The first slide’s headline is the page’s h1.', false, 'Appearance → Homepage content', 'hpcontent', 'home', 'top', 'The homepage hero slider — headline, buttons and colours.', 'elsewhere'],
        /*
         * ON by default, and the reasoning is `brands`' and `seo_engine`'s
         * rather than this registry's usual "a fresh install shows nothing the
         * owner did not ask for".
         *
         * Until 2.60.199 nothing on the storefront read this key: the bar
         * rendered its panels and the phone menu its expandable sections
         * whatever the switch said, and the only reader in the codebase was
         * the admin screen's own `module_on`. The default has to be measured
         * against what the store DOES without the switch, not against a blank
         * slate — and what it does is show the dropdowns. Shipping the gate
         * with `false` would take the header dropdowns off a live store on
         * apply, which is not a default, it is an outage.
         *
         * 2026_10_21_000000 aligns the stored toggle for the installs that
         * were seeded `false` while nothing consulted it. A genuinely fresh
         * install with no row gets this value.
         */
        'mega_menu' => ['store', 'Mega Menu', 'Drives the header mega panels from the admin using the theme\'s own design — category columns, brands and editor\'s picks — plus the expandable sections in the phone menu. On by default: the panels have always rendered, so turning this off is what changes the storefront.', true, 'Store → Mega Menu', 'megamenu', 'header', 'nav', 'The panels that drop from the category bar, and the expandable sections in the phone menu.', 'live'],
        'notification_bar' => ['store', 'Notification Bar', 'A dismissible announcement bar at the top of every page. Replaces the Cosmetics plugin. Off by default — turn on and set your message.', false, 'Its own screen', '', 'header', 'top', 'A dismissible strip above the header on every page.', 'live'],
        'product_labels' => ['store', 'Product Labels', 'Configurable Sale / New / Sold-out / Bestseller badges on product cards. Off by default — the theme’s built-in badges show until you turn it on.', false, 'Growth & Marketing → Product Labels', 'labels', 'grid', 'card', 'Sale, New, Sold-out and Bestseller badges on product cards.', 'live'],
        /*
         * The Media Library, in 'Store & content' because that is what it is:
         * it is not a catalogue feature, it holds the images for products,
         * brands, categories AND the SEO share image, and the console files it
         * under Content.
         *
         * `site` / `all` for the hover card, which renders "nothing visible" —
         * correct, since this changes nothing a shopper ever sees.
         */
        /*
         * Phase 20 — Shoppable UGC video (Lane V3). The rail itself.
         *
         * `live`, and App\Services\UgcSettings::enabled() is the reader — the
         * ONE reader, called from App\Support\Shortcodes::videos() before any
         * query runs. Off means the shortcode renders the empty string, so a page
         * that already carries `[kbb_videos section="x"]` is byte-identical with
         * the switch off. There is no rail on any template: every appearance of
         * this module on the storefront is somewhere the owner wrote a shortcode,
         * which is what "insert anywhere in the site" means.
         *
         * OFF BY DEFAULT, and that is what makes this package inert. The previous
         * round shipped the library with NO registry row at all and said why in
         * 2027_01_10_000001's header: a switch must not be drawn for something
         * nothing reads, and ModuleFrameworkGuardTest enforces that in both
         * directions. This is the round that draws a rail, so this is the round
         * that adds the row.
         *
         * The settings screen is Appearance → Video rail, id `ugcstyle` — NOT
         * "Appearance → Shoppable video", because AdminNavAndIdsTest refuses two
         * sidebar entries with the same label and Content → Shoppable video is
         * already the clip library's row,
         * registered by resources/views/admin/partials/ugc-appearance-screen.blade.php
         * — which is how the `it points every settings link at a console screen
         * that exists` guard finds it (a partial declaring `var SCREEN = '...'`
         * counts, the same way Media Library's does).
         */
        'shoppable_video' => ['store', 'Shoppable video', 'Rails of creator videos with the products tagged on each one, placed anywhere on the shop with a [kbb_videos] shortcode. Everything is under Content → Shoppable video: its Sections tab builds the rails, All clips is the library, and Appearance is the look. Off by default — nothing appears until you turn it on and write a shortcode.', false, 'Content → Shoppable video', 'ugcsections', 'site', 'mid', 'Every video rail you have placed with a shortcode.', 'live'],
        /*
         * (Lane IGR) `instagram_profile` — Content → Instagram, the API module
         * with its "Connect with Facebook" handshake — was retired at the owner's
         * request on 9 October 2026. Instagram is Content → Instagram embeds,
         * which needs no module switch: its own "Show the section" is the switch.
         */
        /*
         * ── Appearance → Banners → Cards banner (Lane BN — Phase 22) ────────
         *
         * The owner: "we can turn on off card banners". THIS ROW IS THAT
         * SWITCH, and without it the feature is unreachable in exactly the way
         * the Instagram note above records: Banners::enabled() is
         * moduleEnabled('cards_banner', false), so with no registry row the
         * switch is never drawn, `false` is the only value it ever has, and the
         * homepage section answers "off" forever.
         *
         * OFF BY DEFAULT, and inert twice over on top of that: the module ships
         * with no set chosen, and a set that IS chosen draws nothing until it is
         * published and holds a card with a picture. Applying the package
         * therefore moves nothing on the front page, which is rule 1 on the most
         * visible page in the shop — CardsBannerShipsOffTest renders it with a
         * full table and asserts the bytes.
         *
         * 'live' and not 'screen': this draws a row a SHOPPER sees.
         *
         * The settings screen is `Appearance → Banners`, id `banners`,
         * registered by resources/views/admin/partials/banners-screen.blade.php
         * declaring `var SCREEN = 'banners'` — which is how AdminNavAndIdsTest's
         * "it points every settings link at a console screen that exists" finds
         * it. The integrator adds that partial's @include and its TITLES entry;
         * the lane report names both lines.
         */
        // ▲ OFF -> ON, AND THE WORDING FOLLOWS THE SHIPPED TREATMENT. (Lane SEC)
        // The owner: "the banner i need to change to simple image banners, not
        // cards, simple only images banner ... apply this on desktop and mobile
        // both." A banner that is the homepage's banner cannot ship behind an off
        // switch, so this default moves with the three in BannerSet. It still shows
        // nothing until a published set carries a picture, which is why turning it
        // on moves no pixel on a shop that has not uploaded one.
        //
        // The label stays "Banners" rather than "Cards banner": both treatments
        // live in the one screen, the id is read by ModuleFrameworkGuardTest and by
        // every saved section payload, and renaming an id is a migration.
        'cards_banner' => ['store', 'Banners', 'The homepage banner: one picture per slide, filling the frame, sliding left and right when there is more than one and standing still when there is one. 1920 × 550 on desktop and 500 × 600 on phones. Build any number of named sets under Appearance → Banners, then pick which set the homepage shows — each set carries its own sizes, arrows, bars and speed. On by default, and shows nothing until a published set with at least one picture is chosen. The older treatment, a scrolling row of picture cards with a line of text and a button under each, is still available per set.', true, 'Appearance → Banners', 'banners', 'site', 'mid', 'The picture banner on the homepage, once you have chosen a set for it.', 'live'],
        'media_library' => ['store', 'Media Library', 'The grid of every image uploaded through the admin, with search by name, by upload date and by the product, brand or category using it — plus what each image is used by before you delete it. Always on: this is a screen, not a switch.', true, 'Content → Media Library', 'media', 'site', 'all', 'An admin screen. Nothing visible on the storefront.', 'screen'],
        // ── Payments & shipping ──
        'pay_ship_rules' => ['payship', 'Payment & Shipping Rules', 'Limit Cash on Delivery by order value and hide paid delivery when free is available. Consolidates conditional payment/shipping plugins. Off by default.', false, 'Store → Payment & Shipping Rules', 'payship', 'checkout', 'mid', 'Hides Cash on delivery and paid delivery when your rules say so.', 'live'],
        /*
         * ── Order emails ──
         *
         * The one group in this registry that ships ON.
         *
         * Everything this registry adds is off by default, on the plugin's own
         * principle that a fresh install shows nothing the owner did not ask for.
         * These five break that rule on purpose, and the reason is the same one
         * that applies to `seo_engine` above: the default has to be measured
         * against what the store does WITHOUT the switch, not against a blank
         * slate.
         *
         * Without them this store sends a customer nothing whatsoever. They pay,
         * and the only confirmation that has ever existed is the order-received
         * page, which is gated to the browser that placed the order — close the
         * tab and it is gone. The merchant is not told an order arrived at all;
         * AdminOrderController::runAction still refuses its own resend actions
         * with "outbound email is not configured for this store". Shipping these
         * off by default would mean applying a package called "order emails" and
         * changing nothing until somebody found the screen.
         *
         * The safety net that used to make ON defensible was that nothing was
         * being sent: MailConfigurator fell back to the `log` transport whenever
         * SMTP was not filled in, so on an install where nobody had completed
         * Store → Mail these wrote to storage/logs and reached no inbox.
         *
         * THAT IS NO LONGER TRUE, AND THE CHANGE WAS THE POINT. The owner's live
         * store had exactly that shape -- five order emails switched on, every
         * one of them going to a log file, nobody told. `mail_transport` now
         * defaults to the host's own mail (MailSettings::TRANSPORT_SERVER) and an
         * untouched install really sends. So these five being ON is no longer
         * harmless-because-inert; it is ON because a store that takes money and
         * says nothing is the worse default, which is what the paragraph above
         * argues and what the owner asked for in as many words.
         *
         * No migration writes a value for any of these keys, so a store that has
         * already saved Store → Modules keeps whatever it chose: moduleEnabled()
         * returns the module_toggles row when one exists and only falls back to
         * the default below when it does not.
         *
         * Every row is `live`: OrderMailer reads each key by name, and
         * Phase3ModuleSwitchesTest greps for exactly that.
         */
        'email_order_confirmation' => ['email', 'Order confirmation email', 'The receipt sent to the customer the moment an order is placed — line items as bought, the money breakdown, delivery address, delivery and payment method, and a link to the order.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when they place an order. Nothing visible on the site.', 'live'],
        'email_merchant_new_order' => ['email', 'New-order alert to you', 'Tells the store an order has come in, with the customer’s details, so you do not have to watch the admin. Goes to the address set under Store → Mail.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to you when an order is placed. Nothing visible on the site.', 'live'],
        // 17 October 2026, the owner: "i only need to send pending payment email to admin as well".
        'email_merchant_unpaid' => ['email', 'Payment-not-received alert to you', 'Tells the store an order is still unpaid 30 minutes after it was placed (card, Tabby, Tamara), so you know the payment did not go through without opening the order. Same rules as the customer’s first “Complete your order”. Goes to the address set under Store → Mail.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to you when an order is still unpaid after 30 minutes. Nothing visible on the site.', 'live'],
        'email_order_shipped' => ['email', 'Dispatch notification', 'Tells the customer their order has left you, sent when its status becomes Shipped.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when you mark an order Shipped. Nothing visible on the site.', 'live'],
        'email_order_cancelled' => ['email', 'Cancellation notification', 'Tells the customer an order has been cancelled and nothing further will be sent, when its status becomes Cancelled.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when an order is cancelled. Nothing visible on the site.', 'live'],
        'email_order_refunded' => ['email', 'Refund notification', 'Tells the customer money has gone back, sent when a refund actually settles — not when an order is merely marked refunded. Covers partial refunds too.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when a refund succeeds. Nothing visible on the site.', 'live'],
        // Lane RL — the rest of the order statuses and the two "Complete your order" reminders. Read by OrderMailer, one literal key each.
        'email_order_processing' => ['email', 'Processing notification', 'Tells the customer their order is being prepared, when you move it to Processing. Not sent when an unpaid order is paid — the order confirmation is that message.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when an order moves to Processing. Nothing visible on the site.', 'live'],
        'email_order_onhold' => ['email', 'On-hold notification', 'Tells the customer their order is paused while you check something. Off by default: send it by hand from the order screen (Order actions → Send on-hold email), or tick "Email the customer" when you change the status.', false, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when an order is put On hold. Nothing visible on the site.', 'live'],
        'email_order_completed' => ['email', 'Delivered notification', 'Tells the customer their order is complete (delivered), when its status becomes Completed.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when an order is marked Completed. Nothing visible on the site.', 'live'],
        'email_order_marked_refunded' => ['email', 'Refunded-status notification', 'Tells the customer an order was refunded when you mark it Refunded yourself. Not sent when the refund was made from the order screen — the refund notification covers that.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when an order is marked Refunded by hand. Nothing visible on the site.', 'live'],
        'email_order_failed' => ['email', 'Payment-failed notification', 'Tells the customer a payment did not go through, with a button to finish the order with any payment method. Not sent while the shopper is still on the checkout looking at the error.', true, 'Emails → All mail settings', 'mail', 'site', 'all', 'An email to the customer when a payment fails. Nothing visible on the site.', 'live'],
        'email_order_reminder_1' => ['email', '"Complete your order" — after 30 minutes', 'Reminds a customer whose order is not paid yet, 30 minutes after they placed it, with a button that opens the order on any device to pay. Never sent once the order is paid, cancelled or replaced by a newer order, and never for cash on delivery.', true, 'No settings screen', '', 'site', 'all', 'An email to the customer 30 minutes after an unpaid order. Nothing visible on the site.', 'live'],
        'email_order_reminder_2' => ['email', '"Complete your order" — after 24 hours', 'The last reminder, 24 hours after an unpaid order, with the same button. Same rules as the 30-minute one.', true, 'No settings screen', '', 'site', 'all', 'An email to the customer 24 hours after an unpaid order. Nothing visible on the site.', 'live'],
        'email_order_feedback' => ['email', 'Feedback request after delivery', 'Three hours after the Delivered email goes, asks the customer to review each product they bought, with a button to each product\'s reviews. Once per order; not sent if the Delivered email was not sent, or if the order has been refunded or cancelled since.', true, 'No settings screen', '', 'site', 'all', 'An email to the customer 3 hours after the Delivered email. Nothing visible on the site.', 'live'],
        'email_review_request' => ['email', 'Review request after completion', 'Days after an order is completed (2 by default), asks the customer to rate each product they bought: five stars per product, each opening a review page with that rating chosen. The reviews arrive in Reviews as pending, marked as coming from this email. Once per order, only for orders completed after it was switched on, and only to addresses that have not unsubscribed.', true, 'Emails → Customer emails → Review request', '', 'site', 'all', 'An email to the customer, and the review page its stars open. Nothing changes on any other page.', 'live'],
        /*
         * The sixth row in this group, and the only one that is not "send this
         * email or do not".
         *
         * It is here rather than on Store → Mail because that screen renders
         * MailSettings::SCHEMA through MailApiController, which knows three
         * field types -- text, secret, and a choice whose options that
         * controller supplies -- and none of them is a checkbox. An on/off put
         * there would be a text box the owner had to type a word into. This
         * screen already draws real switches, already carries the five order
         * emails, and is already where the owner goes to turn a piece of an
         * email off.
         *
         * ON by default, and safe to be: the logo only appears if one has
         * actually been uploaded under Store → Business Details. With no logo
         * saved, on and off render the same email — the wordmark — so the
         * default cannot surprise anybody. App\Services\Mail\EmailBranding is
         * the reader, and it reads this key by name.
         */
        'email_show_logo' => ['email', 'Logo in order emails', 'Prints your uploaded store logo at the top of every order email instead of the text wordmark. Uses the same logo as Store → Business Details — there is no second upload. With no logo saved, the wordmark is shown either way.', true, 'Store → Business Details', 'store-settings', 'site', 'all', 'Your logo at the top of every order email. Nothing visible on the site.', 'live'],
        // ── Catalogue ──
        // The screen is Store → Catalog → Reorder, and it has existed for some
        // time. This row said 'Its own screen' with no console route, which the
        // admin renders as "Its own screen — screen not built yet": the one
        // module whose settings the owner was told did not exist while they did.
        'product_sorting' => ['catalogue', 'Product Sorting', 'Bakes your curated product order (rwpp_sortorder) into WooCommerce’s native order so “Default sorting” shows it. Off by default.', false, 'Catalog → Reorder', 'catalog:reorder', 'grid', 'all', 'Bakes your curated order into Default sorting on shop and category pages.', 'live'],
        /*
         * SAID `todo` ABOUT A FEATURE THAT HAS BEEN LIVE SINCE 2.60.109 — Lane EH.
         *
         * This row was wrong in three separate ways at once, which is why it is
         * worth the space:
         *
         *   - STATUS. `todo` renders on the Modules screen as "Not ported yet",
         *     printed against a brand directory at /korean-skincare-brands/,
         *     per-brand landing pages, 301s from /brands/ and /brand/{slug}/,
         *     an admin editor, logos and a display-mode setting — all real, all
         *     serving. §2 of the master plan still records this as "blocked on
         *     the outstanding /brands/ URL decision"; the owner settled that
         *     decision in 2.60.109 and the pages were built on it.
         *
         *   - SETTINGS SCREEN. 'Its own screen' with no console route, which the
         *     admin renders as "Its own screen — screen not built yet". The
         *     screen is Catalog → Brands and has existed as long as the pages
         *     have. This is the identical fault the `product_sorting` row
         *     carried until it was corrected to 'catalog:reorder'.
         *
         *   - DEFAULT. `false`. Now true, and NOT because the plugin says so —
         *     the plugin ships it off. It is the seo_engine argument: the
         *     default has to be measured against what this shop does WITHOUT
         *     the switch, and without it those pages serve. Adding the gate
         *     below while leaving the default off would 404 three live URL
         *     families on apply.
         *
         * `live` is now true of it: BrandController's constructor reads the key
         * for every action, and store/home.blade.php reads it for the brand
         * strip, so switching it off leaves nothing of brands on the storefront.
         */
        'brands' => ['catalogue', 'Brands', 'The brand directory, each brand’s own page with its logo and description, and the brand strip on the home page. Turn it off and those pages 404 rather than sitting there empty.', true, 'Catalog → Brands', 'catalog:brands', 'grid', 'all', 'Brand pages, logos and the brand directory.', 'live'],
        /*
         * Phase 10 — Build my routine (Lane FM).
         *
         * `live`, and the reader is App\Services\BuildMyRoutine::enabled(),
         * which Store\RoutineController gates BOTH pages on. Off means off in
         * the strongest sense this console offers: /routines and
         * /routines/{concern} 404, and nothing else on the storefront changes
         * at all — no nav entry, no card, no strip. There is nothing to see
         * with it off, which is why it can ship off.
         *
         * OFF BY DEFAULT because it is not ready to be seen until the owner has
         * tagged products. Every row in this catalogue starts with
         * `routine_role` NULL, so on the day this applies the pages would list
         * nothing; the screen's whole top half exists to make that number
         * visible and shrink it.
         *
         * NO LINK TO IT FROM THE STOREFRONT, deliberately and as a gap rather
         * than a decision to be proud of — the header, the mega menu and the
         * footer are `menu_items` rows the owner edits, not templates this lane
         * may touch. docs/FM-ADMIN-APP-BLOCKS.md says where the menu item goes.
         */
        'build_my_routine' => ['catalogue', 'Build my routine', 'Step-by-step routines by skin concern at /routines, each step filled from a product you have tagged for it, with a swap control so the shopper can change any step. Off by default — turn it on after you have tagged some products on Catalog → Build my routine.', false, 'Its own screen', 'routines', 'site', 'all', 'Two pages of their own at /routines. Nothing else on the shop changes.', 'live'],
        'wishlist' => ['catalogue', 'Wishlist', 'Lets shoppers save products (works for guests too, via cookie). Heart button on cards/product pages plus a [kbb_wishlist] page. Off by default.', false, 'Its own screen', '', 'grid', 'card', 'The heart on every product card, and the wishlist page.', 'live'],
        'recently_viewed' => ['catalogue', 'Recently Viewed', 'Shows each shopper the products they just looked at (cookie-based, guests included). Auto-placed on product/cart pages plus a [kbb_recently_viewed] shortcode. Off by default.', false, 'Appearance → Cart panel', 'cartpanel', 'drawer', 'mid', 'The Browsed tab in the cart panel, and a rail on the product page.', 'elsewhere'],
        /*
         * Reviews, in 'Catalogue' because a review hangs off a product and the
         * row sits beside the wishlist and cross-sell rows that do the same.
         *
         * It is REAL and has been for some time: renderReviews() in the Lane AM
         * region of app.blade.php renders 'rev-all' live in the console,
         * ReviewsApiController serves the moderation endpoints, and the
         * storefront shows reviews on every product page. It was absent from
         * this screen for one reason only — nobody ever added the key.
         *
         * `elsewhere`, NOT `screen`, and the difference is load-bearing.
         *
         * Reviews ALREADY HAS AN ON/OFF SWITCH. ProductSections::REGISTRY
         * carries its own 'reviews' entry (app/Services/ProductSections.php:33,
         * default on), and resources/views/store/product.blade.php:213 gates the
         * whole section on it — an `unless` on $modules->hidden('reviews').
         * That switch is edited from Appearance → Product page, and
         * HomepageSections carries a separate 'reviews' entry for the homepage
         * wall.
         *
         * So a `screen` row here would print "Always on — a screen, not a
         * switch" about a feature the owner can switch off on another screen,
         * which is simply false; and a `live` row would draw a SECOND, working
         * toggle for the same feature, stored in module_toggles where nothing
         * reads it. Two switches for one thing, and whichever the operator
         * flipped last would appear to do nothing — the exact fault the status
         * field exists to prevent.
         *
         * `elsewhere` prints "Switched in Appearance → Product page" and links
         * there, which is the true statement and the useful one. Shaped to match
         * recently_viewed, vat_line and cod_fee, which are `elsewhere` for the
         * same reason.
         */
        'reviews' => ['reviews', 'Reviews', 'Customer reviews on the product page — score summary, filters and review cards — plus the moderation screens under Reviews. The on/off switch lives with the rest of the product page sections; this row is here so you can find it.', true, 'Appearance → Product page', 'productpage', 'product', 'bottom', 'The reviews section near the foot of the product page.', 'elsewhere'],
        /*
         * Lane RB: Frequently Bought Together was replaced, in its slot, by
         * "Buy these together" — and its switch with it. That section is
         * switched on Appearance → Product page → Buy these together (and per
         * device on the Sections and Mobile sections rows), so this row is
         * `elsewhere`: a `live` row here would be a second toggle stored in
         * module_toggles that nothing reads any more.
         */
        'frequently_bought' => ['catalogue', 'Buy these together', 'The product on the page plus one match from each category that goes with it, a green tick on each, and one “Buy 4 items together” button that adds every ticked product. Replaced Frequently Bought Together. The switch lives with the rest of the product page sections; this row is here so you can find it.', false, 'Appearance → Product page', 'productpage', 'product', 'mid', 'The Buy these together box under the buy column on the product page.', 'elsewhere'],
        // ── Marketing ──
        'marketing_pixels' => ['marketing', 'Marketing Pixels', 'Meta Pixel, Google (GA4) and TikTok tags with standard e-commerce events (view, checkout, purchase). Off by default — add your IDs to activate.', false, 'Growth & Marketing → Marketing Pixels', 'pixels', 'site', 'all', 'Meta, GA4 and TikTok tags on every page. Nothing visible.', 'live'],
        /*
         * These two said "blocked on mail, which this app has never sent" and
         * were marked `todo` on that basis. That is no longer true and has not
         * been since 2.60.199: MailSettings::DEFAULT_TRANSPORT is the server's
         * own mail(), five order emails are live, and every message this shop
         * hands to a transport is recorded in `mail_deliveries` with its
         * Message-ID and the provider's exact refusal.
         *
         * Both are now BUILT and both are `live` — Services\CartRecovery and
         * Services\StockAlerts each read their key here, and the storefront
         * renders a form from each. They remain OFF by default and, separately,
         * carry no wording of their own, so switching one on still changes
         * nothing a shopper sees until the owner writes the words. That is the
         * `legal_notice` shape, deliberately.
         *
         * The descriptions are edited to match what was actually built rather
         * than what the plugin's blurb promised, because a description is the
         * only thing the owner reads before flipping a switch:
         *
         *   - "one-click recovery link" is gone. The reminder names the basket
         *     and links to each item's own page; it does NOT carry a link that
         *     restores a shopping session, because such a link is a bearer
         *     credential for somebody's basket and checkout details.
         *     App\Mail\CartRecoveryReminder's header argues it, and whether the
         *     owner wants the stronger version is a hand-back question.
         *   - "at your chosen intervals" now says the schedule starts empty,
         *     because an empty schedule sends nothing and that is the shipped
         *     state.
         *   - "emails everyone the moment it restocks" becomes "when the shop
         *     is next visited", which is the truth on a host with no scheduler.
         *     Services\OutboundTick's header sets out why.
         *   - "in place of Add to cart" becomes "under", which is where the form
         *     was actually put. partials/notify-me.blade.php argues the choice
         *     and the hand-back asks the owner to confirm it.
         */
        'abandoned_cart' => ['marketing', 'Abandoned Cart Recovery', 'An opt-in tick box on the cart page; emails a reminder naming the basket, on a schedule you write. Stops the moment an order is placed. Off by default, and sends nothing until you write the message and the schedule.', false, 'Store → Ecommerce → Cart', 'ecommerce', 'site', 'all', 'A tick box under the basket on the cart page.', 'live'],
        'back_in_stock' => ['marketing', 'Back-in-Stock Alerts', 'A “notify me” form under Add to cart on sold-out products; emails everyone who asked, once each, when the shop is next visited after it restocks. Doubles as a demand list for what to reorder. Off by default, and sends nothing until you write the message.', false, 'Store → Ecommerce → Product page', 'ecommerce', 'product', 'mid', 'A notify-me form under Add to cart when sold out.', 'live'],
        'newsletter' => ['marketing', 'Email Capture', 'A signup form ([kbb_signup]) with an optional timed popup. Stores subscribers locally with one-click CSV export for any email tool. No API key. Off by default.', false, 'Appearance → Homepage', 'newsletter', 'home', 'bottom', 'The signup panel near the foot of the homepage.', 'elsewhere'],
        // ── Performance ──
        /*
         * RETIRED, NOT PORTED — and deliberately still here.
         *
         * The plugin's version does two things: it throttles the WordPress
         * heartbeat API and it dequeues WordPress asset bloat. This app is not
         * WordPress. There is no heartbeat to throttle and no plugin stylesheet
         * queue to dequeue, so there is nothing for the switch to switch.
         *
         * What the row's own description promises IS done, and done for every
         * page rather than behind a toggle — re-verified by running, not by
         * reading the row:
         *
         *   - `loading="lazy"` on every storefront image template, counted with
         *     `grep -rl 'loading="lazy"' resources/views` → 7 files.
         *   - three `preconnect` / `dns-prefetch` hints in
         *     resources/views/layouts/store.blade.php.
         *
         * A switch here could therefore only turn those OFF, which is not a
         * feature. So the honest row is one that says the work is already done
         * and offers no control, which is what `inherent` renders as.
         *
         * WHY THE ROW STAYS. `module_toggles` carries a `performance` row on
         * every install the seeder has ever run against, and this REGISTRY is
         * the only thing the Modules screen iterates — delete the row and that
         * stored value becomes something nobody can see or explain. It also
         * leaves the screen silently shorter, so the reader who remembers a
         * Performance module concludes it was lost rather than answered.
         *
         * It said `todo` until this lane, which the screen drew as "Not ported
         * yet" — a promise of unbuilt work — and it named `'Its own screen'`
         * with no console route, which drew as "screen not built yet". Both
         * told the owner something false about a module that is never going to
         * exist. Same pair of faults the `brands` and `product_sorting` rows
         * carried until they were corrected.
         */
        'performance' => ['performance', 'Performance & Speed', 'Lazy-loaded images and early connection hints, already applied to every page of this shop. The plugin version of this module also stripped WordPress bloat and throttled the WordPress heartbeat; neither exists here, so there is nothing left for a switch to do.', false, '', '', 'site', 'all', 'Lazy loading and connection hints, on every page. Nothing visible.', 'inherent'],
        // ── This app only ──
        // Not in the plugin. They are real module_toggles keys the storefront
        // already reads, so leaving them off this screen would make them the one
        // pair nobody can switch.
        'quick_view' => ['extra', 'Quick view', 'A Quick view button on product cards opening a modal with price, stock, short description and add-to-cart, so a shopper does not lose a filtered listing. Hidden on touch devices, where hover has no meaning.', false, 'No settings screen', '', 'grid', 'card', 'The Quick view button revealed on hover over every product card.', 'live'],
        'address_book' => ['extra', 'Address book', 'The saved-addresses screen at /my-account/edit-address: add, edit, delete and set a default per type. Turning this off hides the dashboard card and makes the page itself 404, not just the link.', true, 'Appearance → Login / Register panel → Links', 'acctpanel', 'site', 'all', 'The Addresses screen inside a signed-in customer account.', 'live'],
        'quantity_bundles' => ['extra', 'Quantity bundles', 'Buy-more-save-more tiers on the product page, generated from the price rather than authored.', true, 'Appearance → Quantity bundles', 'bundles', 'product', 'mid', 'The bundle tiles under the price on the product page.', 'live'],
        'dispatch_cutoff' => ['extra', 'Dispatch cutoff', 'The “order within X for dispatch today” line, counting down to your cutoff time.', true, 'Store → Ecommerce', 'ecommerce', 'product', 'mid', 'A line under the Add to cart button on the product page.', 'live'],
        /*
         * Lane PD, both ON: the owner asked for each in as many words (CLAUDE.md
         * rule 1 as reversed on 30 September), and each is a switch because it
         * is a design choice he may want back. Neither costs a query on a
         * product whose copy names no video and no HTML block.
         */
        'desc_videos' => ['extra', 'Videos in product descriptions', 'A video file address (.mp4, .webm, .mov, .m4v) or a [video] shortcode on a line of its own in a product description or an HTML Block plays as a video player, two side by side, as on the old site. Only this shop\'s own addresses and kbeautybliss.com are played; anything else stays text. Off: the address is printed as text, as before.', true, '', '', 'product', 'bottom', 'Inside the Description tab of a product whose copy names a video.', 'live'],
        'eblock_phone_columns' => ['extra', 'HTML Block columns on phones', 'An HTML Block laid out in three columns (the old site\'s ingredient rows) keeps its three columns side by side on a phone, as on the old site, with each picture above its name. Off: a phone stacks the columns one under another.', true, 'Content → HTML Blocks', 'htmlblocks', 'product', 'bottom', 'Inside the Description tab, on a phone, wherever an HTML Block has three columns.', 'live'],

        // ── SEO ──
        /*
         * The one place this registry deliberately diverges from the plugin's
         * own default, recorded here rather than left to be discovered.
         *
         * The plugin ships SEO Engine OFF because WordPress — with or without
         * Yoast — still writes a <title>, a canonical and an og:image when the
         * module is off. Nothing in this app does. App\Support\Seo is the only
         * thing that has ever produced a <head> here, and it has produced one
         * on every page since the layout was wired to it, ungated.
         *
         * So shipping the switch with the plugin's default would not "restore
         * the plugin's behaviour" — it would strip every meta description,
         * canonical, Open Graph tag and JSON-LD node off a live catalogue the
         * first time this package was applied, silently, with no visible
         * symptom on any page. On by default keeps what the storefront
         * already does; the owner can now turn it off on purpose, which is
         * what the switch is for.
         *
         * The settings screen is Store → SEO & Meta and has been real since
         * before 2.56.1; this row claimed it did not exist.
         */
        'seo_engine' => ['seo', 'SEO Engine', 'Meta titles & descriptions (with per-page overrides), Open Graph / Twitter cards, canonical, robots and Product / Organization schema. Turn it off to fall back to a plain page title and nothing else. On by default in this app — unlike the plugin, nothing else here writes a &lt;head&gt;.', true, 'Store → SEO & Meta', 'seo', 'site', 'all', 'Titles, descriptions and structured data. Nothing visible on the page.', 'live'],
        // ── Unknown ──
        // ── install flag ──
        // ── Carts started ──
        // ── Email captured ──
        // ── Recovery email sent ──
        // ── Recovered ──
    ];

    /** Devices a module can be limited to. */
    public const DEVICES = ['both' => 'Everywhere', 'desktop' => 'Desktop only', 'mobile' => 'Phones only'];

    private ?array $state = null;

    public function __construct(private SettingsService $settings) {}

    /**
     * Every module with its current state.
     *
     * Resolved once per request. A module absent from the saved list falls back
     * to the plugin's default, so applying this package changes nothing.
     *
     * @return array<string, array{on: bool, device: string}>
     */
    public function all(): array
    {
        if ($this->state !== null) {
            return $this->state;
        }

        $devices = $this->settings->get('module_devices', null);
        $devices = is_array($devices) ? $devices : (is_string($devices) ? json_decode($devices, true) : []);
        $devices = is_array($devices) ? $devices : [];

        $out = [];

        foreach (self::REGISTRY as $key => [$group, $name, $desc, $default, $screen]) {
            $row = ['device' => $devices[$key] ?? 'both'];

            $out[$key] = [
                // The same call the storefront makes, so this screen and the page
                // can never disagree about whether a module is on.
                'on' => $this->settings->moduleEnabled($key, $default),
                'device' => isset(self::DEVICES[$row['device'] ?? '']) ? $row['device'] : 'both',
            ];
        }

        return $this->state = $out;
    }

    /** Is this module on? Unknown keys are off, so a typo hides a feature rather than forcing one on. */
    public function on(string $key): bool
    {
        return (bool) ($this->all()[$key]['on'] ?? false);
    }

    /** Which devices it is allowed on. */
    public function device(string $key): string
    {
        return (string) ($this->all()[$key]['device'] ?? 'both');
    }

    /**
     * The class that hides a module on the devices it is not meant for.
     *
     * Returns an empty string when the module is off entirely — the caller is
     * expected to check on() first and render nothing at all in that case,
     * rather than shipping markup the shopper cannot see.
     */
    public function classFor(string $key): string
    {
        return match ($this->device($key)) {
            'desktop' => 'm-off',
            'mobile' => 'd-off',
            default => '',
        };
    }

    /** @param array<string, array{on?: bool, device?: string}> $values */
    public function save(array $values): void
    {
        $clean = [];

        foreach ($values as $key => $row) {
            if (! isset(self::REGISTRY[$key]) || ! is_array($row)) {
                continue;
            }

            // Written to module_toggles, which is where the storefront reads it.
            $this->settings->setModule($key, (bool) ($row['on'] ?? self::REGISTRY[$key][3]));

            $clean[$key] = isset(self::DEVICES[$row['device'] ?? '']) ? $row['device'] : 'both';
        }

        $this->settings->set('module_devices', $clean);
        $this->state = null;
    }

    /** How many are on, for the admin header. */
    public function counts(): array
    {
        $all = $this->all();
        $on = count(array_filter($all, static fn ($m) => $m['on']));

        return ['on' => $on, 'total' => count($all)];
    }
}
