<?php

declare(strict_types=1);

namespace App\Http\Controllers\Store;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Services\SettingsService;
use App\Support\Facets;
use App\Support\Url;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\View\View;

/**
 * Shop, category, brand and search archive.
 *
 * Filtering is server-side so every filtered view has its own indexable URL —
 * the previous build filtered in the browser, which meant Google could not index
 * a single filtered page across 671 products and 93 brands.
 */
class ShopController extends Controller
{
    /** Only the columns the card renders. The row also carries description,
     *  seo, meta_feed and images — several KB each, never used here.
     *  `created_at` is in the list because ProductLabels reads it for the
     *  "New" badge — while it was missing that badge could never fire on a
     *  listing, only on the product page. */
    private const CARD_COLUMNS = [
        'id', 'wc_id', 'slug', 'name', 'brand_id', 'price', 'sale_price',
        'sale_starts_at', 'sale_ends_at', 'stock_status', 'image',
        'rating', 'review_count', 'featured', 'position', 'type', 'total_sales',
        'created_at',
        /*
         * ▲ AND THE THREE A SET'S PRICE CANNOT BE READ WITHOUT. (Lane SG)
         *
         * App\Support\SetPricing::COLUMNS carries the argument in full. In
         * short: SetPricing::mode() and ::basis() read these off getAttributes()
         * and fall back to "no rule, no anchor" for an absent column, so a
         * narrow select does not fail -- it prices the set at the number in
         * `products.price`, which is a stale snapshot for a rule-priced set and
         * the pre-reduction figure for an anchored one. This grid showed one
         * price and the set's own page showed another.
         */
        ...\App\Support\SetPricing::COLUMNS,
    ];

    public function __construct(private SettingsService $settings) {}

    /** The one brand a single-brand listing is about, as banner() read it. (Lane PT) */
    private ?Brand $listingBrand = null;

    /**
     * @param  ?Category  $category  the row, when the caller has already got it.
     *
     * CategoryArchiveController resolves the category to decide between 200,
     * 301 and 404, and then handed the slug down here for a second
     * `select * from categories where slug = ?` against the row it was holding.
     * Every category archive on the site paid for that — 10 queries on the
     * fixture, 9 with it passed. Still optional, and still resolved from the
     * slug when it is not supplied, so any other caller is unaffected.
     */
    public function index(Request $request, ?string $categorySlug = null, ?Category $category = null): View|JsonResponse|\Illuminate\Http\RedirectResponse
    {
        // Facets::active() memoises in a process-level static. Under PHP-FPM
        // that is one request and harmless; in the test suite, a queue worker
        // or Octane it would hand this request the previous one's filters.
        Facets::reset();

        $active = Facets::active();
        $page = Facets::page();
        /*
         * Appearance → Site layout → Loading more products (Lane PI-B). With
         * the shipped "Arrows" this is `products_per_page`, exactly as it was;
         * "Load more on scroll" makes a page one batch, "Load all" makes it
         * SiteLayout::LOAD_ALL_CAP.
         *
         * Catalog → Pagination (Lane PG) decides first, below, once the
         * category is known: pagination off makes the page ListingPagination::
         * CAP. With pagination on — the shipped state — it is this same call.
         */

        /*
         * EVERY CARD COLUMN QUALIFIED WITH ITS TABLE.
         *
         * A search joins `brands` (applyFacets below), and `brands` carries a
         * column called id, one called slug, one called name, one called
         * position and one called created_at — five of the eighteen this list
         * asks for. Unqualified, MySQL answers "Column 'id' in field list is
         * ambiguous" and every search on the shop is a 500. SQLite is happy to
         * guess, which is exactly the MySQL-parity gap docs/MYSQL-PARITY.md
         * exists for, so this is qualified once here rather than discovered on
         * the live host.
         *
         * `products.name` and `name` select the same column when nothing is
         * joined, so the unsearched query is unchanged.
         */
        $query = Product::query()
            ->visible()
            ->select(array_map(static fn (string $c): string => 'products.' . $c, self::CARD_COLUMNS))
            ->with('brand:id,name,slug');

        $category ??= $categorySlug ? Category::where('slug', $categorySlug)->first() : null;

        // /shop/ and search are the 'shop' page; a category archive is its own.
        $pgKind = $category ? 'category' : 'page';
        $pgId = $category ? (int) $category->id : 'shop';
        $perPage = \App\Support\ListingPagination::perPage($pgKind, $pgId, (int) $this->settings->get('products_per_page', 24));

        if ($category) {
            // The category's products, with ITS OWN order beside them -- one
            // join on the pivot's key in place of the EXISTS this was. (Lane SO)
            // And its sub-categories' products, once each, when it lists them
            // (Lane SC): ids from the cached tree, no query of their own.
            \App\Support\ScopeOrder::inCategory($query, (int) $category->id, \App\Support\CategoryRollup::idsFor($category));
        }

        $search = (string) $request->query('s', '');
        // Kept, unsearched, for the spelling retry below -- a PHP clone, no SQL.
        $unsearched = $search !== '' ? clone $query : null;

        $this->applyFacets($query, $active, $search);
        // A category may open newest first (Catalog -> Categories -> Edit ->
        // Product order; 2.60.501). Read off the row already held: no query.
        $sortDefault = \App\Support\CategoryOrder::defaultFor($category);
        $this->applySort($query, Facets::sort($sortDefault), $category !== null);

        // Sold-out products as usual, last, or not at all (Lane SX): the
        // category's own choice, else the shop's -- /shop/ and search follow
        // the shop's. BEFORE the count, so "N products", every ?paged= batch
        // and the ItemList are all the same set. App\Support\SoldOut.
        \App\Support\SoldOut::apply($query, \App\Support\SoldOut::for($category));

        $total = (clone $query)->count();

        /*
         * SPELLING MISTAKES (Lane SR; Store -> Site Search -> Spelling
         * mistakes). Only a search that found NOTHING gets here, so every other
         * listing runs exactly the statements it ran before. "medicob" is
         * searched again as "Medicube"; when that finds products they are the
         * page, and the heading says so with a way back to what was typed
         * (?sfix=0 is that way back, and is never corrected).
         */
        $searchTyped = $search;
        $searchCorrected = null;

        if ($total === 0 && $unsearched !== null && $request->query('sfix') !== '0'
            && app(\App\Services\HeaderSettings::class)->get('search_fuzzy_enabled')
            && ($fixed = \App\Support\SearchSpelling::correct($search)) !== null) {
            $retry = clone $unsearched;
            $this->applyFacets($retry, $active, $fixed);
            $this->applySort($retry, Facets::sort($sortDefault), $category !== null);
            \App\Support\SoldOut::apply($retry, \App\Support\SoldOut::for($category));
            $found = (clone $retry)->count();

            if ($found > 0) {
                [$query, $total, $search, $searchCorrected] = [$retry, $found, $fixed, $fixed];
            }
        }
        $lastPage = max(1, (int) ceil($total / $perPage));

        /*
         * A page number past the end is not a page.
         *
         * forPage(min($page, $lastPage)) below clamps out-of-range requests
         * back onto page one, so every one of /shop/?paged=2, ?paged=57 and
         * ?paged=4000 answered 200 with the page-one grid -- and the canonical
         * Facets::canonicalUrl() then emitted for it was that same out-of-range
         * URL, self-referencing. That is an unbounded supply of crawlable,
         * self-canonicalising duplicates of page one, on /shop/ and on every
         * category archive, and Google will happily walk it: each fetch is
         * crawl budget taken off a product page, and each is a duplicate of a
         * page that is already indexed.
         *
         * 404 rather than a redirect or a canonical pointing back at page one,
         * for the same reason CategoryArchiveController 404s an unknown
         * category: the URL does not identify anything, and a 301 from an
         * unbounded space onto one real page is a soft 404 wearing a 301. Only
         * page numbers above the last one are affected -- page one, and every
         * page that really exists, are untouched, so the self-referencing
         * canonical on a genuine /shop/?paged=2 still stands.
         */
        /*
         * Pagination off (Catalog → Pagination, Lane PG): every product is on
         * page one, so an old ?paged=N address -- a crawler's index, a bookmark
         * -- goes there for good, filters and sort kept, rather than to a 404.
         * Only while the listing fits in the cap; past it the later pages are
         * real. The brand page's own rule, BrandController::show(). $total is
         * already counted, so this costs nothing.
         */
        if ($page > 1 && $total <= \App\Support\ListingPagination::CAP
            && \App\Support\ListingPagination::showsAll($pgKind, $pgId)) {
            return \App\Support\ListingPagination::toPageOne(Facets::pageUrl(1));
        }

        if ($page > 1 && $page > $lastPage) {
            abort(404);
        }

        $products = $query->forPage(min($page, $lastPage), $perPage)->get();

        /*
         * ONE STATEMENT FOR EVERY SET ON THIS PAGE, OR NONE AT ALL. (Lane SG)
         *
         * The three columns above let a set be priced by its RULE; this is what
         * makes reading that rule affordable. App\Support\SetPricing::prime()
         * looks first and returns without touching the database when none of
         * these rows is a set -- which is every page of this shop today, so
         * StorefrontQueryBudgetTest's ceilings do not move. With sets present it
         * is ONE grouped aggregate for all of them, flat in their number, in
         * place of the one-per-set tally() would otherwise run lazily from the
         * card. See prime()'s docblock for the two alternatives and why not.
         */
        \App\Support\SetPricing::prime($products);

        /*
         * THE NEXT BATCH FOR "LOAD MORE ON SCROLL" (Lane PI-B): the cards of
         * exactly this page, after exactly this query — see ListingBatch.
         */
        if (\App\Support\ListingBatch::wanted($request)) {
            return \App\Support\ListingBatch::respond(
                $products,
                $category?->t('name'),
                $page,
                $lastPage,
                $page < $lastPage ? Facets::pageUrl($page + 1) : null,
                Facets::pageUrl($page),
            );
        }

        [$title, $sub, $crumb] = $this->heading($category, $search);
        $crumbParents = $this->ancestorsOf($category);
        if ($category !== null) {
            /*
             * A category page names ITSELF at the end of the trail (Lane BC).
             * The owner, 10 October: "on the categories pages, the breakcrums
             * should say like Home > Collecton > Skincare sets". A top-level
             * category read "Home / Category" -- a placeholder word where its
             * name belongs, and a trail that disagreed with the BreadcrumbList
             * this page already gives Google (breadcrumbTrail(): Home -> Shop
             * -> parents -> the category). The visible trail now matches it:
             * Home / Shop / [parents /] the category.
             */
            $crumb = $category->t('name');
        }

        $banner = $this->banner($category, $active, $search, $title);

        /*
         * THE TITLE HEADER (Lanes PT and PY): a category's title and
         * description over its picture, or in the light box when it has none.
         * Null whenever the owner's own banner is on, and on /shop/ and a
         * search; for the one-brand listing, null unless the brand has a
         * picture (its light box is a separate switch, off) -- and a null
         * header is the page exactly as it was. No query of its own: the
         * category row is already loaded, with its own `header_style`, and the
         * one-brand listing reuses the row banner() just read.
         */
        $titleHeader = $category
            ? \App\Support\TitleHeader::forModel($category, $title, $banner)
            : \App\Support\TitleHeader::forModel($this->listingBrand, $this->listingBrand?->t('name') ?? $title, $banner, true);

        /*
         * THE CUSTOM HEADER AREA (Lane CH): the Super Sale page's header and
         * banner, on a category whose "Edit header" panel switched it on. It
         * replaces the title header and the plain heading block. Null for
         * every other category -- read from the row already loaded, and from
         * a setting the request has already loaded only when it is on.
         */
        $categoryHeader = $category ? app(\App\Services\CategoryHeaders::class)->forCategory($category, $title) : null;

        if ($categoryHeader !== null) {
            $titleHeader = null;
        }

        /*
         * THE CATEGORY BANNER (Lane CB): the brand page's Panel header on a
         * category with a picture -- its own Banner picture, else the one its
         * old header showed. The owner: "i need the categories banners, exact
         * same like brand banners", and "if there's banner, then the banner
         * should be picked auto by new design". It replaces the title header
         * and the Catalog banner the way the Panel does on a brand page; the
         * custom header area above still wins. Null for a category with no
         * picture on this server, or on "Category header -- as before": that
         * page is exactly as it was. Off the row already loaded and the settings map the
         * request has already read -- no query.
         */
        $catPanel = null;

        if ($category && $categoryHeader === null) {
            $layoutAll = app(\App\Services\SiteLayout::class)->all();

            $catPanel = \App\Support\BrandPanel::forCategory($category, $layoutAll, $title, $banner);

            if ($catPanel !== null) {
                $titleHeader = null;
            }
        }

        /*
         * A ONE-BRAND LISTING IS NAMED FOR ITS BRAND.              (2.60.346)
         *
         * The owner, on /shop/?filter_brands=celimax: "it showin one default
         * heading and text. show it either the brand name as per the url. or
         * remove it completely. this thing do only for such brand urls." It
         * read "Shop all" over "Authentic Korean skincare, curated for the
         * UAE." -- the unfiltered /shop/ heading, on a page of one brand.
         *
         * banner() has already read the brand row, so this costs no query. The
         * heading (and the tab title and the page schema, which said "Shop all"
         * too) take the brand's name, and the generic line goes. Only that one
         * path -- no category, no search, exactly one brand that exists --
         * because listingBrand is only ever set there. ShopBrandHeadingTest.
         */
        if (! $category && $this->listingBrand) {
            $title = (string) $this->listingBrand->t('name');
            $sub = '';
        }

        /*
         * PER-CATEGORY SEO OVERRIDES — `categories.seo`, unread until now.
         *
         * The same column, the same shape and the same story as `brands.seo`;
         * Store\BrandController::seoCtx() carries the reasoning in full and
         * this is the other half of it. Store → Catalog → Categories has been
         * collecting an SEO title and description, saving them into this
         * column and publishing neither, so a category archive — the highest
         * intent page on the site, which is what "korean sunscreen uae" lands
         * on — took its title from the bare category name and its description
         * from seoDescription() below whatever the owner typed.
         *
         * Through ProductSeo::normalise() for the reason given there: the
         * admin writes `seo.description` and the published vocabulary spells
         * that key `desc`, and ProductSeo::RENAME is the existing map between
         * them. Reusing it is what makes this the product mechanism rather
         * than a second one beside it.
         *
         * NULL FOR /shop/ AND FOR A SEARCH, which have no category and
         * therefore no row to carry an override.
         */
        $catSeo = $category ? (\App\Support\ProductSeo::normalise($category->seo) ?? []) : [];

        /*
         * THE CANONICAL OVERRIDE REPLACES THE CLEAN BASE URL, NOT THE WHOLE
         * CANONICAL — and that distinction is the only safe way to do it here.
         *
         * Facets::canonicalUrl() is what makes /shop/?paged=2 canonicalise to
         * itself rather than to page one; its own docblock records why
         * collapsing later pages is worse than the crawl cost of indexing
         * them. Substituting the owner's URL for the whole canonical would
         * reintroduce exactly that: every page of a category, and every
         * filtered view of it, claiming to be one document. Substituting it
         * for the base the method builds FROM keeps pagination and facet
         * collapsing behaving as they do on every other listing.
         *
         * Url::absolute(), never Url::to(): the owner's path already carries
         * whatever language it meant, and to() would strip that and apply this
         * reader's. absolute() passes a full http(s) URL through untouched.
         */
        $canonicalBase = trim((string) ($catSeo['canonical'] ?? ''));
        $listingUrl = $canonicalBase !== ''
            ? Url::absolute($canonicalBase)
            : $this->absoluteListingUrl($category);

        /*
         * WHAT THIS PAGE IS, AND WHICH PRODUCTS ARE ON IT.
         *
         * A category archive published no @type of its own: sitewide
         * Organization, sitewide WebSite, a BreadcrumbList, and nothing at all
         * saying the document is a list of products or naming one of them.
         * `collection` is now that statement -- see App\Support\Seo's
         * CollectionPage branch for the shape and App\Support\CollectionSchema
         * for why the price in it is a decimal string and not the fils column.
         *
         * ── ONLY WHEN THE CANONICAL IS THIS PAGE ──────────────────────────
         *
         * Facets::canonicalUrl() collapses every filtered and every sorted view
         * of an archive onto the clean archive URL, deliberately: a sort order
         * is not a new document. But the twenty-four rows THIS request drew are
         * the filtered ones, and attaching them to a canonical that names a
         * different document states that the other document contains them. That
         * is the same defect as a canonical pointing at the wrong address --
         * the thing five Arabic page types did before 2.60.109 -- wearing an
         * ItemList instead of a <link>. So the list is built only when the
         * canonical this page emits IS this page.
         *
         * Search is caught by the same test without naming it: /shop/?s=foo
         * canonicalises to /shop/, so a search result set is never published as
         * the shop's list.
         *
         * THE TEST IS Facets::narrowed(), NOT URL EQUALITY, and the difference
         * matters. On page one a filtered view's canonical and the clean
         * listing URL are the same string -- /shop/?filter_brands=cosrx
         * canonicalises to /shop/ -- so comparing the two reports
         * "self-canonical" for precisely the case this exists to exclude, and
         * the shop published three COSRX products as the whole catalogue's
         * list. Measured against a running preview, which is how it was found.
         * narrowed() is canonicalUrl()'s own filter test, extracted so there is
         * one copy of the rules and not two that can drift.
         */
        $canonical = Facets::canonicalUrl($listingUrl);

        /*
         * AND NEVER WHEN THE OWNER HAS TYPED A CANONICAL. An override in
         * Catalog -> Categories -> SEO names a document this controller did not
         * render and whose contents it does not know; the rows below are this
         * page's, and hanging them off that URL would describe somebody else's
         * page. The override case keeps the CollectionPage node -- what it
         * points at is still a collection -- and carries no list.
         */
        $selfCanonical = $canonicalBase === '' && ! Facets::narrowed();

        // Appearance → Site layout → Product grid → "Filters · laptop" and
        // "Filters button · phone" (Lane SO). Both off, as shipped: no filter
        // column is drawn, so its two lists are not read either.
        $layout = app(\App\Services\SiteLayout::class);
        $filtersD = (bool) $layout->get('filters_d');
        $filtersM = (bool) $layout->get('filters_m');
        $filters = $filtersD || $filtersM;

        return view('store.shop', [
            'filtersD' => $filtersD,
            'filtersM' => $filtersM,
            // Under the category banner the Catalog banner is not drawn on its
            // own -- its picture is the panel's background (Lane CB).
            'banner' => $catPanel === null ? $banner : null,
            'titleHeader' => $titleHeader,
            'catPanel' => $catPanel,
            'categoryHeader' => $categoryHeader,
            /*
             * THE ARCHIVE'S CATEGORY, FOR THE TILE'S EYEBROW.          Lane PG
             *
             * The unified product card takes its small upper-case line as a
             * caller's string rather than reading `$product->categories`, so
             * that this page — and the related rail, and /routines — do not
             * start paying a `category_product` read they do not pay today.
             * A category archive knows its own category; /shop, a search and a
             * brand filter have none, and hand the card null.
             */
            'category' => $category,
            'products' => $products,
            'total' => $total,
            'page' => $page,
            'lastPage' => $lastPage,
            'cols' => Facets::columns(),
            'sorts' => Facets::sortLabels(),
            'curorder' => Facets::sort($sortDefault),
            'buckets' => Facets::buckets(),
            'title' => $title,
            'seoCtx' => array_filter([
                /*
                 * A title the owner typed is the WHOLE title — `title_is_final`
                 * stops Seo::render() appending the site name through
                 * `seo_title_template`, which is exactly how
                 * Store\ProductController::show() treats a per-product title.
                 * Both keys are null when the box is empty and array_filter
                 * drops them, so an un-overridden archive is byte-for-byte the
                 * page it was.
                 */
                'title' => trim((string) ($catSeo['title'] ?? '')) !== '' ? $catSeo['title'] : null,
                'title_is_final' => (trim((string) ($catSeo['title'] ?? '')) !== '') ?: null,
                /*
                 * AND THE ONE TOKEN THAT BRANCH CANNOT RESOLVE ON ITS OWN.
                 *
                 * `title_is_final` sends the typed title through
                 * Seo::titleOf()'s template branch, and
                 * TitleTemplate::render() DELETES every token it was not
                 * handed. `%%title%%` is Yoast's word for the post title —
                 * here the CATEGORY's own name — and Seo cannot work it out
                 * from `title`, which is the template itself. Left out, an
                 * owner typing Yoast's shipped default `%%title%% %%sep%%
                 * %%sitename%%` into Store → Catalog → Categories → SEO →
                 * Page title publishes the site name alone, exactly as all 671
                 * imported product pages did before the same key was added to
                 * Store\ProductController.
                 *
                 * t(), like every other string on this page: an Arabic archive
                 * whose tab reads the English category name advertises itself
                 * as untranslated where a shopper decides whether to click.
                 *
                 * NULL WHENEVER THE BOX IS EMPTY — and null for /shop/ and for
                 * a search, which have no category at all. array_filter below
                 * drops it, so an un-overridden archive hands Seo exactly the
                 * keys it handed before and is byte-for-byte the page it was.
                 */
                'title_token' => trim((string) ($catSeo['title'] ?? '')) !== ''
                    ? $category?->t('name')
                    : null,
                'description' => trim((string) ($catSeo['desc'] ?? '')) !== ''
                    ? $catSeo['desc']
                    : $this->seoDescription($category, $search, $total),
                /*
                 * The share image is the hero this page actually draws.
                 *
                 * Every category archive published the store-wide default share
                 * image, so a category with its own banner photograph shared as
                 * the generic shop card. $banner is already resolved above for
                 * the view — this reads the same value rather than deciding a
                 * second time, so the picture in the share card and the picture
                 * at the top of the page cannot disagree.
                 *
                 * PageBanner::resolve() has already dropped the image for the
                 * styles that never draw one (tint, no-image), which is why
                 * this is the right key to read and `categories.banner` is not:
                 * a banner switched off still has a URL in the column, and
                 * publishing it would share a photograph the page does not show.
                 *
                 * Null — no banner, or a search/filter page that has none —
                 * falls through to og_default_image, unchanged.
                 */
                /*
                 * An explicit og_image override wins over the banner, exactly
                 * as it does on a product (`$override['og_image'] ?? $product->image`).
                 *
                 * `categories.image` is STILL not read, here or anywhere: it
                 * has no storefront consumer at all, so publishing it as an
                 * og:image would share a picture that appears nowhere on the
                 * page. The banner stays the fallback because the banner is
                 * the hero this page actually draws.
                 */
                'image' => trim((string) ($catSeo['og_image'] ?? '')) !== ''
                    ? $catSeo['og_image']
                    : (is_string($banner['image'] ?? null) && $banner['image'] !== '' ? $banner['image'] : null),
                'url' => $canonical,
                /*
                 * `collection` on every listing this controller serves -- the
                 * shop root and every category archive. The type is set even
                 * when there is no list to carry (a filtered view), because the
                 * canonical it points at IS a collection page and saying so is
                 * true either way; og:type is unaffected, Seo::render() maps
                 * everything that is not a product or an article to `website`.
                 *
                 * The offset is the number of rows before this page's first,
                 * computed from the SAME clamped page number forPage() used
                 * above, so page two of Serums publishes positions 25..48 and a
                 * clamped out-of-range page cannot publish positions past the
                 * end of the catalogue.
                 */
                'type' => 'collection',
                'collection' => $selfCanonical
                    ? \App\Support\CollectionSchema::from(
                        $products,
                        rtrim((string) (\App\Models\Setting::map()['site_url'] ?? ''), '/'),
                        (min($page, $lastPage) - 1) * $perPage
                    ) + ['name' => $title]
                    : null,
                /*
                 * A category the owner has marked noindex is noindexed on
                 * EVERY view of itself — page two, a filtered view, a sort —
                 * because this is read once for the archive and not per facet.
                 * Store\SeoFilesController drops the same categories from the
                 * sitemap, so the two documents cannot disagree.
                 */
                'noindex' => ! empty($catSeo['noindex']) ?: null,
                'breadcrumb' => $this->breadcrumbTrail($category, $crumbParents),
                // SEO → Keywords (Lane KW): which page's keywords this is. Only
                // the unfiltered listing; a filtered view is a different page.
                'seo_entity' => $selfCanonical ? ($category ? 'category:' . $category->id : 'collection:shop') : null,
            ], static fn ($v) => $v !== null),
            'sub' => $sub,
            // "Showing results for Medicube · Search instead for medicob" (Lane SR).
            'searchCorrected' => $searchCorrected,
            'searchTyped' => $searchTyped,
            'crumb' => $crumb,
            // (Lane BC) The "Shop" step on a category's trail, linking the
            // whole-shop listing, as the BreadcrumbList already does. Null on
            // /shop/ and search, whose trail is unchanged.
            'crumbShop' => $category !== null ? \App\Support\Url::to('/shop/') : null,
            // The category's parents, root first, as links before the crumb
            // (Lane CH). Empty for a top-level category, which therefore
            // renders byte for byte as before.
            'crumbParents' => array_map(
                static fn (Category $c) => ['name' => $c->t('name'), 'url' => $c->url()],
                $crumbParents
            ),
            'clearUrl' => $category ? $category->url() : Facets::clearUrl(),
            'chips' => $this->chips($active),
            // The sidebar is identical for every visitor and only changes with
            // the catalogue, so it is cached rather than recounted per view.
            // Ordered by the curated `position` FIRST, then by size.
            //
            // It was ordered by size alone, which meant the category reorder in
            // Store → Catalog → Categories wrote `categories.position` and
            // nothing on the storefront ever read it: the owner could reorder
            // the tree all day and this list never moved. "Most products" is
            // not a merchandising decision, and it is not one the owner asked
            // for.
            //
            // Backward compatible by construction: `position` defaults to 0 on
            // every row and nothing has ever written it, so until the owner
            // actually reorders something, every row ties at 0 and the size
            // ordering below decides exactly as before.
            'cats' => ! $filters ? collect() : $this->sidebarCats(),
            // Same reasoning as the categories above: `brands.position` has
            // existed since the original schema and nothing has ever read it,
            // so the brand reorder had nowhere to show up. Ties at 0 fall back
            // to alphabetical, which is what this did before.
            'brands' => ! $filters ? collect() : Cache::remember('kbb.shop.brands', 900, fn () => Brand::query()
                ->select('id', 'name', 'slug')
                ->withCount(['products' => fn ($q) => $q->visible()])
                ->groupBy('brands.id', 'brands.name', 'brands.slug', 'brands.position')
                ->having('products_count', '>', 0)
                ->orderBy('brands.position')
                ->orderBy('name')
                // Same as the categories above; brand names are not unique.
                ->orderBy('brands.id')
                ->limit(40)
                ->get()),
        ]);
    }

    /**
     * The filter rail's categories with their counts, cached 15 minutes.
     *
     * Lane SC: while any category with sub-categories lists their products,
     * a parent's count is the number its own page lists -- each product once
     * -- not just the products filed directly under it, and a parent whose
     * products are all in its children is offered at all. Counted for the
     * whole tree in ONE query (CategoryRollup::counts()), and the empty rows,
     * the order and the 30-row cut done on those counts. With nothing rolling
     * up, the original query, under the original key, unchanged.
     */
    private function sidebarCats(): \Illuminate\Support\Collection
    {
        if (\App\Support\CategoryRollup::hasRollups()) {
            return Cache::remember(\App\Support\CategoryRollup::cacheKey(\App\Support\CategoryRollup::SIDEBAR_CACHE), 900, static fn () => \App\Support\CategoryRollup::applyCounts(
                Category::query()->select('id', 'name', 'slug', 'position')
                    ->withCount(['products' => fn ($q) => $q->visible()])
                    ->get(),
                static fn ($a, $b) => [(int) $a->position, -(int) $a->products_count, (int) $a->id]
                    <=> [(int) $b->position, -(int) $b->products_count, (int) $b->id],
                30,
            ));
        }

        return Cache::remember('kbb.shop.cats', 900, fn () => Category::query()
            ->select('id', 'name', 'slug')
            ->withCount(['products' => fn ($q) => $q->visible()])
            ->groupBy('categories.id', 'categories.name', 'categories.slug', 'categories.position')
            ->having('products_count', '>', 0)
            ->orderBy('categories.position')
            ->orderByDesc('products_count')
            // And `categories.id`, because this is a LIMIT: a tie on the
            // count at the thirtieth place decides which category the
            // filter rail offers at all.
            ->orderBy('categories.id')
            ->limit(30)
            ->get());
    }

    /**
     * The banner for whatever page this request actually is, or null.
     *
     * WHAT COUNTS AS A BRAND PAGE, given U-05.
     *
     * A brand has no path of its own. Brand::url() is
     * /shop/?filter_brands={slug} and the contract says so in as many words —
     * "this must not be 'improved' into a pretty URL". So the brand's listing
     * is this controller, reached through a query parameter, and the only
     * honest definition of "the Estée Lauder page" available here is: the
     * brand facet holds exactly one slug, and nothing else is narrowing the
     * results.
     *
     * The three exclusions are all cases where the banner would be a lie
     * rather than a decoration:
     *
     *   - two or more brands selected. /shop/?filter_brands=a,b is a
     *     comparison, not a brand page; showing one of the two brands' banners
     *     across the top of it would be picking a winner at random.
     *   - a category also selected. The heading already says "Cleansers", and
     *     a brand banner over a category-narrowed grid describes neither.
     *   - a search term. The page is a result set.
     *
     * Deliberately NOT excluded: price, sale, in-stock and paging. Those
     * narrow the grid without changing what the page is about, and dropping
     * the banner on page 2 of a brand would look like a bug.
     *
     * One extra query, only on the single-brand path, and only to fetch the
     * two columns this needs. The category needs none — it is already loaded.
     */
    private function banner(?Category $category, array $active, string $search, string $title): ?array
    {
        /*
         * Cleared first, on every path. The router keeps ONE controller
         * instance per route, so in any process that serves more than one
         * request (the test suite, a queue worker, Octane) a brand read here
         * for /shop/?filter_brands=celimax was still set when /shop/?s=toner
         * returned early below -- and that search would be titled "Celimax".
         */
        $this->listingBrand = null;

        if ($category) {
            return \App\Support\PageBanner::forModel($category, $title);
        }

        $oneBrand = count($active['brand']) === 1 && ! $active['cat'] && $search === '';

        if (! $oneBrand) {
            return null;
        }

        // The header columns ride on the same query, for the title header
        // (Lane PT) -- one row, one statement, as before.
        $brand = Brand::query()
            ->select('id', 'name', 'banner', 'description', 'logo', 'header_image', 'header_title', 'header_subtitle', 'header_description')
            ->where('slug', $active['brand'][0])
            ->first();

        $this->listingBrand = $brand;

        // The fallback heading is catalogue text — see BrandController::show().
        return \App\Support\PageBanner::forModel($brand, $brand?->t('name') ?? $title);
    }

    /**
     * The Arabic plan for a search, read once per request (index() applies the
     * facets more than once). Null when there is nothing to plan, or when the
     * plan cannot be built at all -- the English path then runs as before.
     */
    private function arabicPlan(string $search): ?array
    {
        $attrs = request()->attributes;
        $key = 'kbb.ar_plan.' . md5($search);

        if (! $attrs->has($key)) {
            try {
                $plan = \App\Support\ArabicSearch::plan($search);
            } catch (\Throwable) {
                $plan = [];
            }
            $attrs->set($key, $plan === [] ? null : $plan);
        }

        return $attrs->get($key);
    }

    private function applyFacets($query, array $active, string $search): void
    {
        /*
         * (Lane AR round 3) An Arabic search, read in Arabic: the same plan the
         * header box uses (App\Support\ArabicSearch), as sub-selects of this
         * same statement. Only a query with Arabic letters takes this branch, so
         * every English search below runs exactly as it did. A plan that finds
         * nothing leaves the page at 0, and index() goes on to the spelling fix
         * exactly as before (it calls this again with the corrected English).
         */
        $arabicPlan = $search !== '' && \App\Support\ArabicSearch::isArabic($search) ? $this->arabicPlan($search) : null;

        // A query that is nothing but a brand ("أنوا") is searched as the brand's
        // English name, below -- the very rows and order the English page gives
        // for "Anua", as the header box does (SearchController::buildArabic()).
        if ($arabicPlan !== null && ($brandId = \App\Support\ArabicSearch::brandOnly($arabicPlan)) !== null) {
            $brand = \Illuminate\Support\Facades\Cache::remember('kbb.search.brandnames', 900,
                fn () => \App\Models\Brand::query()->select('id', 'name', 'slug')->get())->firstWhere('id', $brandId);

            if ($brand !== null) {
                [$arabicPlan, $search] = [null, (string) $brand->name];
            }
        }

        if ($arabicPlan !== null) {
            $query->where(fn ($w) => \App\Support\ArabicSearch::apply($w, $arabicPlan, \App\Support\ArabicSearch::ready()));
        } elseif ($search !== '') {
            // Expanded before matching: "moisturiser" has to reach a product
            // labelled "Moisturizer", and "sun cream" has to reach "sunscreen".
            // Matching the raw string returns nothing and the shopper concludes
            // the shop does not stock it.
            //
            // Also note the escaping. The old code interpolated the term
            // straight into the pattern, so a shopper typing "50%" searched for
            // "anything, then 50, then anything" -- not a SQL injection, since
            // the value is still bound, but wrong results all the same.
            $terms = \App\Support\SearchTerms::expand($search);

            /*
             * ── ONE LEFT JOIN, NOT A CORRELATED EXISTS PER TERM PER ROW ─────
             *
             * orWhereHas('brand', …) compiles to
             *   exists (select * from brands
             *           where products.brand_id = brands.id and brands.name like ?)
             * which the planner evaluates once per candidate row, per search
             * term. On 3,025 products that is the dominant cost of the COUNT
             * that decides the pagination, and the COUNT runs on every search
             * before a single card is rendered.
             *
             * WHY THE JOIN IS BEHAVIOUR-IDENTICAL AND NOT MERELY EQUIVALENT-
             * LOOKING. products.brand_id is a single nullable foreign key onto
             * the brands primary key, so the join matches AT MOST ONE row per
             * product: it cannot multiply rows, which is the only way a join
             * ever changes a COUNT or a result set. LEFT, not INNER, so a
             * product with brand_id NULL — or pointing at a brand that has been
             * deleted — stays in the result exactly as it did under EXISTS, and
             * `brands.name like ?` is NULL for it, which is not true, which is
             * the same answer EXISTS gave. Product::brand() is a plain
             * belongsTo with no constraints and Brand has no soft deletes, so
             * there is nothing in the relation for the join to leave out.
             *
             * Measured rather than assumed, and the numbers are in the lane
             * report. tests/Feature/ShopSearchJoinTest.php pins the result set,
             * the ordering and the count against the EXISTS form it replaces,
             * on a search matching by product name only, by brand name only, by
             * both, and by neither.
             */
            $query->leftJoin('brands', 'products.brand_id', '=', 'brands.id');

            $query->where(function ($q) use ($terms, $search) {
                // Every word, in any order, as the search box does
                // (SearchTerms::words()). brands is joined above.
                \App\Support\SearchTerms::orWhereEveryWord($q, $search, ['products.name', 'products.sku', 'brands.name']);

                foreach ($terms as $term) {
                    \App\Support\SearchTerms::orWhereLike($q, 'products.name', $term);
                    \App\Support\SearchTerms::orWhereLike($q, 'products.sku', $term);
                    \App\Support\SearchTerms::orWhereLike($q, 'brands.name', $term);
                }
            });
        }

        if ($active['cat']) {
            /*
             * Lane SC: a parent in the filter rail is counted with its
             * sub-categories' products (sidebarCats()), so ticking it narrows
             * to the same set. Ids from the cached tree; when no ticked
             * category has children that it lists, the SQL is as it was.
             */
            $ids = \App\Support\CategoryRollup::expandSlugs(array_values(array_map('strval', $active['cat'])));

            if ($ids !== null) {
                $query->whereHas('categories', fn ($q) => $q->whereIn('categories.id', $ids));
            } else {
                $query->whereHas('categories', fn ($q) => $q->whereIn('categories.slug', $active['cat']));
            }
        }

        if ($active['brand']) {
            $query->whereHas('brand', fn ($q) => $q->whereIn('slug', $active['brand']));
        }

        if ($active['price'] && isset(Facets::BUCKETS[$active['price']])) {
            [, $min, $max] = Facets::BUCKETS[$active['price']];

            /*
             * Bucketed on the price the SHOPPER IS CHARGED, not on the `price`
             * column.
             *
             * `price` is the pre-sale figure. Reading it here meant a product
             * marked down from AED 200 to AED 50 printed AED 50 on its card and
             * was then filed under "AED 150 – 300", absent from "AED 54 – 150":
             * a shopper filtering by budget was shown everything except the
             * discounted stock, with a Sale badge on the cards that survived.
             *
             * App\Support\EffectivePrice is Product::effectivePrice() in SQL,
             * scheduling window included, so the filter and the card cannot
             * disagree. Bucket bounds are declared in whole AED.
             */
            \App\Support\EffectivePrice::whereRange(
                $query,
                $min === null ? null : $min * 100,
                $max === null ? null : $max * 100,
            );
        }

        if ($active['sale'] === '1') {
            // Product::isOnSale(), not the raw columns. `sale_price IS NOT NULL
            // AND sale_price < price` is true the moment a markdown is
            // scheduled, so a sale set up for next week was listed under "On
            // sale" today — at full price, with no Sale badge, because
            // ProductLabels draws that badge from isOnSale() and the two
            // disagreed.
            \App\Support\EffectivePrice::whereOnSale($query);
        }

        if ($active['instock'] === '1') {
            $query->where('stock_status', 'instock');
        }
    }

    private function applySort($query, string $orderby, bool $inCategory = false): void
    {
        /*
         * QUALIFIED, for the same reason the select list above is: a search
         * joins `brands`, and `name`, `position`, `id` and `created_at` all
         * exist on both tables. An unqualified ORDER BY across that join is
         * ambiguous on MySQL and a coin toss on SQLite. Nothing is joined on an
         * unsearched listing, where `products.name` and `name` are the same
         * column and the plan is identical.
         */
        match ($orderby) {
            'popularity' => $query->orderByDesc('products.total_sales'),
            // Same reasoning as the price bucket above: "Price: low to high"
            // has to mean the price on the card. Sorting on the `price` column
            // put an AED 50 markdown where AED 200 belongs, near the end of the
            // cheapest-first list the shopper opened to find it.
            'plow' => \App\Support\EffectivePrice::orderBy($query, 'asc'),
            'phigh' => \App\Support\EffectivePrice::orderBy($query, 'desc'),
            'rating' => $query->orderByDesc('products.rating')->orderByDesc('products.review_count'),
            'date' => $query->orderByDesc('products.created_at'),
            'name' => $query->orderBy('products.name'),
            // "Featured" is the curated order the Sorting module maintains.
            default => $this->applyDefaultSort($query, $inCategory),
        };

        /*
         * AND THEN `id`, WHATEVER THE SHOPPER PICKED.
         *
         * Every arm above leaves ties, and several leave nothing but ties.
         * `rating` and `review_count` are 0 for most of this catalogue, so
         * "Sort by: average rating" is one enormous tied block; `total_sales`
         * ties across the whole tail; `created_at` ties for every product the
         * importer wrote in the same second, which is all of them.
         *
         * This method's caller pages the result with forPage(), and LIMIT /
         * OFFSET only partitions a list when the order is total. Page 1 and
         * page 2 are two separate requests running two separate queries, and
         * where the order does not decide between two rows, nothing obliges
         * the second query to break the tie the way the first one did. The
         * shopper sees the same product on both pages and never sees the one
         * it displaced.
         *
         * The tie-break runs in the same direction as the sort it follows, so
         * "most popular" and "cheapest" both keep reading the way they look.
         * It CANNOT reorder a list that was already ordered -- a final key
         * only ever decides between rows every earlier key called equal.
         */
        if (in_array($orderby, ['popularity', 'rating', 'date'], true)) {
            $query->orderByDesc('products.id');
        } else {
            $query->orderBy('products.id');
        }
    }

    /**
     * "Featured" — the shop's default sort, and the one surface the
     * `product_sorting` module actually governs.
     *
     * The curated order: on a category page that category's own order, and
     * on /shop/ and search `products.position` (Lane SO; ScopeOrder). Store →
     * Catalog → Reorder (CatalogReorderApiController) writes the former. This is the plugin's
     * own idea: WordPress's `menu_order` baked into WooCommerce's "Default
     * sorting". Off, the column is simply not consulted and the default view
     * falls back to featured-first, then alphabetical — which is exactly what
     * this query did before a curated order existed at all.
     *
     * This gate is the whole module. Before it, `position` was in the ORDER BY
     * unconditionally and the switch on Store → Modules changed nothing
     * whatsoever, while the registry advertised it as `live`.
     *
     * Deliberately NOT gated: the `menu_order` option of the [kbb_products]
     * shortcode (App\Support\Shortcodes). That is an explicit, per-shortcode
     * request for the curated order, not the default sort the module is about,
     * and silently ignoring an author's explicit choice is a different bug.
     */
    private function applyDefaultSort($query, bool $inCategory = false)
    {
        /*
         * YOUR ORDER FIRST, "featured" only as a tie-break (2.60.402). The
         * owner: "the re-order ... on front-end the same old sorting is
         * showing ... there's two products showing on front-end on top of the
         * list, but in the backend that's not #1 and #2". Featured came FIRST,
         * so every featured product jumped the curated order on every shop,
         * category and Shop-all-brand listing. Featured still decides between
         * products the owner has not ordered (position ties at 0).
         */
        /*
         * A CATEGORY PAGE READS ITS OWN ORDER, NOT THE SHARED ONE. (Lane SO)
         * The owner: "when i did the sorting of Super Sale category, then it
         * also effected the Medicube brand's sorting too ... NO ANY CATEGORY OR
         * BRAND should disturb the sorting of each other". Each category's
         * Reorder lives on its own pivot rows (App\Support\ScopeOrder); /shop/
         * and search are no category and keep `products.position`.
         */
        if ($this->settings->moduleEnabled('product_sorting', true)) {
            $inCategory
                ? \App\Support\ScopeOrder::orderInCategory($query)
                : $query->orderBy('products.position');
        }

        $query->orderByDesc('products.featured');

        return $query->orderBy('products.name');
    }

    /**
     * A real, page-specific meta description instead of falling back to one
     * sitewide default everywhere — every category, search, and the general
     * shop page gets its own, distinct text. Duplicate meta descriptions
     * across a catalogue's category pages is flagged as a real quality
     * signal problem, not just a missed opportunity, so this isn't
     * cosmetic. Kept deliberately short (under ~130 characters) rather than
     * padded out to the full 160-character budget — accurate and concise
     * reads better than stretched, and Google truncates hard past 155-160
     * on desktop and roughly 120 on mobile regardless.
     */
    /**
     * BreadcrumbList schema's own trail, not the single visual label
     * `heading()` returns — search-engine breadcrumb schema needs the
     * real ancestor chain with URLs (Home → Shop → Category), which
     * nothing in this controller was building until now; the schema
     * renderer itself (Seo::jsonLd()) has accepted a 'breadcrumb' context
     * key from the start, but no controller ever actually supplied one.
     */
    /**
     * The category's parents, root first. (Lane CH)
     *
     * NO QUERY for a top-level category -- `parent_id` is already on the row.
     * Under a parent: the chain is walked in ProductTabs' cached id => parent
     * map (one cache read, shared with the product page) and the ancestors
     * are fetched in ONE query, however deep. Bounded, so a loop in the data
     * cannot spin.
     *
     * @return list<Category>
     */
    private function ancestorsOf(?Category $category): array
    {
        if ($category === null || $category->parent_id === null) {
            return [];
        }

        $tree = \App\Support\ProductTabs::categoryTree();
        $ids = [];
        $node = (int) $category->parent_id;

        while ($node !== 0 && ! in_array($node, $ids, true) && $node !== (int) $category->id && count($ids) < 10) {
            $ids[] = $node;
            $node = (int) ($tree[$node] ?? 0);
        }

        $rows = Category::query()->whereIn('id', $ids)->get(['id', 'slug', 'name', 'parent_id', 'path', 'short_url'])->keyBy('id');

        $out = [];
        foreach (array_reverse($ids) as $id) {
            if (isset($rows[$id])) {
                // Hand each ancestor its parent from this same set, so a row
                // with a null `path` builds its address without a query per
                // level (CategoryPathWalkCostTest).
                $pid = $rows[$id]->parent_id === null ? null : (int) $rows[$id]->parent_id;
                $rows[$id]->setRelation('parent', $pid !== null ? ($rows[$pid] ?? null) : null);
                $out[] = $rows[$id];
            }
        }
        if ($out !== []) {
            $category->setRelation('parent', end($out));
        }

        return $out;
    }

    /** @param list<Category> $parents */
    private function breadcrumbTrail(?Category $category, array $parents = []): array
    {
        $base = rtrim((string) (\App\Models\Setting::map()['site_url'] ?? ''), '/');
        /*
         * TRANSLATED, THOUGH NOTHING ON THE PAGE SHOWS IT — Lane FB.
         *
         * This is BreadcrumbList JSON-LD, which is the trail Google prints
         * beneath the result. On an Arabic page an English trail is the same
         * defect as an English heading, minus the part where anybody would
         * notice. The two keys are the ones the visible crumb already uses.
         */
        $trail = [
            ['name' => __('store.breadcrumb.home'), 'url' => $base . '/'],
            ['name' => __('store.breadcrumb.shop'), 'url' => $base . '/shop/'],
        ];

        foreach ($parents as $parent) {
            $trail[] = ['name' => $parent->t('name'), 'url' => $base . $parent->url()];
        }

        if ($category) {
            $trail[] = ['name' => $category->t('name'), 'url' => $base . $category->url()];
        }

        return $trail;
    }

    /**
     * Category::url() (like Product::url()) is deliberately root-relative
     * for <a href> links — a canonical tag needs the real, absolute URL,
     * so site_url is prepended by hand here rather than reused as-is.
     */
    private function absoluteListingUrl(?Category $category): string
    {
        $base = rtrim((string) (\App\Models\Setting::map()['site_url'] ?? ''), '/');

        return $base . ($category ? $category->url() : '/shop/');
    }

    /**
     * NO DELIVERY PROMISE IN A META DESCRIPTION.
     *
     * All three of these ended in a transit time attached to one country, and
     * this is the description on the category archive, the search results and
     * /shop — so it went to every visitor of those pages AND into the search
     * result Google shows for them.
     *
     * It was the hardest delivery promise left anywhere in this application,
     * for two reasons rather than one. It named a country, like the checkout,
     * the home page, the order confirmation and the product page before their
     * repairs. And the window it named is one the shop does not record and does
     * not agree with: `delivery_default_text`, the owner's own wording, is
     * "1–3 days fast delivery all over UAE". A shopper in Dubai who chose this
     * shop from a search result offering a one-day window has been told two
     * different things by one shop before they have clicked anything.
     *
     * A META DESCRIPTION CANNOT BE PER-VISITOR, which is why the machinery the
     * rest of this lane uses is deliberately NOT applied here. There is one
     * description per URL, a crawler is one of the readers, and varying it by a
     * guessed geo header would mean serving search engines something different
     * from shoppers — for a promise, which is the worst thing to do it with.
     *
     * So the clause is removed rather than localised, and nothing replaces it:
     * everything these still say is a count of real rows.
     *
     * THE ONE THIS LANE DID NOT TOUCH is `seo_default_description`, the
     * site-wide fallback, which also carries a delivery claim. That one is the
     * owner's to write — it is a real field on Store → SEO (SETTING_RULES:
     * 'seo_default_description' => ['text', 'Default description']) — and
     * rewriting a setting he may already have edited is not this lane's to do.
     */
    private function seoDescription(?Category $category, string $search, int $total): string
    {
        // (Lane AR round 2) Interface strings, so /ar gets an Arabic description;
        // the English is the same sentence word for word (InterfaceStrings).
        if ($category) {
            $count = $total
                ? (string) __('store.wording.seo_category_count', ['total' => $total])
                : (string) __('store.wording.seo_category_none');

            return (string) __('store.wording.seo_category', ['name' => (string) $category->t('name'), 'count' => $count]);
        }

        if ($search !== '') {
            return (string) __($total === 1 ? 'store.wording.seo_search_one' : 'store.wording.seo_search_many', ['search' => $search, 'total' => $total]);
        }

        return (string) __('store.wording.seo_shop', ['total' => $total]);
    }

    private function heading(?Category $category, string $search): array
    {        if ($category) {
            /*
             * The category's own name and description are CATALOGUE rows, not
             * interface strings — they reach Arabic through the translations
             * table against their own id (App\Support\HasTranslations), which
             * is why they are not keyed here. Only the fallback, used when the
             * category has no description, is this file's to say.
             *
             * THAT WAS THE INTENTION AND NOT THE CODE. Until this lane these
             * read `$category->name` and `$category->description`, which is the
             * column and therefore the English — so the comment above described
             * a mechanism the page did not use, and an Arabic category archive
             * carried an English <h1>. t() is that mechanism.
             *
             * `description` is one of TranslationStore::LONG_FIELDS, so it is
             * fetched by this page rather than carried in the map that every
             * Arabic request loads. One category, one row, one query — and the
             * `?:` still asks the TRANSLATED value, so a category whose Arabic
             * description is blank falls back to its English one and only a
             * category with no description in either language reaches the
             * keyed default.
             */
            return [
                $category->t('name'),
                $category->t('description') ?: __('store.shop.sub_default'),
                __('store.shop.crumb_category'),
            ];
        }

        if ($search !== '') {
            // The term is the shopper's own words and is passed through, never
            // translated.
            return [
                __('store.shop.title_search', ['term' => $search]),
                __('store.shop.sub_search'),
                __('store.shop.crumb_search'),
            ];
        }

        return [
            __('store.shop.title_all'),
            __('store.shop.sub_default'),
            __('store.breadcrumb.shop'),
        ];
    }

    /**
     * Removable chips for whatever is currently applied.
     *
     * The two lookups are batched. Selecting eight brands used to mean eight
     * separate `select name from brands where slug = ?` round trips just to
     * label the chips above the grid.
     */
    private function chips(array $active): array
    {
        $chips = [];

        $catNames = $active['cat']
            ? Category::whereIn('slug', $active['cat'])->pluck('name', 'slug')
            : collect();

        $brandNames = $active['brand']
            ? Brand::whereIn('slug', $active['brand'])->pluck('name', 'slug')
            : collect();

        foreach ($active['cat'] as $slug) {
            $name = $catNames[$slug] ?? null;
            if ($name) { $chips[] = ['key' => 'cat', 'value' => $slug, 'label' => $name]; }
        }

        foreach ($active['brand'] as $slug) {
            $name = $brandNames[$slug] ?? null;
            if ($name) { $chips[] = ['key' => 'brand', 'value' => $slug, 'label' => $name]; }
        }

        if ($active['price'] && isset(Facets::BUCKETS[$active['price']])) {
            $chips[] = ['key' => 'price', 'value' => $active['price'], 'label' => Facets::bucketLabel($active['price'])];
        }

        if ($active['sale'] === '1') { $chips[] = ['key' => 'sale', 'value' => '1', 'label' => __('store.shop.chip_on_sale')]; }
        if ($active['instock'] === '1') { $chips[] = ['key' => 'instock', 'value' => '1', 'label' => __('store.shop.chip_in_stock')]; }

        return $chips;
    }

    /** Call after any catalogue write, or the sidebar counts go stale. */
    public static function flushSidebarCache(): void
    {
        Cache::forget('kbb.shop.cats');
        \App\Support\CategoryRollup::forgetLists();
        Cache::forget('kbb.shop.brands');
    }
}
