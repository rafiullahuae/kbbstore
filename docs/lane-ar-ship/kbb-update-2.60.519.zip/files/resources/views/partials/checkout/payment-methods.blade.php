{{--
    The payment options list — the inside of #payment, factored out of
    checkout.blade.php so the one-tap Browsed add re-renders the exact markup
    the page itself rendered, rather than a second copy that could drift.

    Why this has to move at all when the bag changes: PayShipRules enforces a
    Cash-on-delivery order-value window, and the window is measured against the
    order TOTAL — which shipping, the free-delivery threshold and the new line
    all feed. So adding one product can take Cash on delivery off the table (or
    put it back). A summary that updates while this list stands still leaves the
    shopper holding a method place() will refuse at the last step, which is the
    exact confusion one-tap adding is meant to remove.

    Inputs: $gateways, $codHidden.
    Optional: $selectedMethod — the id to keep checked when it is still offered;
              $payNotice      — said out loud when the selection had to move.
--}}
@php
    // One rule for which radio is checked, so the page and the refresh cannot
    // disagree: the asked-for method when it is still on offer, otherwise the
    // first one. Never "nothing checked" — a payment section with no selection
    // posts no payment_method at all and fails validation on Place order.
    $payIds = array_column($gateways, 'id');
    $payChecked = in_array($selectedMethod ?? null, $payIds, true)
        ? ($selectedMethod ?? null)
        : ($payIds[0] ?? null);

    // Appearance → Checkout page → Payment boxes. Null under "Today", and then
    // nothing below prints a byte it did not print before (pinned by
    // CheckoutPaymentBoxesTest). Asked of the service rather than the page's
    // own $kbbCoPage because the fragment refresh renders this partial alone.
    // Each logo is a PaymentMarkArt constant chosen by gateway id -- never a
    // setting's bytes -- so the label prints it raw. It is written inline
    // after the fee, with no comment or line of its own, because a Blade
    // comment still leaves its line behind and "Today" may not gain a byte --
    // and `</label>` shares its line: PHP swallows the newline that follows
    // the @endif's closing tag, but Blade keeps the one after a raw echo, so a
    // line break here would add one under "Today" (CheckoutPaymentBoxesTest
    // caught exactly that). Never write PHP's closing-tag characters in these
    // comments either: inside a // comment they still end PHP mode.
    $payBoxes = app(\App\Services\CheckoutPage::class)->paymentBoxes();
    $kbbApRow = app(\App\Services\CheckoutPage::class)->applePayRow($gateways);
@endphp
@if (!empty($payNotice))<p class="pay-note pay-moved" role="status" aria-live="polite">{{ $payNotice }}</p>@endif
@if ($gateways === [] && empty($payNotice))
{{-- A CHECKOUT WITH NOTHING TO PAY WITH SAYS SO.

     PaymentProviderSeeder installs all four gateways switched off, so a shop
     that has not yet been through Store → Payments renders this step as an
     empty list under a live Place order button. Pressing it answered "The
     payment method field is required." — a validation message about a field
     that was never on the page, which reads as the shopper's mistake. Walked
     end to end in Chromium: zero radios, that sentence, no way forward.

     The wording is the one fragments() already uses when the last method is
     withdrawn by a quantity change, so the page says the same thing however
     the shopper arrives at it. --}}
<p class="pay-note pay-empty" role="status" aria-live="polite">{{ __('store.checkout.no_payment_method') }}</p>
@endif
            <ul class="wc_payment_methods payment_methods methods">
            @if (!empty($codHidden))<p class="pay-note">{{ $codHidden }}</p>@endif
            @foreach ($gateways as $g)
            <li class="wc_payment_method payment_method_{{ $g['id'] }}{{ empty($payBoxes['brand'][$g['id']]) ? '' : ' pay-brand' }}">
    <input id="payment_method_{{ $g['id'] }}" type="radio" class="input-radio" name="payment_method" value="{{ $g['id'] }}" @checked($g['id'] === $payChecked) data-order_button_text="" />

    <label for="payment_method_{{ $g['id'] }}">
        {{ (class_exists(\App\Support\ArabicWording::class) ? \App\Support\ArabicWording::of($g['title']) : (string) ($g['title'])) }}
        {{-- The fee, right on the option — not only in the paragraph below,
             which is easy to miss until after it has already been chosen. --}}
        @if (!empty($g['fee_html']))<span class="codfee">{!! $g['fee_html'] !!}</span>@endif{!! empty($payBoxes['logos'][$g['id']]) ? '' : '<span class="pay-logo pay-logo-'.e($g['id']).'" aria-hidden="true">'.$payBoxes['logos'][$g['id']].'</span>' !!}    </label>
            @if ($g['description'] || $g['id'] === 'stripe')
            {{-- Shown purely by :has() on .kbb-checkout below, matching how
                 the selected-option highlight on this same list already
                 works — no JS, and correct for whichever option is checked
                 rather than only ever the first one.

                 THE CONDITION NAMES THE CARD GATEWAY, and it has to. This box
                 is drawn for a description, and the card fields live inside it
                 so that the same `:has(input:checked)` rule reveals them. The
                 owner asked for the paragraph above the fields to go, so
                 StripeGateway::description() now returns null — and a box
                 rendered only when there is a description would have taken the
                 card fields away with the words, which is a checkout that
                 cannot take a card. --}}
            <div class="payment_box payment_method_{{ $g['id'] }}">
            @if ($g['description'])<p>{!! (class_exists(\App\Support\ArabicWording::class) ? \App\Support\ArabicWording::payLine($g['description']) : (string) ($g['description'])) !!}</p>@endif
            {{-- The card fields, for the one gateway that has any. Inside the
                 same .payment_box as its description, so the existing
                 `:has(input:checked)` rule in kbb-checkout.css reveals them
                 exactly when Credit / Debit Card is selected and hides them
                 otherwise — no JavaScript deciding visibility, and correct in
                 the re-render this partial gets after a quantity or coupon
                 change as well as on first paint. --}}
            @if ($g['id'] === 'stripe')@include('partials.checkout.stripe-card')@endif
        </div>
            @endif
    </li>
@if ($g['id'] === 'stripe' && $kbbApRow)
{{-- 2.60.495, his words: "I need the APPLE PAY only, with same icon ... payment
     option inside the payment methods again, on no 2, under stripe card".
     Drawn HIDDEN and shown by the wallet script only once Stripe says this
     device can pay with Apple Pay. The radio has NO name: it is never posted,
     and the list checkout.js reports to the server (payment_method radios
     only) is exactly the list of gateways, so nothing on the server changes.
     Apple Pay pays through the card gateway; partials/checkout/express-wallets
     posts payment_method=stripe for it, as it always has. --}}
            <li class="wc_payment_method payment_method_applepay{{ $payBoxes === null ? '' : ' pay-brand' }}" data-kbb-ap-li hidden>
    <input id="payment_method_applepay" type="radio" class="input-radio" data-kbb-ap-pick autocomplete="off" />
    <label for="payment_method_applepay">
        {{ __('store.checkout.apple_pay') }}<span class="pay-logo pay-logo-applepay" aria-hidden="true">{!! \App\Support\PaymentMarkArt::checkoutLogo('applepay') !!}</span>    </label>
            </li>
@endif
            @endforeach
        </ul>
