<?php

declare(strict_types=1);

namespace App\Http\Controllers\Store;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Support\Facades\Cache;
use App\Models\ProductVariant;
use App\Services\CartService;
use App\Services\Checkout\BasketRelease;
use App\Services\Checkout\UnfinishedPayment;
use App\Services\CouponService;
use App\Services\SettingsService;
use App\Support\Money;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * Cart page, mini-cart drawer, and the endpoints behind both.
 *
 * The drawer and the page are rendered from the same partials on the server and
 * swapped in whole. Two renderers for one cart is how the two drift apart — the
 * WordPress build had exactly that problem until it moved to fragments.
 *
 * Rule 27: one query for the cart, one for its lines with products and brands
 * eager loaded, and only the product columns a line actually renders.
 */
class CartController extends Controller
{
    /** Columns a cart line needs. The rest of the row is never read here. */
    private const LINE_COLUMNS = [
        'id', 'wc_id', 'slug', 'name', 'brand_id', 'price', 'sale_price',
        'sale_starts_at', 'sale_ends_at', 'stock_status', 'image', 'sku', 'type',
        /*
         * ▲ AND THE THREE A SET'S PRICE CANNOT BE READ WITHOUT. (Lane SG)
         *
         * ═══════════════════════════════════════════════════════════════════
         * THIS ONE WAS MONEY, NOT DISPLAY.
         * ═══════════════════════════════════════════════════════════════════
         *
         * App\Support\SetPricing::mode() and ::basis() read these columns off
         * getAttributes() and fall back to "no rule, no anchor" when they were
         * not selected -- so effectivePrice() on a row hydrated from THIS list
         * answered `products.price`, which for a rule-priced set is the figure
         * the editor last wrote and for an anchored one is the price before the
         * reduction. Measured on a three-set fixture whose members had since
         * been marked down: the page offered AED 166.50, AED 160.00 and
         * AED 145.00 and this list priced the same three rows at AED 180.00,
         * AED 175.00 and AED 160.00. See App\Support\SetPricing::COLUMNS.
         */
        ...\App\Support\SetPricing::COLUMNS,
    ];

    /**
     * What SetStockReconciler took out of the basket on this request, so
     * payload() can hand the page the sentence that says so. Empty on every
     * request that changed nothing, which is every request on a shop with no
     * set in anybody's basket. (Lane SEC)
     *
     * @var list<array{product: string, set: string, removed: int, left: int}>
     */
    private array $setStockNotices = [];

    public function __construct(
        private CartService $carts,
        private CouponService $coupons,
        private SettingsService $settings,
    ) {}

    public function page(Request $request): View
    {
        /*
         * (Lane BK) A shopper back from a payment they did not finish -- the
         * Back button, a tab closed and reopened later, a timed-out provider --
         * gets their basket here, before loadCart() would mint them an empty
         * one. Session-only gate: an ordinary basket view runs no query for it.
         */
        if (UnfinishedPayment::due($request)) {
            [$outcome] = app(UnfinishedPayment::class)->recover($request, shopperCameBack: false);

            if ($outcome === BasketRelease::RESTORED || $outcome === BasketRelease::MERGED) {
                $request->session()->now(UnfinishedPayment::BACK_KEY, $outcome);
            }
        }

        return view('store.cart', $this->payload($this->loadCart($request), $request));
    }

    public function add(Request $request): JsonResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer'],
            'variant_id' => ['nullable', 'integer'],
            'quantity' => ['nullable', 'integer', 'min:1', 'max:99'],
        ]);

        $product = Product::query()->select(self::LINE_COLUMNS)->visible()->find($data['product_id']);

        if (! $product) {
            return response()->json(['ok' => false, 'error' => __('store.wording.msg_product_na')], 404);
        }

        $variant = null;
        if (! empty($data['variant_id'])) {
            $variant = ProductVariant::where('product_id', $product->id)->find($data['variant_id']);

            if (! $variant) {
                return response()->json(['ok' => false, 'error' => __('store.wording.msg_option_na')], 404);
            }
        }

        /*
         * A VARIABLE PRODUCT IS BOUGHT BY ITS VARIATION, AND THIS ENDPOINT LET
         * IT BE BOUGHT WITHOUT ONE — FOR NOTHING.
         *
         * `variant_id` is `nullable` above and that is right: a simple product
         * has no variant to send. What was missing is the other half of the
         * pair — that a VARIABLE product must send one. Left out, the parent
         * row goes to CartService::add(), which prices it
         * `$variant?->effectivePrice() ?? $product->effectivePrice()`; a
         * variable parent's `price` column is NULL, effectivePrice() casts that
         * to 0, and the basket took a line at AED 0 that the checkout would
         * then collect. See Product::requiresVariant().
         *
         * BEFORE THE STOCK TEST, because the parent row's own `stock_status`
         * is usually `instock` and would wave it straight through; and because
         * "choose a size" is the truer sentence for a shopper who has not
         * chosen one than "sold out" would be.
         *
         * The same refusal shape as the two guards around it — `ok`, a
         * sentence, 422 — which is what cart.js already renders.
         */
        if (! $variant && $product->requiresVariant()) {
            return response()->json([
                'ok' => false,
                'error' => __('store.wording.msg_choose_option'),
            ], 422);
        }

        if (($variant?->stock_status ?? $product->stock_status) !== 'instock') {
            return response()->json(['ok' => false, 'error' => __('store.wording.msg_sold_out')], 422);
        }

        $cart = $this->carts->current($request);
        $this->carts->add($cart, $product, (int) ($data['quantity'] ?? 1), $variant);

        // Analytics (Lane AN): one add to cart, for the board's funnel. One
        // INSERT; never throws; refuses bots, admins and the owner's addresses.
        \App\Services\Analytics\Tracker::record($request, 1);

        return $this->fragments($this->loadCart($request), $request, 'Added to bag', null, true);
    }

    /**
     * "Buy these together": every ticked product, one request.        (Lane RB)
     *
     * The owner: "whatever products are checked and user click on Buy 4 items
     * together [...] all those will add to the cart."
     *
     * ONE REQUEST AND NOT FOUR, so the panel opens once, repaints once and the
     * shopper sees every line arrive together — and so a refusal can name the
     * product it is about. Mounted from routes/buy-together.php, throttled
     * there; CSRF like every storefront POST.
     *
     * EVERY LINE IS RE-CHECKED HERE, exactly as add() checks one: the product
     * must be visible (published, not hidden, not scheduled, not deleted), a
     * product that is sold by its options must arrive WITH one of its own, and
     * what is added must be in stock. The price is the server's — nothing the
     * browser sends says what anything costs. A line that fails is named in the
     * answer; the others still go in.
     */
    public function addTogether(Request $request): JsonResponse
    {
        $data = $request->validate([
            'items' => ['required', 'array', 'min:1', 'max:'.(int) \App\Services\BuyTogetherSettings::SCHEMA['count'][4]['max']],
            'items.*.product_id' => ['required', 'integer', 'min:1'],
            'items.*.variant_id' => ['nullable', 'integer', 'min:1'],
            // (Lane RE) The product whose page the section was on. It says
            // which section the press came from and nothing else: no price,
            // no percentage and no group handle is ever read off a request.
            'main_id' => ['nullable', 'integer', 'min:1'],
        ]);

        // One line per product, in the order the shopper sees them.
        $wanted = [];

        foreach ($data['items'] as $item) {
            $id = (int) $item['product_id'];
            $wanted[$id] ??= empty($item['variant_id']) ? null : (int) $item['variant_id'];
        }

        $products = Product::query()->select(self::LINE_COLUMNS)->visible()
            ->whereIn('id', array_keys($wanted))->get()->keyBy(fn ($p) => (int) $p->id);

        $variantIds = array_values(array_filter($wanted));
        $variants = $variantIds === [] ? collect() : ProductVariant::query()
            ->whereIn('id', $variantIds)->get()->keyBy(fn ($v) => (int) $v->id);

        $cart = null;
        $added = 0;
        $failed = [];
        // product id => the cart line it went into, for the bundle below.
        $lines = [];

        foreach ($wanted as $id => $variantId) {
            $product = $products->get($id);

            if (! $product) {
                $failed[] = ['id' => $id, 'why' => __('store.buy_together.gone')];

                continue;
            }

            $name = $product->t('name');
            $variant = null;

            if ($variantId !== null) {
                $variant = $variants->get($variantId);

                if (! $variant || (int) $variant->product_id !== $id) {
                    $failed[] = ['id' => $id, 'why' => __('store.buy_together.option_gone', ['name' => $name])];

                    continue;
                }
            }

            if (! $variant && $product->requiresVariant()) {
                $failed[] = ['id' => $id, 'why' => __('store.buy_together.choose_option', ['name' => $name])];

                continue;
            }

            if (($variant?->stock_status ?? $product->stock_status) !== 'instock') {
                $failed[] = ['id' => $id, 'why' => __('store.buy_together.sold_out_named', ['name' => $name])];

                continue;
            }

            try {
                $cart ??= $this->carts->current($request);
                $lines[$id] = (int) $this->carts->add($cart, $product, 1, $variant)->id;
                $added++;
            } catch (\Throwable $e) {
                report($e);
                $failed[] = ['id' => $id, 'why' => __('store.buy_together.not_added', ['name' => $name])];
            }
        }

        $this->groupTogether($cart, $lines, $data['main_id'] ?? null);

        $toast = $added === 0 ? null : ($added === 1
            ? __('store.buy_together.added_one')
            : __('store.buy_together.added', ['count' => $added]));
        $error = $failed === [] ? null : implode(' ', array_column($failed, 'why'));

        $response = $this->fragments($this->loadCart($request), $request, $toast, $error, $added > 0 && $failed === []);
        $out = $response->getData(true);

        /*
         * SOME IN, SOME NOT: one sentence that says both. cart.js shows `toast`
         * whenever it is set, and `added` is false here, so the sentence is
         * shown as text whatever "When something is added" is set to — a
         * refusal must be read, not acknowledged with a tick.
         */
        if ($added > 0 && $error !== null) {
            $out['toast'] = $toast.' '.$error;
        }

        $out['ok'] = $added > 0;
        $out['added_count'] = $added;
        $out['failed'] = array_column($failed, 'id');

        return response()->json($out, $added > 0 ? 200 : 422);
    }

    /**
     * Make what one press added a "Buy these together" bundle — or don't.
     *                                                                (Lane RE)
     *
     * The bundle discount is for a bundle the SECTION made, so every condition
     * here is checked on the server, against what this request actually put in
     * the basket:
     *
     *   - three to six lines went in, and no more than the section shows
     *     ("How many products");
     *   - the press names the product whose page it came from (`main_id`), and
     *     that product is still on sale;
     *   - every other product is one that page's section could have offered
     *     (BuyTogether::allowedCompanions()).
     *
     * Fail any and the products are still in the basket — they were on sale and
     * the shopper asked for them — just not grouped, so not discounted. The
     * group handle is minted by CartService::group(); the percentage is not
     * decided here at all but on every pricing pass from settings, by
     * App\Services\BuyTogetherPricing.
     *
     * @param  array<int, int>  $lines  product id => cart line id
     */
    private function groupTogether($cart, array $lines, mixed $mainId): void
    {
        if ($cart === null || count($lines) < \App\Services\BuyTogetherPricing::MIN_GROUP || ! $mainId) {
            return;
        }

        $config = app(\App\Services\BuyTogetherSettings::class)->all();

        if (empty($config['on']) || count($lines) > (int) $config['count']) {
            return;
        }

        $main = Product::query()->visible()->find((int) $mainId);

        if ($main === null) {
            return;
        }

        $others = array_values(array_diff(array_keys($lines), [(int) $main->id]));
        $allowed = app(\App\Services\BuyTogether::class)->allowedCompanions($main, $others);

        if (count($allowed) !== count($others)) {
            return;
        }

        $this->carts->group($cart, array_values($lines));
    }

    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'item_id' => ['required', 'integer'],
            'quantity' => ['required', 'integer', 'min:0', 'max:99'],
        ]);

        $cart = $this->loadCart($request, create: false);

        if ($cart) {
            $this->carts->updateQuantity($cart, (int) $data['item_id'], (int) $data['quantity']);
        }

        return $this->fragments($this->loadCart($request), $request);
    }

    public function remove(Request $request): JsonResponse
    {
        $data = $request->validate(['item_id' => ['required', 'integer']]);

        $cart = $this->loadCart($request, create: false);

        if ($cart) {
            $this->carts->remove($cart, (int) $data['item_id']);
        }

        return $this->fragments($this->loadCart($request), $request, 'Removed');
    }

    public function coupon(Request $request): JsonResponse
    {
        $data = $request->validate([
            'code' => ['nullable', 'string', 'max:60'],
            'remove' => ['nullable', 'boolean'],
        ]);

        $cart = $this->loadCart($request);

        if ($request->boolean('remove')) {
            $cart->forceFill(['coupon_id' => null])->save();

            return $this->fragments($this->loadCart($request), $request, 'Coupon removed');
        }

        $result = $this->coupons->validate((string) ($data['code'] ?? ''), $cart, $request->user('customer')?->email);

        if (! $result['ok']) {
            return $this->fragments($cart, $request, null, $result['error']);
        }

        $cart->forceFill(['coupon_id' => $result['coupon']->id])->save();

        return $this->fragments($this->loadCart($request), $request, 'Coupon applied');
    }

    /**
     * Read-only view of what the server believes is in the cart.
     *
     * Exists so "the cart is empty" can be diagnosed by opening a URL rather
     * than by shipping another diagnostic file. It reports the cookie, the cart
     * row, the lines and the totals — no writes, nothing sensitive.
     */
    public function debug(Request $request): JsonResponse
    {
        $cart = $this->loadCart($request, create: false);
        $all = \App\Models\Cart::query()
            ->where('status', 'active')
            ->latest('id')
            ->limit(5)
            ->get(['id', 'token', 'customer_id', 'status', 'created_at'])
            ->map(fn ($c) => [
                'id' => $c->id,
                'token' => substr((string) $c->token, 0, 8) . '…',
                'items' => $c->items()->count(),
                'created' => (string) $c->created_at,
            ]);

        return response()->json([
            'cookie_present' => $request->hasCookie(CartService::COOKIE),
            'cookie_value' => substr((string) $request->cookie(CartService::COOKIE), 0, 8) . '…',
            'resolved_cart_id' => $cart?->id,
            'resolved_item_count' => $cart?->itemCount() ?? 0,
            'lines' => $cart?->items->map(fn ($i) => [
                'item_id' => $i->id,
                'product_id' => $i->product_id,
                'name' => $i->product?->name,
                'qty' => $i->quantity,
            ]) ?? [],
            'recent_active_carts' => $all,
            'products_visible' => \App\Models\Product::visible()->count(),
            'url_resolution' => \App\Support\Url::debugBase(),
            'sample_links' => [
                'cart' => \App\Support\Url::to('/cart/'),
                'checkout' => \App\Support\Url::to('/checkout/'),
                'cart_api' => \App\Support\Url::to('/api/cart'),
            ],
            'hint' => 'More than one recent cart with items means the cookie is not being sent back. '
                . 'If sample_links lack the /kbb-upgrade prefix, url_resolution shows why.',
        ], 200, [], JSON_PRETTY_PRINT);
    }

    /** The drawer alone, for the header cart button. */
    public function drawer(Request $request): JsonResponse
    {
        $cart = $this->loadCart($request, create: false);
        $payload = $this->payload($cart, $request);

        return response()->json([
            'ok' => true,
            'count' => $payload['totals']['item_count'],
            'html' => $this->drawerHtml($payload),
        ]);
    }

    /**
     * Everything /cart and the drawer read off a basket line, in a fixed number
     * of queries however many lines there are.
     *
     * ── WHAT THE OLD DOCBLOCK CLAIMED, AND WHAT IT LEFT OUT ─────────────────
     *
     * It said "one query for the cart, one for its lines with products and
     * brands", and every relation it named was indeed loaded. The list was
     * short by ONE, and the missing one was the only relation on this page that
     * is read inside the line loop:
     *
     *     store/cart-inner.blade.php:170   $attrs = $item->variant?->label()
     *
     * ProductVariant::label() reads `attributeValues`, a belongsToMany over
     * `product_variant_attribute_value`. Unloaded, Eloquent fetches it the
     * moment it is touched — one join per variant line, with a singular
     * `where "product_variant_attribute_value"."product_variant_id" = ?` rather
     * than an `in (...)`.
     *
     * MEASURED on /cart, squeeze layout, one variable line per product:
     *
     *     lines        1    2    3    5    8
     *     total      10   11   12   14   17      (+1 per line, exactly)
     *     attribute_values reads
     *                  1    2    3    5    8
     *
     * and 10 flat from one line to eight with the entry below in place. See
     * docs/q8-cart-eager-loads.md for how those requests were measured — a
     * warm-up pass, and two memos reset — and for the one artifact of measuring
     * this in a test process at all.
     *
     * Store\CheckoutController::loadCart() has carried
     * `items.variant.attributeValues` all along — CartService::lineLabel()
     * refuses to read the relation unless it is loaded, so the checkout had to
     * — and /checkout measures FLAT at 12 queries from one line to eight. The
     * cart drew the same label off the same relation with nothing loaded. This
     * line is that list's entry, spelled exactly as the checkout spells it so
     * the two screens cannot drift into loading different columns of it.
     *
     * CartLineEagerLoadTest is the pin, and it asserts the SHAPE — the cost of
     * eight lines equals the cost of one — rather than a number, because a
     * total is a ceiling that a generous budget hides an N+1 inside.
     */
    /**
     * ONE JAR, CLAIMED TWICE — reconciled before the page is drawn. (Lane SEC)
     *
     * A basket holding a set AND a product that is inside it asked for the same
     * unit twice and could not be paid for at all: Place order answered "1025
     * Dokdo Toner (in Medicube booster set) is sold out" for ever, because
     * nothing the shopper could press changed the basket. The owner's decision
     * is that the LOOSE LINE GOES AND THE SET STAYS, and it happens here —
     * while they are looking at the basket — rather than inside place(), so the
     * subtotal, the item count and the free-delivery bar all describe what is
     * actually left. See App\Services\SetStockReconciler.
     *
     * AFTER the load and not before it: the reconciler reads the set membership
     * rows SetEagerLoad has just fetched, so it costs no query of its own for
     * those. A basket with no set in it costs NOTHING AT ALL — one cached
     * settings read and an in-memory scan — which is why the ceilings in
     * StorefrontQueryBudgetTest do not move.
     *
     * AND THE SECOND HYDRATION ONLY HAPPENS WHEN A LINE ACTUALLY WENT. The
     * relation in memory still describes the basket as it was, and every figure
     * the page prints is read off it.
     */
    private function loadCart(Request $request, bool $create = true)
    {
        $cart = $this->carts->current($request, create: $create);

        $this->hydrate($cart);

        $took = app(\App\Services\SetStockReconciler::class)->reconcile($cart);

        if ($took !== []) {
            $this->hydrate($cart);
        }

        /*
         * ACCUMULATED ACROSS THE REQUEST, NOT ASSIGNED. Several methods on this
         * controller call loadCart() TWICE — remove() and coupon() each load
         * once to do the work and again to render the reply. The second call
         * finds a basket this one has already reconciled and correctly reports
         * that it took nothing, so an assignment here would throw away the
         * sentence the first call earned and the reply would say "Removed" with
         * no explanation of why a second line went with it.
         */
        $this->setStockNotices = array_merge($this->setStockNotices, $took);

        return $cart;
    }

    /**
     * What a cart page, a drawer and every write fragment need loaded, in one
     * batch. Split out of loadCart() so the reconciler above can ask for it
     * again after it has taken a line out, without the two copies drifting.
     */
    private function hydrate($cart): void
    {
        $cart?->load([
            'items' => fn ($q) => $q->orderBy('id'),
            'items.product' => fn ($q) => $q->select(self::LINE_COLUMNS),
            'items.product.brand:id,name,slug',
            // `sku` added so this set is a superset of the drawer composer's,
            // which now stands down rather than loading its own copy.
            'items.variant:id,product_id,sku,price,sale_price,image,stock_status',
            // store/cart-inner.blade.php calls $item->variant?->label(), which
            // reads this. Same three columns as
            // Store\CheckoutController::loadCart(), which is the list this one
            // was short of.
            'items.variant.attributeValues:id,attribute_id,name',
            // (Lane VPA) the axis, so a line reads "Shade: #13 Bright Beige".
            // Runs only when a line HOLDS a variant with values.
            'items.variant.attributeValues.attribute:id,name,position',
            'coupon:id,code,type,amount',
        ]);

        /*
         * The set members, and ONLY when a line is a set. (Lane SET)
         *
         * Deliberately not three more entries in the list above: Laravel runs a
         * relation's query whether or not any parent needs it, so that would
         * cost three queries on every cart render of a shop that has never made
         * a set. This looks first and returns without a query when there is no
         * set in the bag, which is every basket in this shop today — the
         * ceilings in StorefrontQueryBudgetTest do not move. With a set in the
         * bag it is three queries for the whole page, whether the set holds two
         * members or thirty. See App\Support\SetEagerLoad.
         */
        if ($cart !== null) {
            \App\Support\SetEagerLoad::on($cart->items->pluck('product'));
        }

        // Said AFTER the load, and unconditionally: this method always fetches,
        // so whatever a mutation changed a moment ago is in hand before the
        // drawer is told it need not look.
        if ($cart !== null) {
            $this->carts->markDisplayLoaded();
            // (Lane VPA) name each line's shade now, so the mini cart's own
            // reload of these lines need not read the values again.
            app(\App\Support\VariantLabels::class)->fill($cart->items);
        }
    }

    /**
     * The drawer fragment, rendered from the payload computed HERE.
     *
     * The flag is what stops CartDrawerComposer filling the same partial in a
     * second time from its own look at the request. A composer runs after the
     * data handed to a view and overwrites it, and on the first add of a
     * session that meant the panel was painted EMPTY over a payload that was
     * already correct: the cart is created during that request and its cookie
     * only goes out on the response, so the composer's cookie test said there
     * was nothing to show.
     */
    private function drawerHtml(array $payload): string
    {
        return view('partials.cart-drawer', $payload + [
            \App\View\Composers\CartDrawerComposer::SUPPLIED => true,
        ])->render();
    }

    private function payload($cart, Request $request): array
    {
        $country = (string) $this->settings->get('store_country', 'AE');

        // Browsed and the heart tab (Lane HLB), one query between them; neither
        // is wanted when the drawer is not being drawn for display.
        [$browsed, $wish] = $request->boolean('skip_browsed')
            ? [collect(), collect()]
            : $this->lists($request);

        $empty = [
            'item_count' => 0, 'subtotal' => 0, 'discount' => 0, 'coupon_code' => null,
            'shipping' => 0, 'total' => 0, 'free_shipping_threshold' => null,
            'free_shipping_remaining' => null, 'free_shipping_unlocked' => false,
            'free_shipping_percent' => null, 'vat' => null,
            // The same keys CartService::totals() returns, so a partial that
            // reads one of them off an empty basket finds the key rather than
            // an undefined-index notice. An empty basket is taxed at nothing on
            // no basis, which is what nulls here say.
            'taxable_base' => 0, 'tax_charged' => 0, 'tax_rate' => null,
            'tax_basis' => null, 'tax_added' => false,
        ];

        return [
            /*
             * THE PARTIAL'S OWN SETTINGS, SUPPLIED HERE RATHER THAN INHERITED.
             *
             * store/cart-inner.blade.php opens with `$kbbCartPage->squeezed()`
             * and reads it four more times. It used to arrive only as inherited
             * view data: store/cart.blade.php resolves it in an @php block and
             * @include hands it down. That works for the full page and ONLY for
             * the full page.
             *
             * fragments() renders this partial STANDALONE on every cart write,
             * so `$kbbCartPage` was simply not there, and every one of them
             * answered 500 while rendering its own reply:
             *
             *     Undefined variable $kbbCartPage (View: store/cart-inner.blade.php)
             *
             * Measured across both layouts before the fix: add, update and
             * coupon 500 on classic AND squeeze; remove 500 on squeeze. The
             * drawer path was untouched, because it renders a different view —
             * which is exactly why the mini-cart kept working and hid this.
             *
             * THE SYMPTOM DID NOT LOOK LIKE AN ERROR. The write is committed
             * before fragments() is reached, so the basket really did change;
             * only the HTML describing it never arrived. cart.js catches the
             * failure and the page sits there unchanged — and the shopper sees
             * their new item the moment they reload. Reported as "it only
             * updates on page refresh", which is precisely what a 500 on the
             * render half of a successful write looks like from outside.
             *
             * It belongs in payload() and not at the one call site, because
             * payload() IS the contract for this view. A caller that renders
             * the partial tomorrow gets the variable without having to know it
             * was ever missing.
             */
            'kbbCartPage' => app(\App\Services\CartPage::class),
            /*
             * The sentences SetStockReconciler wrote, if it took anything out
             * of the basket. An empty array on every ordinary request, and the
             * views render nothing at all for an empty array — so the cart page
             * and the drawer are byte-identical to what they were unless a set
             * has actually claimed the last of something. (Lane SEC)
             */
            'setStockNotices' => $this->setStockNotices,
            'cart' => $cart,
            'items' => $cart?->items ?? collect(),
            'totals' => $cart ? $this->carts->totals($cart, $country) : $empty,
            'promo' => $this->settings->moduleEnabled('minicart_promo', true)
                ? (string) $this->settings->get('minicart_promo', '')
                : '',
            /*
             * THE CODE IS CHECKED BEFORE IT IS ADVERTISED.
             *
             * This was `$this->settings->get('cart_coupon_text', 'Use code <b
             * data-code="GLOW30">GLOW30</b> for an extra 30% off.')` — a code
             * and a percentage both written into the default, on a shop that
             * has never had either. The badge is clickable, so a shopper who
             * tapped it was answered "That code is not valid." by the same
             * panel that had just offered it; and this payload feeds the
             * mini-cart drawer, which the layout renders on EVERY page.
             *
             * Support\CheckoutCouponHint holds the one set of conditions —
             * exists, started, not expired, not exhausted — so the cart, the
             * drawer and the checkout cannot advertise different things. It
             * costs no query at all until the owner actually names a code.
             */
            'couponHint' => $this->settings->moduleEnabled('coupon_hint', true)
                ? \App\Support\CheckoutCouponHint::html(
                    \App\Support\CheckoutCouponHint::cartOffer($this->settings)
                )
                : '',
            // Only fetched when the drawer is being rendered for display.
            'browsed' => $browsed,
            'wish' => $wish,
            'wishTotal' => \App\Support\CartPanelLists::wishCount($request),
            // Which browsed products are already in the bag, so the add control
            // can show a tick instead of a plus. Products are not removed from
            // the list any more, so the list itself no longer carries that fact.
            'inCart' => $cart ? $cart->items->pluck('product_id')->unique()->values()->all() : [],
        ];
    }

    /**
     * The drawer's Browsed tab, from the cookie the product page writes, and
     * its heart tab, from the wishlist cookie (Lane HLB) -- ONE query for both,
     * App\Support\CartPanelLists::fetch().
     *
     * Rule 27: no query at all when both cookies are empty, which is every
     * first visit and every crawler.
     *
     * Browsed items stay listed after they are added. Removing them was why
     * the add button appeared to work exactly once: the product left the
     * list the moment it entered the bag, so there was nothing left to press
     * a second time. Adding again increments the line, which is what a
     * shopper reaching for + expects.
     *
     * @return array{0: \Illuminate\Support\Collection, 1: \Illuminate\Support\Collection}
     */
    private function lists(Request $request): array
    {
        $ids = array_slice(array_filter(array_map('intval', explode(',', (string) $request->cookie('kbb_viewed', '')))), 0, 6);

        return \App\Support\CartPanelLists::fetch($ids, \App\Support\CartPanelLists::wishIds($request), self::LINE_COLUMNS);
    }

    private function fragments($cart, Request $request, ?string $toast = null, ?string $error = null, bool $added = false): JsonResponse
    {
        $payload = $this->payload($cart, $request);

        /*
         * ONE JAR, CLAIMED TWICE — said at the moment it happens. (Lane SEC)
         *
         * Adding a product that is already inside a set in the basket, when the
         * shelf cannot cover both, makes SetStockReconciler take the new line
         * straight back out. Without this the shopper presses Add to bag,
         * nothing appears, and the toast says "Added to bag" — which is the
         * shape of a bug even though the basket is right.
         *
         * The sentence replaces the toast rather than joining it, because it
         * IS the answer to what the press did. The cart page and the checkout
         * print the same sentence from the same partial when they are rendered;
         * this is the third surface, and the only one with no room for a band.
         */
        if ($this->setStockNotices !== []) {
            $first = $this->setStockNotices[0];

            $toast = $first['left'] === 0
                ? __('store.cart.set_took_the_last_one', [
                    'product' => $first['product'],
                    'set' => $first['set'],
                ])
                : __('store.cart.set_took_some', [
                    'product' => $first['product'],
                    'left' => $first['left'],
                    'set' => $first['set'],
                ]);
        }

        // The cart-page body is only rendered when the client is actually
        // showing it. Off the cart page that was a full Blade view compiled and
        // thrown away on every add — the single biggest cost of opening the
        // drawer. (Rule 27)
        $wantsPage = $request->boolean('with_page');

        return response()->json([
            'ok' => $error === null,
            'error' => $error,
            'toast' => $toast,
            /*
             * TRUE ONLY FOR THE PLAIN "IT WENT IN" CONFIRMATION. (Lane PI-B)
             * cart.js shows that one the way Appearance → Cart panel →
             * Behaviour → "When something is added" says — a tick, the pill,
             * or nothing. A set notice above REPLACES the toast with a sentence
             * the shopper must read, so it is not `added` and always shows as
             * text, whatever that setting is.
             */
            'added' => $added && $error === null && $this->setStockNotices === [],
            'count' => $payload['totals']['item_count'],
            'drawer' => $this->drawerHtml($payload),
            'page' => $wantsPage ? view('store.cart-inner', $payload)->render() : null,
            'subtotal' => Money::format($payload['totals']['subtotal']),
            'total' => Money::format($payload['totals']['total']),
        ] + (\App\Support\Locale::isDefault() ? [] : [
            // (Lane AR stage 2) The page heading's "(n items)", in the page's own
            // language and plural rules; cart.js used to build it in English.
            // Absent in English, so an English answer is the one it always was.
            'lead' => '(' . trans_choice('store.cart.item_count', $payload['totals']['item_count']) . ')',
        ]));
    }
}
