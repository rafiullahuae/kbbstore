<?php

namespace App\Providers;

use App\Services\CartService;
use App\Models\Redirect;
use App\Models\ShippingMethod;
use App\Models\ShippingZone;
use App\Models\ShippingZoneLocation;
use App\Services\SettingsService;
use App\Services\ShippingService;
use App\Services\Update\BackupService;
use App\Services\Update\UpdateRunner;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        /*
         * The owner app's hooks (new orders, status changes, stock crossing the
         * low line, an admin's password change ending their app sessions).
         * Registered HERE, not in bootstrap/providers.php: UpdateGuard forbids
         * bootstrap/ to a package, so a provider listed there never reaches the
         * live server and the hooks would silently not run. (2.60.400)
         */
        $this->app->register(OwnerAppServiceProvider::class);

        // Marketing Pixels server events (Lane MP): registered here for the same
        // reason -- bootstrap/ never ships in a package.
        $this->app->register(MarketingPixelsServiceProvider::class);

        /*
         * Update services need filesystem paths, and Laravel cannot guess a
         * string constructor argument — asking the container for BackupService
         * without these throws "Unresolvable dependency". That was the 500 on
         * the Updates page.
         */
        $this->app->singleton(BackupService::class, fn () => new BackupService(
            storage_path('app/updates/backups'),
            base_path(),
        ));

        $this->app->singleton(UpdateRunner::class, fn ($app) => new UpdateRunner(
            $app->make(BackupService::class),
            base_path(),
        ));

        /*
         * One CartService per request, shared by everything that needs it.
         *
         * `scoped` rather than `singleton`: a singleton would survive between
         * requests on a queue worker and hand one customer's cart to the next.
         * Scoped is reset at the end of each request, which is exactly right.
         *
         * Without this, the layout's view composer and the cart controller each
         * built their own instance and resolved the cart separately — two
         * lookups per page, and two independent memos. (Rule 27)
         */
        $this->app->scoped(CartService::class);
        $this->app->scoped(SettingsService::class);

        /*
         * The variable-product price range the tiles print, memoised for one
         * request. App\Services\VariantPricing carries the argument in full;
         * the binding matters for two reasons and both are about the memo.
         *
         * `scoped`, like the two above, so a queue worker cannot serve a second
         * job out of the first one's prices. And scoped rather than a plain
         * static inside the class, because StorefrontQueryBudgetTest's
         * budgetReset() clears scoped instances between its measured requests —
         * a static would survive, the class's one query would run in the
         * warm-up pass and never again, and the budget would be measuring a
         * page that does not exist. A cache this test cannot reset is a cache
         * that flatters every number in that file.
         */
        $this->app->scoped(\App\Services\VariantPricing::class);
        // (Lane VPA) The cards' shade dots and size chips: the same one-query,
        // one-request memo, scoped for the same two reasons.
        $this->app->scoped(\App\Services\VariantSwatches::class);
        $this->app->scoped(\App\Support\VariantLabels::class);

        /*
         * Appearance → Product styles, resolved once per request.    (Lane CARD)
         *
         * components/product-card.blade.php reads three of that screen's keys
         * and runs once per tile, and ProductStyles::all() walks its whole
         * schema through SettingsService::get() — which is a
         * `Cache::rememberForever` per key. Measured: 24 × 29 = 696 cache reads
         * on a /shop page, and about 87ms of the ~120ms it takes.
         *
         * `scoped` and not `singleton`, like the three above: a singleton would
         * survive between requests on a queue worker and serve one shop's card
         * settings to the next. Scoped also means
         * `forgetScopedInstances()` clears it, which is how
         * StorefrontQueryBudgetTest and every test that moves a setting and
         * re-renders get a clean read — a static inside the class would not.
         */
        $this->app->scoped(\App\Services\ProductStyles::class);

        /*
         * Bilingual foundation (Lane EP). Two bindings and nothing else.
         *
         * 1. __() READS THE DATABASE. Laravel's own translator is kept; only
         *    its loader is decorated, so validation messages and pagination
         *    wording still come from the framework's files and every Blade
         *    conversion the later lanes do is ordinary __() that any Laravel
         *    developer already knows.
         *
         *    This has to be an override rather than a new helper because the
         *    owner has no shell and lang/ is not on UpdateGuard's allowed
         *    prefixes — a translation the owner types can only live in the
         *    database, and the framework has to be told to look there. See
         *    App\Services\Translation\DatabaseTranslationLoader.
         *
         *    extend(), not a fresh singleton: the FileLoader underneath is
         *    whatever the framework configured, including any path a package
         *    has added, and rebuilding it here would silently drop those.
         *
         * 2. THE MACHINE-TRANSLATION PROVIDER, which is NullProvider unless the
         *    owner has saved his own API key. That default is what makes the
         *    manual path — the one that must be free to operate — work with
         *    nothing configured, and what keeps the test suite off the network.
         *
         *    `scoped` rather than `singleton`, so a queue worker that runs one
         *    job before the key is saved and another after does not keep
         *    answering "no provider" for the life of the process. Same trap as
         *    Setting::map(), one layer up.
         */
        $this->app->extend('translation.loader', static fn ($loader) => new \App\Services\Translation\DatabaseTranslationLoader($loader));

        $this->app->scoped(\App\Services\Translation\TranslationProvider::class, static function () {
            $key = \App\Services\Translation\TranslationCredentials::apiKey();

            return $key === null
                ? new \App\Services\Translation\NullProvider
                : new \App\Services\Translation\GoogleProvider($key);
        });
    }

    public function boot(): void
    {
        // Lane SP: a settings map written or forgotten mid-request -- by
        // SettingsService itself or by a service that writes the table and
        // forgets the key on its own -- is read fresh by the rest of that
        // request. See SettingsService::REQUEST_MEMO_KEYS.
        \Illuminate\Support\Facades\Event::listen(
            [\Illuminate\Cache\Events\ForgettingKey::class, \Illuminate\Cache\Events\WritingKey::class],
            static function ($event): void {
                if (SettingsService::requestMemoActive()) {
                    SettingsService::forgetRequestMemo((string) $event->key);
                }
            }
        );

        /*
         * ── THE LINE THAT MAKES /ar EXIST, FROM A FILE A PACKAGE CAN SHIP ───
         *
         * SetLocaleFromPath has to run BEFORE the router, because it strips the
         * /ar segment so every existing route, RESERVED_SLUGS, the redirect map
         * and the sitemap can stay exactly as they are. Only the global
         * pipeline runs that early, which is why bootstrap/app.php prepends it.
         *
         * AND bootstrap/ IS ON BuildPackage::NEVER_SHIP. So that line has never
         * reached the server, and could not: it was documented as the one change
         * in this feature to be applied by hand. It was not applied, which is
         * why the owner reported "/ar gives 404 everywhere" after switching
         * Arabic on — the switch was on and the middleware that acts on it was
         * not there.
         *
         * A hand-edit to bootstrap/app.php is the worst thing to ask of an owner
         * with no shell: a mistake in that file stops the application booting at
         * all, which also stops the updater that would roll it back.
         *
         * PROVIDERS BOOT BEFORE THE PIPELINE IS BUILT, which is what makes this
         * work. Kernel::handle() calls bootstrap() — including BootProviders —
         * and only then reads $this->middleware to build the Pipeline. So a
         * prepend from here lands in the global stack in time, and this file
         * ships in a package like any other.
         *
         * BOTH REGISTRATIONS ARE SAFE TOGETHER. prependMiddleware() does an
         * array_search before it unshifts, so a server whose bootstrap/app.php
         * DOES carry the hand-applied line gets one registration, not two. The
         * bootstrap line is deliberately left in place rather than removed: a
         * shop that already applied it must not be broken by this, and losing
         * the global-pipeline registration on a future Laravel upgrade would
         * silently turn Arabic off again.
         *
         * STILL INERT UNTIL SWITCHED ON. The middleware reads Locale::enabled(),
         * false until Arabic is turned on in Translation → Settings, so this
         * changes nothing a shopper of an English-only shop can see.
         */
        $kernel = $this->app->make(\Illuminate\Contracts\Http\Kernel::class);

        if (method_exists($kernel, 'prependMiddleware')) {
            /*
             * ── THE REDIRECT TABLE, FINALLY WIRED TO SOMETHING ──────────────
             *
             * CheckRedirects has been written as middleware since the day it
             * was created and was registered as middleware nowhere. The only
             * live reader of the `redirects` table was the
             * NotFoundHttpException closure further down this method, and that
             * has one absolute consequence, measured rather than assumed:
             * AN ADDRESS THAT DOES NOT 404 COULD NEVER BE REDIRECTED BY A ROW.
             * Rows written for `/shop/`, a category archive and a product
             * address, all enabled and all matching byte for byte, changed
             * nothing at all. The old shop has five years of URLs and every one
             * of them that collides with a slug this app serves kept serving
             * the wrong page. See the class's own comment and
             * docs/GP-ADDRESSES-LAND.md.
             *
             * PREPENDED FIRST, WHICH MAKES IT RUN LAST OF THE THREE.
             * prependMiddleware() puts each new entry at the front, so the
             * order of these three calls is the reverse of their execution
             * order, and both ends of that matter:
             *
             *   CanonicalHost runs before it — no sense redirecting a path on
             *   a host the request is about to be forwarded off. It folds the
             *   path correction into its own hop through
             *   CheckRedirects::lookup(), so the visitor still makes one.
             *
             *   SetLocaleFromPath runs before it — /ar is stripped before the
             *   router sees the request and `redirects.source` carries no
             *   locale segment, so an Arabic visitor following an old link
             *   matches the same row an English one does. Url::redirect() puts
             *   the segment back on the way out.
             *
             * HERE AND NOT ONLY IN bootstrap/app.php, for the reason the block
             * above gives: bootstrap/ is on BuildPackage::NEVER_SHIP and
             * UpdateGuard's forbidden list, so a registration written only
             * there can never reach the live server. The bootstrap line exists
             * too and the two are safe together — prependMiddleware()
             * array_searches before it unshifts.
             *
             * INERT ON A SHOP WITH NO ROWS, which is what makes applying this
             * safe: it reads a cached set of `redirects.source` values and
             * steps aside when the incoming path is not one of them, at a cost
             * of zero queries. Nothing a shopper can see moves until a row
             * exists for an address the shop serves — which is the whole point.
             */
            $kernel->prependMiddleware(\App\Http\Middleware\CheckRedirects::class);

            $kernel->prependMiddleware(\App\Http\Middleware\SetLocaleFromPath::class);

            /*
             * ── THE ARABIC ADDRESS, TURNED INTO THE ONE THE ROUTER SERVES ────
             *
             * Lane S5. With the Arabic-slug policy on, a reader may arrive at an
             * address no route matches; this rewrites it to the English slug
             * before the router looks, so no route, controller or query knows a
             * second address exists. The same trick SetLocaleFromPath plays with
             * the /ar segment.
             *
             * pushMiddleware AND NOT prepend, and the order is the whole point:
             * prependMiddleware() puts a class FIRST, so a prepended
             * ResolveLocaleSlugs would run BEFORE CheckRedirects. The retrofit
             * writes a redirect from the English address to the Arabic one; if
             * the rewrite ran first it would turn the Arabic address back into
             * the English one, CheckRedirects would forward that to the Arabic
             * one, and a visitor would bounce between the two for ever.
             * ArabicTranslatedSlugsTest asserts this order.
             *
             * Inert today: the class returns immediately while the policy is
             * `shared`, which is what no seeded row means, at a cost of one
             * cached settings read.
             */
            $kernel->pushMiddleware(\App\Http\Middleware\ResolveLocaleSlugs::class);

            /*
             * CanonicalHost — forwards a listed alias to the real address and
             * marks anything private noindex. Registered HERE, and not in
             * bootstrap/app.php, for the reason the block above exists:
             * bootstrap/ is on BuildPackage::NEVER_SHIP and UpdateGuard's
             * forbidden list, so a registration there can never reach the
             * server in a package. This one can.
             *
             * BEFORE SetLocaleFromPath in execution order -- prependMiddleware
             * puts each new entry at the front, so the last one prepended runs
             * first -- which is what we want: there is no sense translating a
             * request that is about to be sent to another host.
             *
             * INERT UNTIL CONFIGURED. SiteHost::classify() answers CANONICAL
             * for every host while `canonical_host` is empty, which is how it
             * ships. Applying this package changes nothing until somebody fills
             * the field in on Settings -> Site address.
             */
            $kernel->prependMiddleware(\App\Http\Middleware\CanonicalHost::class);

            /*
             * Appearance -> Coming Soon page (Lane CS). Prepended AFTER
             * CanonicalHost, so it runs BEFORE it: a hidden address that is
             * also a forwarded old address shows the page rather than a 301,
             * and the gate itself never redirects off the host, so the two
             * cannot loop. Still inside SettingsRequestMemo (prepended below).
             * OFF, as it ships: one array lookup in the Setting::map() that
             * CanonicalHost reads anyway. See App\Support\ComingSoon.
             */
            $kernel->prependMiddleware(\App\Http\Middleware\ComingSoonGate::class);

            /*
             * Lane SP. HERE AND NOT IN bootstrap/app.php, which UpdateGuard
             * refuses to ship (BuildPackage::NEVER_SHIP's note): a line there
             * would pass every test in the repo and never reach the shop.
             *
             * SettingsRequestMemo is prepended LAST -- after CanonicalHost --
             * so it is the outermost of all: the settings maps are read from the cache once per request
             * for everything after it (App\Services\SettingsService).
             * ClearPrefetchOnWrite is pushed: it only adds a header to the
             * response of a write (App\Support\InstantNav).
             */
            $kernel->prependMiddleware(\App\Http\Middleware\SettingsRequestMemo::class);
            $kernel->pushMiddleware(\App\Http\Middleware\ClearPrefetchOnWrite::class);
        }

        /*
         * ── THE GUEST REDIRECT, DECIDED BY AUDIENCE (Lane SEC) ──────────────
         *
         * bootstrap/app.php carried one line whose comment named a scope the
         * call does not have:
         *
         *     // Unauthenticated back-office requests go to the admin login, not /login.
         *     $middleware->redirectGuestsTo(fn () => route('admin.login'));
         *
         * redirectGuestsTo() sets three APPLICATION-WIDE statics, so every
         * unauthenticated request to anything behind any guard answered with
         * the admin login. /my-account/orders, the address book, the order
         * detail page and the verification notice are all behind
         * `auth:customer`, so a logged-out shopper who clicked "Your orders"
         * from the order-tracking page was handed the owner's SECRET ADMIN
         * ADDRESS -- in their address bar, their browser history and the
         * Referer of whatever they clicked next. The owner reported it from his
         * own shop. `admin_path` is a secret everywhere else in this codebase:
         * CLAUDE.md names it among the columns that must never leave `settings`
         * through /api/*, Api\SettingController::PUBLIC_KEYS holds it in, and
         * Mail\NewOrderAlert refuses to print it into an email. This redirect
         * was the one door it walked out of.
         *
         * App\Support\GuestRedirect answers from the matched route's GUARD --
         * `auth:admin` is the back office and everything else is a shopper --
         * and never from a string match on the path, because `admin_path` is
         * configurable (KBB_ADMIN_PATH, or the settings row) and a shop that
         * changed it would fall through to the wrong branch. It fails towards
         * the storefront: no matched route, or a guard it has never heard of,
         * answers with the customer login, which is the direction that cannot
         * leak.
         *
         * HERE AND NOT ONLY IN bootstrap/app.php, for the reason the three
         * registrations above exist: bootstrap/ is on BuildPackage::NEVER_SHIP
         * and UpdateGuard's forbidden list, so a fix written only there can
         * never reach the live shop -- and this one is a security fix on a shop
         * that is taking orders today.
         *
         * THIS CALL IS THE ONE THAT WINS, AND THE TWO ARE SAFE TOGETHER.
         * withMiddleware()'s callback runs when the HTTP kernel is resolved,
         * which is before BootProviders, so bootstrap/app.php sets these
         * statics first and this line sets them again to the same closure.
         * They are plain statics, so last write wins and both writes are
         * identical.
         *
         * THE THREE, because Middleware::redirectTo() sets all three and
         * missing one leaves a path that still answers with the admin login:
         * Authenticate is the `auth` middleware, AuthenticateSession is the
         * one that logs a session out when the password changes elsewhere, and
         * AuthenticationException is the fallback the exception itself reads
         * when it was constructed without a destination.
         *
         * IT MOVES NOTHING FOR THE BACK OFFICE. Every route inside
         * `auth:admin` answers route('admin.login') exactly as before, byte for
         * byte. tests/Feature/AdminPathNeverLeaksTest.php pins both sides.
         */
        $guests = static fn (\Illuminate\Http\Request $request): string
            => \App\Support\GuestRedirect::for($request);

        \Illuminate\Auth\Middleware\Authenticate::redirectUsing($guests);
        \Illuminate\Session\Middleware\AuthenticateSession::redirectUsing($guests);
        \Illuminate\Auth\AuthenticationException::redirectUsing($guests);

        /*
         * ── AND THE SECOND DOOR: HIDE, RATHER THAN POINT AT A LOGIN ─────────
         *
         * 398 admin-guarded endpoints do not live under the secret admin path —
         * 397 `admin-api/...`, which is a FIXED prefix anybody can guess, and
         * `api/cart/debug`. Logged out, each of them answered
         * `302 Location: .../<admin_path>/login`, so the secret was readable by
         * anyone who could type `admin-api`.
         *
         * WHAT CHANGES IS ONLY THE BRANCH THAT PRINTED IT. Handler::
         * unauthenticated() already answers a request that expects JSON with a
         * bare 401 and no Location, and every one of the console's 43 fetch()
         * calls to admin-api sets Accept: application/json — so the console has
         * never seen the redirect and does not see this. Leaving the 401 alone
         * is deliberate and is argued at length on
         * GuestRedirect::hidesTheAddressInstead(): 33 console screens read a
         * 404 from their own endpoints as "clear the route cache", and 3
         * already read 401 as "your session expired".
         *
         * A RENDER CALLBACK, WHICH IS THE ONLY SHIPPABLE HOOK. The obvious home
         * for this is `->withExceptions()` in bootstrap/app.php, and
         * bootstrap/ is on BuildPackage::NEVER_SHIP — the same reason
         * everything else in this method is here. Handler::render() runs its
         * render callbacks BEFORE the AuthenticationException branch, so this
         * intercepts cleanly, and returning null falls straight through to the
         * behaviour above for every request it does not claim.
         *
         * IT RE-RENDERS A REAL NotFoundHttpException rather than composing a
         * 404 of its own, so the answer is byte-identical to the one the router
         * gives for a path that was never registered — in every environment,
         * debug or not. A refusal that looked slightly different from a genuine
         * 404 would tell a stranger the address exists, which is the one thing
         * this is for.
         */
        $handler = $this->app->make(\Illuminate\Contracts\Debug\ExceptionHandler::class);

        if (method_exists($handler, 'renderable')) {
            $handler->renderable(static function (
                \Illuminate\Auth\AuthenticationException $e,
                \Illuminate\Http\Request $request
            ) use ($handler) {
                if (! \App\Support\GuestRedirect::hidesTheAddressInstead($request)) {
                    return null;
                }

                return $handler->render(
                    $request,
                    new \Symfony\Component\HttpKernel\Exception\NotFoundHttpException
                );
            });
        }

        /*
         * CacheHeaders -- APPENDED TO THE `web` GROUP, not prepended globally,
         * and for the opposite reason to the two above. Those two have to run
         * BEFORE the router: one rewrites the path so /ar matches an existing
         * route, the other may send the request to another host entirely. This
         * one sets a header on a finished response, so it wants to run LAST,
         * after every other middleware has stopped touching it.
         *
         * ▲ AND IT IS THE THIRD REGISTRATION IN THIS METHOD THAT EXISTS
         * BECAUSE bootstrap/app.php CANNOT SHIP. docs/FQ-CACHE-HEADERS.md
         * wrote out the one line to add to $middleware->web(append: [...]) by
         * hand; it was never applied, so App\Http\Middleware\CacheHeaders has
         * been complete, tested and called by nothing since Lane FQ. That is
         * the same story as the /ar block above, one file over.
         *
         * SAFE ALONGSIDE THE HAND-APPLIED LINE. appendMiddlewareToGroup() does
         * an array_search before it appends, so a server whose bootstrap/app.php
         * does carry it gets one registration and not two -- and a doubled
         * Cache-Control middleware is exactly the "two middlewares setting the
         * same header" the class's own docblock warns about.
         *
         * INERT UNTIL SWITCHED ON, which is the part that matters on a shop
         * that is already taking orders. CacheSettings::ENABLED ships false and
         * the middleware returns the response untouched until the owner turns
         * it on from Platform -> Cache. Applying this package changes no
         * response header anywhere.
         *
         * The isset() guard is not defensive padding: appendMiddlewareToGroup()
         * THROWS InvalidArgumentException for a group it does not know, and a
         * provider that throws is a shop that does not boot.
         */
        if (method_exists($kernel, 'appendMiddlewareToGroup')
            && method_exists($kernel, 'getMiddlewareGroups')
            && isset($kernel->getMiddlewareGroups()['web'])) {
            $kernel->appendMiddlewareToGroup('web', \App\Http\Middleware\CacheHeaders::class);

            /*
             * THE REPORT-ONLY CONTENT-SECURITY POLICY (Lane C, Phase 18 item 5).
             *
             * Beside CacheHeaders, appended to the `web` group, and for the
             * same two reasons that one is here rather than in bootstrap/
             * app.php: that file cannot ship in a package, and this sets a
             * header on a finished response so it wants to run last. The `web`
             * group is also what keeps it off /api/* entirely.
             *
             * IT IS A MIDDLEWARE, WHICH NOTHING ELSE IN THIS MODULE IS. The
             * rest of the security module is model events, auth events and one
             * listener on RequestHandled, because a listener holds a finished
             * response and has nothing to return; a header has to be SET on the
             * response, so this one piece cannot be a listener. It still cannot
             * refuse anything: handle() has one return and it returns
             * $next($request)'s own response, the header it adds is the
             * REPORT-ONLY one by construction — the enforcing header's name is
             * not in this application's source at all — and
             * tests/Feature/SecurityCspTest.php walks the storefront with the
             * switch on and with it off against named absolute status codes.
             *
             * INERT UNTIL SWITCHED ON. `sec_csp_on` ships OFF, because this
             * shop sends no policy header today and a new setting ships at the
             * value the page already has. Applying the package changes no
             * response header anywhere until somebody moves the switch on
             * Store -> Security -> Content security policy.
             *
             * ITS OWN CLASS AND NOT app/Http/Middleware/, which is another
             * lane's directory this round. That is why the class sits under
             * app/Services/Security/ beside the policy it serves; a middleware
             * is a class with a handle() method and the group does not care
             * where it lives.
             */
            $kernel->appendMiddlewareToGroup('web', \App\Services\Security\CspHeaders::class);

            /*
             * Appearance -> Coming Soon page (Lane CS): the half that needs
             * the session -- after StartSession, before any controller. One
             * attribute read for every request the gate did not mark.
             */
            $kernel->appendMiddlewareToGroup('web', \App\Http\Middleware\ComingSoonAdminPass::class);
        }

        /*
         * Growth & Marketing → Cart Tracking (Lane CT): the block-list gate at
         * the front of `web` and `api`, the retention heartbeat, and the hook
         * that recompiles the gate's file when its settings change. One call;
         * see App\Services\CartTracking\CartTrackingHooks for each.
         */
        \App\Services\CartTracking\CartTrackingHooks::register($kernel);

        /*
         * `media_usages` — which image belongs to which product, brand or
         * category. One call, because the hooks themselves live with the
         * writer rather than being spelled out here: this file is shared by
         * every lane and four more closures in it is how it becomes
         * unreadable. See App\Support\MediaUsageWriter for what is
         * registered and, more importantly, for the two places the table can
         * still fall behind.
         */
        \App\Support\MediaUsageWriter::listen();

        // Catalog -> Image SEO (Lane IR): a product whose pictures, alt text or
        // name change elsewhere has its Media Library score re-stored. Admin
        // and importer writes only; the shop never saves a product.
        \App\Services\ImageSeo\ImageSeo::listen();

        /*
         * `orders.locale` — the language the customer was shopping in.
         *
         * One call, registering an Order::creating hook, for the same reason
         * MediaUsageWriter is one call: this file is shared by every lane and
         * another closure in it is how it stops being readable.
         *
         * A model hook rather than a line in CheckoutController, and that is
         * deliberate rather than convenient. Orders are created in FIVE places
         * — Store\CheckoutController, Api\CheckoutController,
         * ManualOrderBuilder, DemoContentController and GatewayPreflight — and
         * a rule written at four of them is a rule. See
         * App\Support\OrderLocale for what it does when there is no request.
         */
        \App\Support\OrderLocale::listen();

        /*
         * `audit_events` — who changed which setting, who installed which
         * package, who signed in from where (Lane C, Phase 18 items 6 and 7).
         *
         * One call, for the same reason as the two above: this file is shared
         * by every lane, and the hooks live with the writer.
         *
         * HERE AND NOT IN bootstrap/app.php, AND NOT AS MIDDLEWARE. Not in
         * bootstrap because that directory is on BuildPackage::NEVER_SHIP and
         * UpdateGuard's forbidden list, so a registration there can never reach
         * the live server in a package — the /ar block at the top of this
         * method is the same story and it cost a release. Not as middleware
         * because Phase 18's sequencing is REPORT BEFORE ENFORCE: what
         * SecurityModule registers is model events, auth events and one
         * listener on RequestHandled, which fires after the response exists
         * and has nothing to return. Nothing it registers can refuse, delay or
         * alter a single request.
         *
         * It records only while an admin is signed in, so the storefront and
         * `php artisan migrate` write nothing at all.
         */
        \App\Services\SecurityModule::listen();

        /*
         * Shipping zones, their locations and their methods are read on EVERY
         * storefront page — the header's free-delivery bar asks for the store
         * country's threshold — and used to cost two queries every time they
         * were asked. ShippingService now reads the whole set once and caches
         * it (a dozen rows; it is configuration, not data).
         *
         * These hooks are what make that cache safe to keep forever rather than
         * on a TTL: every write to any of the three tables drops it, so an edit
         * on Store → Shipping is live on the next request exactly as it was
         * before the cache existed. Same shape, and the same reason, as the
         * catalogue hooks further down that evict the homepage fragments.
         *
         * `saved` AND `deleted`: switching a method off is a save, removing a
         * zone's last country is a delete, and both change what a shopper is
         * quoted.
         */
        foreach ([ShippingZone::class, ShippingZoneLocation::class, ShippingMethod::class] as $shippingModel) {
            $shippingModel::saved(fn () => ShippingService::flushZones());
            $shippingModel::deleted(fn () => ShippingService::flushZones());
        }

        /*
         * Redirects — the same shape, one line down, and for the same reason.
         *
         * CheckRedirects runs on every storefront request now, and answers "no
         * redirect for this path" out of a cached set of `redirects.source`
         * values rather than a query. That is what keeps a page that redirects
         * nothing at zero queries against the table; these two hooks are what
         * make the cache safe to keep forever rather than on a TTL. A row
         * added, switched off or deleted on Store → Redirects is live on the
         * next request, exactly as it was before the index existed.
         *
         * HERE AND NOT IN Redirect::booted(), which was tried first and does
         * not hold. Eloquent runs booted() ONCE PER PROCESS — Model::$booted is
         * static and keyed by class — while the event dispatcher is replaced
         * with every application instance. `Redirect` is first booted by the
         * Phase 9 seed migration, so in any process that outlives one
         * application (the suite, a queue worker, `artisan migrate`) the
         * listener booted() registered is attached to a dispatcher nothing
         * dispatches to, and the index silently stops being evicted. Measured
         * rather than reasoned about: a row created after a page had been
         * rendered was absent from the index, and the address it named went on
         * serving its own page. This method runs per application instance.
         *
         * `saved` AND `deleted`: switching a redirect off is a save, and a row
         * that no longer exists has to stop claiming its address.
         */
        Redirect::saved(fn () => \App\Http\Middleware\CheckRedirects::flushIndex());
        Redirect::deleted(fn () => \App\Http\Middleware\CheckRedirects::flushIndex());

        /*
         * Redirects & 404 manager.
         *
         * ▲ THIS IS NO LONGER THE ONLY READER OF THE TABLE, and the comment
         * that used to stand here said it was. CheckRedirects is registered as
         * global middleware at the top of this method, so it answers first for
         * every path a row claims — including the ones this closure could never
         * see, which was the defect: a redirect for an address the shop already
         * served could not fire at all.
         *
         * THE CHECK STAYS HERE ANYWAY, and it is belt and braces rather than
         * duplication. A host whose provider registration somehow did not land
         * keeps redirecting 404s exactly as it did before, which is the failure
         * mode that has to stay boring. It calls the same static findMatch(),
         * so the two cannot answer differently.
         *
         * The exception handler reliably catches every 404 regardless of source
         * (an unmatched path via the fallback route, or a controller's own 404
         * for a renamed slug), so the redirect check happens first here; only
         * when nothing matches does this fall through to logging it.
         */
        $this->app->make(\Illuminate\Contracts\Debug\ExceptionHandler::class)->renderable(
            function (\Symfony\Component\HttpKernel\Exception\NotFoundHttpException $e, \Illuminate\Http\Request $request) {
                $redirect = \App\Http\Middleware\CheckRedirects::findMatch($request);

                if ($redirect !== null) {
                    \App\Http\Middleware\CheckRedirects::recordHit($redirect);

                    /*
                     * Url::redirect(), not the bare target. See
                     * CheckRedirects::handle() for the whole argument; the
                     * short version is that redirect() hands a relative target
                     * to Laravel's UrlGenerator, which strips the trailing
                     * slash and knows nothing about the reader's language.
                     * Measured both ways on a running server: 15 of 15 rows
                     * landed on a non-canonical address, and an Arabic reader
                     * following one was dropped onto the English page. The
                     * BASE PATH was already right — UrlGenerator takes it from
                     * the request root — which is a correction to
                     * docs/GB-MEDIA-AND-REDIRECTS.md §6.4; the other two were
                     * not. This is the copy that actually runs.
                     */
                    // IN-BAND, and $request is handed over: the reader of this
                    // Location is the visitor who just hit a 404 on this host,
                    // so their own host is the right one to send them back to.
                    // The argument is what makes that testable — see
                    // Url::redirect()'s note on runningInConsole().
                    return redirect(\App\Support\Url::redirect($redirect->target, $request), $redirect->code);
                }

                // An old picture address (Google Images' /wp-content/uploads/…
                // index, a WordPress sized copy, a JPEG since turned into WebP)
                // sent to the file that shows that picture now. Only 404s reach
                // this line, and the class leaves at once for anything not under
                // an upload root or img-cache -- see App\Support\LegacyImageRedirect
                // (Lane SEO). A picture Catalog -> Image SEO renamed (Lane IR)
                // is answered by the same class, from its ledger, in one hop.
                if (($legacyImage = \App\Support\LegacyImageRedirect::respond($request)) !== null) {
                    return $legacyImage;
                }

                // A product picture the owner removed with nothing in its slot
                // (Lane RPL): 410 Gone once its 30 days in the trash are up --
                // not a soft 404 -- and an old email's copy of it goes to the
                // product's current picture. Null for everything else.
                if (($gonePicture = \App\Services\Media\PictureTrash::respond($request)) !== null) {
                    return $gonePicture;
                }

                if ($request->isMethod('GET') && !$request->is('admin*', 'admin-api*', 'api*')) {
                    \App\Support\NotFoundLogger::record($request->path(), $request->header('referer'));
                }

                // The shop's own 404 page for a shopper's page request (Lane
                // NF), still a 404; null for everything else — the admin, the
                // APIs, the owner app, JSON — which keeps Laravel's default.
                return \App\Support\NotFoundPage::respond($request);
            }
        );

        // In production, generate https URLs and set secure cookies behind the host's TLS proxy.
        if ($this->app->environment('production')) {
            URL::forceScheme('https');
        }

        /*
         * ── THE SHOP'S OWN FILES ARE ADDRESSED FROM THE ROOT, WITH NO SCHEME.
         *
         * THE DEFECT, reported by the owner and reproduced in a real browser:
         * the mobile menu worked in Chrome and did nothing in Safari or Opera,
         * and Opera labelled the page "Connection is not secure".
         *
         * Opera and Safari had loaded the shop over plain http://. Chrome
         * upgrades to https:// by itself; they do not. forceScheme() above
         * then wrote every asset address as https:// -- and a page and a file
         * that differ only in scheme are DIFFERENT ORIGINS to a browser.
         * Stylesheets do not care, so the page looked right. But
         * <script type="module"> is always fetched under cross-origin rules,
         * and so is every web font, and the host sends no
         * Access-Control-Allow-Origin header for static files. Measured with
         * two real servers and no interception, the browser's own words:
         *
         *   "Access to script at '.../build/assets/app-BLfAa6WG.js' from origin
         *    '...' has been blocked by CORS policy: No
         *    'Access-Control-Allow-Origin' header is present"
         *
         * -- and the same sentence for the Outfit font. No script means no
         * menu; no font file means a fallback typeface. Same page, same files,
         * same origin: the menu opens.
         *
         * A root-relative address has no scheme and no host, so it is ALWAYS
         * the page's own origin, on http:// and on https:// alike. The path is
         * taken from asset() so a base path (KBB_BASE_PATH on the staging box)
         * is kept exactly as before.
         *
         * ▲ NOT AN http -> https REDIRECT IN HERE, deliberately. This app does
         *   not trust the proxy's X-Forwarded-Proto, so it cannot tell an https
         *   visit from an http one on the live host -- which is the very reason
         *   forceScheme() exists. A redirect written here would see EVERY
         *   request as http and redirect for ever, taking the whole shop down.
         *   That redirect belongs where TLS terminates, on the host.
         *
         * An ASSET_URL (a CDN on another host) is left alone: there, absolute
         * is the point, and the CDN is the one that must send the header.
         */
        \Illuminate\Support\Facades\Vite::createAssetPathsUsing(
            static function (string $path, ?bool $secure = null): string {
                $absolute = asset($path, $secure);

                if (config('app.asset_url')) {
                    return $absolute;
                }

                $rootRelative = parse_url($absolute, PHP_URL_PATH);

                return is_string($rootRelative) && $rootRelative !== '' ? $rootRelative : $absolute;
            }
        );

        // The mini-cart drawer renders with every page, so it is correct on a
        // hard refresh rather than only after an add. Previously the header
        // badge came from the server while the drawer waited for JavaScript.
        \Illuminate\Support\Facades\View::composer(
            'partials.cart-drawer',
            \App\View\Composers\CartDrawerComposer::class
        );

        // @shortcodes($page->content) — renders [kbb_products ...] anywhere:
        // pages, posts, HTML blocks.
        \Illuminate\Support\Facades\Blade::directive(
            'shortcodes',
            fn ($expr) => "<?php echo \\App\\Support\\Shortcodes::render({$expr}); ?>"
        );

        // IndexNow: ping on publish, not on every save — a draft being
        // autosaved every few seconds would otherwise spam the endpoint
        // with URLs nobody can even reach yet. Fire-and-forget; IndexNow
        // itself never throws (see the service), so this can't turn a
        // product/post save into a failure over a search-engine ping.
        //
        // Deliberately NOT using Product::url() here — that goes through
        // Url::to(), which adds its own base-path prefix (e.g.
        // /kbb-upgrade), and site_url below already includes that same
        // prefix as part of the configured canonical base. Combining both
        // double-counts it (…/kbb-upgrade/kbb-upgrade/product/…, a URL
        // that 404s) — the path is built by hand instead, same as the
        // Post hook just below, which never had this problem because it
        // never went through Url::to() in the first place.
        \App\Models\Product::saved(function (\App\Models\Product $product) {
            /*
             * ProductVisibility::isLive(), not a hand-written status check.
             *
             * A product scheduled for next Tuesday is `publish` and visible and
             * satisfies the old two-part test the moment it is saved — so this
             * hook told Google to come and crawl a URL that will 404 until
             * Tuesday. Submitting a soft-404 to IndexNow is worse than
             * submitting nothing: it spends crawl budget and teaches the index
             * that the URL is missing, on exactly the page a launch date exists
             * to make a good first impression on.
             *
             * Nothing re-submits when the date passes, and that is deliberate
             * rather than a gap: the product is in the sitemap from that moment
             * on, and a real edit after launch saves the row again and pings
             * then. Manufacturing a ping with no scheduler to run it is the
             * problem this whole package avoids.
             */
            if (\App\Support\ProductVisibility::isLive($product)) {
                $base = rtrim((string) (\App\Models\Setting::map()['site_url'] ?? ''), '/');
                if ($base !== '') {
                    \App\Services\Seo\IndexNow::submitOne($base . \App\Support\UrlScheme::product($product->slug));
                }
            }
        });

        \App\Models\Post::saved(function (\App\Models\Post $post) {
            if (($post->status ?? null) === 'published' && $post->slug) {
                $base = rtrim((string) (\App\Models\Setting::map()['site_url'] ?? ''), '/');
                if ($base !== '') {
                    /*
                     * /blog/{slug}/, which is where the address scheme serves
                     * an article. Submitting the site-root form would ping a
                     * URL that 301s -- a wasted crawl and, worse, a hint to the
                     * index that the address it just fetched is not the one.
                     */
                    \App\Services\Seo\IndexNow::submitOne($base . \App\Support\UrlScheme::article($post->slug));
                }
            }
        });

        /*
         * Homepage fragment eviction.
         *
         * Store\HomeController serves the most-hit URL on the site out of eight
         * Cache::remember() keys — the product rails at 600s, the brand strip,
         * category tiles, journal row, routine, catalogue count and brand total
         * at 900s. All eight are built from products, brands, categories and
         * posts, and until this hook NOTHING ON ANY WRITE PATH EVICTED THEM:
         * HomeController::flushCache() existed with no callers at all. A price
         * edit, a sale, a `featured` toggle or an out-of-stock left the homepage
         * advertising the old answer for up to fifteen minutes, so a shopper
         * could click a tile at one price and land on a page at another.
         *
         * Bound to the MODEL rather than to each admin controller, for the same
         * reason the IndexNow ping above is: it is the one place every write has
         * to pass through. The review wall was evicted the other way, with a
         * literal key copied into each controller that writes reviews, and it
         * went stale twice because a new write path did not know to copy it.
         * Products are written from at least six places — the editor, the
         * catalogue grid and its three bulk actions, the reorder screen, the
         * importer and the seeders.
         *
         * Guarded on wasChanged() so the editor's open-and-close, which saves
         * without altering anything, does not throw away eight valid entries and
         * send the next visitor through a full rebuild.
         */
        $homeProductColumns = [
            'slug', 'name', 'brand_id', 'category_id', 'price', 'sale_price',
            'sale_starts_at', 'sale_ends_at', 'stock_status', 'image', 'rating',
            'review_count', 'featured', 'type', 'total_sales', 'status', 'is_visible',
            'deleted_at',
            /*
             * ▲ AND THE THREE COLUMNS A SET'S PRICE IS DERIVED FROM.
             *
             * A rule-priced set does not carry its price in `price` in any
             * meaningful sense — SetPricing recomputes it at render off
             * `set_price_mode`, `set_discount` and `set_price_basis`. The
             * homepage rails cache SERIALISED products for ten to fifteen
             * minutes, so a set whose rule changed but whose watched columns did
             * not would keep advertising the old figure until the TTL, and a
             * shopper would click a tile at one price and land on a page at
             * another. That is the exact defect this hook was written for.
             *
             * It is UNREACHABLE TODAY, and the previous lane said so and left
             * them out on that basis: ProductEditorApiController is the only
             * writer of a set's rule and it writes `price` in the same save,
             * from SetPricing::derived(). The reasoning is sound and it is also
             * the whole problem — it is a fact about ONE call site, holding a
             * model-level hook closed. This hook is bound to the MODEL rather
             * than to each controller precisely because the review wall was done
             * the other way and went stale twice when a new write path did not
             * know to copy the key. A second writer is being built this round.
             *
             * Costs nothing to be right: these columns only move when somebody
             * changes a set's pricing rule, which is rare and which should evict
             * the homepage anyway. The failure it prevents is silent and
             * commercial.
             */
            ...\App\Support\SetPricing::COLUMNS,
        ];

        /*
         * The /shop sidebar has the same hole under a different key.
         *
         * ShopController::flushSidebarCache() clears kbb.shop.cats and
         * kbb.shop.brands, both withCount(visible) tallies, and its own doc
         * comment says "call after any catalogue write". Five admin controllers
         * do call it — for category, brand and layout writes. NOT ONE PRODUCT
         * WRITE PATH DOES, and a product being hidden, published, deleted or
         * moved to another brand is exactly what those counts count. The
         * sidebar read "Cleansers (24)" next to a grid showing 23.
         *
         * Narrower column list than the homepage's: these are counts, so only
         * visibility and the brand/category a product is counted under move
         * them. A price edit does not.
         */
        $visibilityColumns = ['status', 'is_visible', 'published_at', 'brand_id', 'category_id', 'deleted_at'];

        \App\Models\Product::saved(function (\App\Models\Product $product) use ($homeProductColumns, $visibilityColumns) {
            if ($product->wasRecentlyCreated || $product->wasChanged($homeProductColumns)) {
                \App\Http\Controllers\Store\HomeController::flushCache();
            }

            if ($product->wasRecentlyCreated || $product->wasChanged($visibilityColumns)) {
                \App\Http\Controllers\Store\ShopController::flushSidebarCache();
            }
        });

        // Force-delete and soft-delete both land here; a restore is a save.
        \App\Models\Product::deleted(function () {
            \App\Http\Controllers\Store\HomeController::flushCache();
            \App\Http\Controllers\Store\ShopController::flushSidebarCache();
        });

        \App\Models\Post::saved(function (\App\Models\Post $post) {
            // `cover`, not `image` — the journal row renders posts.cover, and
            // there is no posts.image at all. wasChanged() on a column that does
            // not exist is silently never dirty, so naming the wrong one here
            // would have left a changed cover photo stale for fifteen minutes
            // with nothing failing anywhere.
            if ($post->wasRecentlyCreated || $post->wasChanged(['slug', 'title', 'excerpt', 'status', 'published_at', 'cover'])) {
                \Illuminate\Support\Facades\Cache::forget('kbb.home.posts');
                \App\Support\HomeSections::flush(); // Row 55: the Blog section's three articles
            }
        });

        \App\Models\Post::deleted(function () {
            \Illuminate\Support\Facades\Cache::forget('kbb.home.posts');
            \App\Support\HomeSections::flush();
        });

        // The strip is ordered by visible product count and the total is quoted
        // in the copy, so a rename, a new brand and a removal all move it.
        \App\Models\Brand::saved(function (\App\Models\Brand $brand) {
            if ($brand->wasRecentlyCreated || $brand->wasChanged(['name', 'slug', 'logo'])) {
                \Illuminate\Support\Facades\Cache::forget('kbb.home.brands');
                \Illuminate\Support\Facades\Cache::forget('kbb.home.brandcount');
            }

            // Row 55: the Brands section prints the logo AND the banner photo.
            if ($brand->wasRecentlyCreated || $brand->wasChanged(['name', 'slug', 'logo', 'banner'])) {
                \App\Support\HomeSections::flush();
            }
        });

        \App\Models\Brand::deleted(function () {
            \Illuminate\Support\Facades\Cache::forget('kbb.home.brands');
            \Illuminate\Support\Facades\Cache::forget('kbb.home.brandcount');
            \App\Support\HomeSections::flush();
        });

        // Auto-301 on slug change: 'updating' (not 'saved') because this
        // needs the slug's OLD value, which is only still available before
        // the write actually happens. Only for already-published items —
        // a draft's slug changing isn't a broken link anywhere yet, since
        // nothing has ever linked to it.
        \App\Models\Product::updating(function (\App\Models\Product $product) {
            if (!$product->isDirty('slug') || $product->getOriginal('status') !== 'publish') {
                return;
            }

            $oldSlug = $product->getOriginal('slug');
            if (!$oldSlug || $oldSlug === $product->slug) {
                return;
            }

            \App\Support\RedirectManager::autoCreate(
                \App\Support\UrlScheme::product($oldSlug),
                \App\Support\UrlScheme::product($product->slug),
            );
        });

        \App\Models\Post::updating(function (\App\Models\Post $post) {
            if (!$post->isDirty('slug') || $post->getOriginal('status') !== 'published') {
                return;
            }

            $oldSlug = $post->getOriginal('slug');
            if (!$oldSlug || $oldSlug === $post->slug) {
                return;
            }

            /*
             * BOTH SPELLINGS OF THE OLD ADDRESS, AND THE NEW ONE IS /blog/.
             *
             * This wrote '/' . $oldSlug . '/' -> '/' . $post->slug . '/', which
             * was right while articles were served from the site root. They are
             * at /blog/{slug}/ now, so a row written the old way pointed at an
             * address that itself 301s -- two hops for every renamed article,
             * for ever, and growing a link each time it is renamed again.
             *
             * The ROOT form of the old slug is still written, because that is
             * the address Google holds for an article the WordPress site
             * published, and PageController::rootArticle() 404s it the moment
             * the slug stops naming a post. Without the row the old root
             * address is simply gone.
             */
            \App\Support\RedirectManager::autoCreate(
                '/' . $oldSlug . '/',
                \App\Support\UrlScheme::article($post->slug),
            );

            \App\Support\RedirectManager::autoCreate(
                \App\Support\UrlScheme::article($oldSlug),
                \App\Support\UrlScheme::article($post->slug),
            );
        });
    }
}
