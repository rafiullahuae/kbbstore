{{--
    Cart page body — ported verbatim from kbb_cartpage_inner() in
    kbb-theme/functions.php. Classes, element order and inline styles copied
    exactly; only the data expressions are translated to Eloquent.
--}}
@php
    use App\Support\CssUrl;
    use App\Support\Gradient;
    use App\Support\Url;

    /*
     * Cart & mini-cart -> "Cart-page discount code box" (module key
     * cart_coupon_field), default OFF.
     *
     * Read here rather than passed in from CartController because that
     * controller belongs to another lane, and because this is already how a
     * dozen storefront views resolve a module (see product-card.blade.php and
     * partials/checkout/*.blade.php). moduleEnabled() returns the stored
     * module_toggles row when one exists, so an install that has chosen a value
     * keeps it; only an install with no row at all gets the default.
     */
    $kbbCartCoupon = app(\App\Services\SettingsService::class)->moduleEnabled('cart_coupon_field', false);
    // The checkout's "Floating labels on checkout fields" switch (Lane CD)
    // covers this one field too. Asked only when the field is drawn at all.
    $kbbCartFl = $kbbCartCoupon && app(\App\Services\CheckoutPage::class)->floatLabels();
@endphp
@if ($kbbCartFl)
@push('styles')
<style>
/* FLOATING LABEL on the discount code (Lane CD) -- Appearance -> Checkout
   page -> Fields & attention -> "Floating labels on checkout fields". The
   Create account form's `.fld` (kbb.css), restated at this page's specificity:
   the label is the placeholder, and lifts to a small heading inside the box.
   Here and not in kbb-cart.css: printed only on a cart that draws the field
   with the switch on, so every other cart page carries none of it. */
.kbb-cartpage .coupon .fld.kbb-fl{position:relative;flex:1;min-width:0;margin:0}
.kbb-cartpage .coupon .fld.kbb-fl input{width:100%;padding:calc(17px + var(--fld-gap,3px)) 13px 5px;padding-inline-start:40px}
.kbb-cartpage .coupon .fld.kbb-fl > label{position:absolute;inset-inline-start:41px;top:50%;transform:translateY(-50%);max-width:calc(100% - 54px);
  font-size:13px;line-height:1.3;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;pointer-events:none;
  transition:top .16s ease,transform .16s ease,font-size .16s ease,color .16s ease}
.kbb-cartpage .coupon .fld.kbb-fl input:is(:focus,:not(:placeholder-shown),:-webkit-autofill,:autofill) ~ label{
  top:13px;transform:translateY(calc(-7px - var(--fld-gap,3px)));font-size:10.5px;letter-spacing:.04em;color:#1F7D52}
.kbb-cartpage .coupon .fld.kbb-fl .lead{position:absolute;inset-inline-start:13px;top:50%;transform:translateY(-50%);
  display:grid;place-items:center;color:var(--muted);pointer-events:none}
.kbb-cartpage .coupon .fld.kbb-fl .lead svg{width:17px;height:17px;display:block}
.kbb-cartpage .coupon .fld.kbb-fl:focus-within .lead{color:#2E9E6B}
</style>
@endpush
@endif

@if ($items->isEmpty())
    <div class="empty">
        <div class="em">🛍️</div>
        <b>{{ __('store.cart.empty_heading') }}</b>
        <p>{{ __('store.cart.empty_body') }}</p>
        <a class="cobtn" style="max-width:260px;margin:0 auto" href="{{ Url::to('/shop/') }}">{{ __('store.cart.empty_cta') }}</a>
    </div>
@else
{{-- The coupon ticket under "Your Bag" (2.60.512, design A): the cart panel's own line, tap to copy -- Appearance -> Cart panel -> Coupon hint. Zero bytes while it is off or its coupon is not usable now. Inside #cartInner, so emptying the bag takes it away. method_exists: mid-update the opcode cache can still hold the OLD CartPanel, and this page then simply draws no ticket instead of failing (2.60.513). --}}@if (method_exists(\App\Services\CartPanel::class, 'couponHint')){!! app(\App\Services\CartPanel::class)->couponHint() !!}@endif
    @php
        $free = $totals['free_shipping_threshold'];
        $left = $totals['free_shipping_remaining'] ?? 0;
        $pct  = $totals['free_shipping_percent'] ?? 100;

        /*
         * The same guard the cart panel carries, and for the same bytes: this
         * page printed "You're AED 0 away from free delivery" on a basket 30
         * fils short, above a bar the same @php block fills to 100% because the
         * percent is rounded too. Zero is the one number this sentence cannot
         * say while $left > 0, since zero is what "you have it" looks like —
         * and the 🎉 branch below, which is that state, did not run.
         */
        $leftDp = \App\Support\Money::decimalsToDistinguish($left, 0);

        // Lane QK7: the cart page's two free-delivery bars (the band over the
        // items and the one in the summary) obey the checkout's switch --
        // Appearance -> Checkout page -> Delivery labels -> "Free-delivery bar
        // on the cart and checkout pages", off as the owner asked. The cart
        // panel's bar (partials/cart-drawer) does not read it.
        $kbbFsBar = app(\App\Services\CheckoutPage::class)->freeDeliveryBar();
    @endphp
@php
/*
 * Appearance → Cart page (Lane: cart-page).
 *
 * EVERY DIRECTIVE THIS LANE ADDS TO THIS FILE STARTS AT COLUMN 0, and that is
 * load-bearing rather than untidy. Blade compiles @php/@if/@endif to a bare
 * <?php ?> and PHP swallows the single newline after it, so a directive on a
 * line of its own contributes zero bytes — but the INDENTATION in front of it
 * is ordinary text and is emitted whatever the condition says. An @if indented
 * to line up with the markup around it would add its own indent and a newline
 * to every classic cart page in the shop, and StorefrontEnglishUnchangedTest
 * compares this page against the base commit byte for byte. The $kbbCartDp
 * block below is at column 0 for exactly the same reason and says so.
 *
 * $kbbCartPage comes from store/cart.blade.php, which resolves it once so the
 * two halves of this page cannot disagree about which layout they are drawing.
 * On the classic layout — which is how this ships — squeezed() is false, every
 * branch below is skipped, and this file renders the bytes it renders today.
 */
$kbbSq = $kbbCartPage->squeezed();
$kbbCpg = $kbbCartPage->all();
/*
 * The address the docked row names, read from the session on the server.
 *
 * Rendered rather than fetched, so a shopper who reloads the page — or who
 * changes a quantity and gets this whole file re-rendered under them by
 * cart.js — keeps the address they chose with no script running at all. The
 * sheet's script only has to update the row for the tap that just happened.
 *
 * Only on the squeezed layout: App\Support\CartAddressState::all() touches the
 * session and the address book, and the classic page has nothing to show for
 * it.
 */
/*
 * And only while the row is drawn at all: Appearance -> Checkout page ->
 * Fields & attention -> "Address picker row on cart and checkout" ships OFF
 * (Lane CK, asked for), and a row nobody sees has no business costing the
 * signed-in shopper an address-book query.
 */
$kbbAddrRowOn = $kbbSq && $kbbCartPage->addressRowOn();
$kbbAddrState = $kbbAddrRowOn ? \App\Support\CartAddressState::all(request()) : null;
$kbbAddr = $kbbAddrState['chosen'] ?? null;
$kbbSignedIn = (bool) ($kbbAddrState['signedIn'] ?? false);
/*
 * THE STRUCK "was" FOR ONE BASKET LINE, in fils, for the whole line.
 *
 * ── WHY A LINE DOES NOT ASK THE PRODUCT ─────────────────────────────────────
 *
 * Product::compareAtPrice() answers for the PRODUCT, and on a variable one it
 * is MIN(regular) across the variations — the from-price the tile printed the
 * day before the markdown started. That is the right figure wherever the
 * product is collapsed to one number. A basket line is the one place it is
 * not: the line knows exactly WHICH option is in it, so the honest compare-at
 * there is that option's own regular price.
 *
 * They differ whenever the shopper picked a dearer option, and they differ in
 * the direction that understates. A parent whose options are AED 120 and
 * AED 190 has a compare-at of AED 120; a line holding the AED 190 option
 * marked down to AED 140 therefore had a compare-at BELOW what is being
 * charged, so the max() below took the line and the row printed AED 140 with
 * nothing struck beside it — silent, for a shopper who is saving AED 50. That
 * was a deliberate clamp rather than an oversight (printing AED 120 beside
 * AED 140 is worse than printing nothing), and this is the figure it was
 * waiting for.
 *
 * ── THE TWO RULES THIS CANNOT BREAK ─────────────────────────────────────────
 *
 * A struck figure must never be LOWER than what is being charged, and never
 * zero. max() against the line total is both: the compare-at arm can only ever
 * raise the answer above the line, so the callers' `> $line` test is the same
 * test it always was, and a line with no compare-at at all contributes exactly
 * what it costs instead of `(int) null`.
 *
 * `unit_price` is a SNAPSHOT taken at add-to-basket time, so it can sit below
 * today's regular price for reasons that are not a markdown at all. That is
 * why the compare-at is still gated on isOnSale() on both arms rather than
 * being struck whenever it happens to be higher.
 *
 * ── AND IT COSTS NOTHING ────────────────────────────────────────────────────
 *
 * ProductVariant::isOnSale() needs the parent's sale window and refuses to
 * fetch it — Store\CartController::loadCart() eager-loads `items.variant` and
 * not `variant.product`, so reading it would be one query per basket line on
 * the screen where somebody decides to pay. The line already HOLDS that row as
 * $item->product; setRelation() hands over the one it has.
 */
$kbbLineWas = static function ($kbbWasLine): int {
    $kbbWasVariant = $kbbWasLine->variant;
    $kbbWasProduct = $kbbWasLine->product;

    if ($kbbWasVariant !== null) {
        if ($kbbWasProduct !== null && ! $kbbWasVariant->relationLoaded('product')) {
            $kbbWasVariant->setRelation('product', $kbbWasProduct);
        }

        $kbbWasUnit = $kbbWasVariant->isOnSale() ? (int) $kbbWasVariant->compareAtPrice() : 0;
    } else {
        $kbbWasUnit = ($kbbWasProduct && $kbbWasProduct->isOnSale())
            ? (int) $kbbWasProduct->compareAtPrice()
            : 0;
    }

    return max($kbbWasUnit * $kbbWasLine->quantity, $kbbWasLine->lineTotal());
};
@endphp
    <div class="grid">
        <div>
            @if ($free && ! $kbbSq && $kbbFsBar)
            <div class="ship">
                <div class="t">
                    @if ($left > 0)
                        {!! __('store.cart.free_delivery_away', ['amount' => '<b>' . \App\Support\Money::format($left, $leftDp) . '</b>', 'free_delivery' => '<b>' . e(__('store.cart.free_delivery_phrase')) . '</b>']) !!}
                    @else
                        🎉 <b>{!! \App\Support\Phrase::inline(__('store.cart.free_delivery_unlocked')) !!}</b>
                    @endif
                </div>
                <div class="bar"><div class="fill" style="width:{{ $pct }}%"></div></div>
            </div>
            @endif
            <div class="items">
                @foreach ($items as $item)
                    @php
                        $p     = $item->product;
                        // t(), not the column; the seed stays English so a
                        // line keeps one colour in both languages.
                        $brand = $p?->brand?->t('name') ?? '';
                        $name  = $p?->t('name');
                        $seed  = ($p?->brand?->name ?? '') . ($p?->name ?? '');
                        $img   = $item->variant?->image ?: $p?->image;
                        // (Lane IM) The basket page's line thumbnail is the same .kc-th
                        // square as the drawer's and was pulling the same full-size file.
                        // ImageVariants::variantUrl() returns the original untouched when
                        // there is no copy, so a catalogue that has never been through the
                        // batch renders exactly what it renders today.
                        $imgCss = CssUrl::value(\App\Support\ImageVariants::variantUrl((string) $img, 400));
                        $thumb = $imgCss !== '' ? "background-image:url('" . e($imgCss) . "')" : 'background:' . Gradient::for($seed);
                        // (Lane VPA) "Shade: #13 Bright Beige", in the page's
                        // language; '' for a line with no options.
                        $attrs = \App\Support\VariantText::forVariant($item->variant);
                        $line  = $item->lineTotal();
                        // $kbbLineWas(), defined once at the top of this file
                        // and read by the order-value total further down, so the
                        // line and the sum beside it cannot answer differently.
                        // It is the VARIATION's own regular price where the line
                        // holds one -- the parent's compare-at is its FROM-price,
                        // which on a dearer option sits below what is charged --
                        // and it is never below the line total, so the `$was >
                        // $line` test below is the same test it always was.
                        $was   = $kbbLineWas($item);
                        // The struck "was" and the line total are two figures
                        // off one basket line, so they are quoted at one width
                        // and at a width that separates them: whole dirhams
                        // printed both as "AED 100" for a line marked down from
                        // 10000 to 9980 fils. Money::decimalsToDistinguish()
                        // returns the store's usual 0 for every other line.
                        $wasDp = ($was > $line) ? \App\Support\Money::decimalsToDistinguish($was, $line) : null;
                        // (Lane SET) NONE for every line that is not a set, so
                        // the row below is byte-identical on every basket in
                        // this shop today. Priced at THIS line's unit price, so
                        // a line repriced by a quantity bundle reports the
                        // saving it actually got.
                        $kbbSet = \App\Support\SetContents::fromProduct($p, (int) $item->unit_price);
                        // (Lane RE) THIS LINE'S SHARE OF A "BUY THESE TOGETHER"
                        // BUNDLE, from the same pricing pass as the summary
                        // below. Null for every ordinary line, which leaves the
                        // row byte-identical. A bundled line prints what it
                        // costs after the bundle, its own price struck beside
                        // it, and a green tag saying why.
                        $kbbBt = $totals['bundle']['lines'][$item->id] ?? null;
                        if ($kbbBt !== null && $kbbBt['off'] > 0) {
                            $was = max($was, $line);
                            $line -= $kbbBt['off'];
                            $wasDp = \App\Support\Money::decimalsToDistinguish($was, $line);
                        }
                    @endphp
                    {{-- ▲ `ci-set` MARKS A SET LINE AND NOTHING ELSE, and it is what
                         Appearance → Set → Set row on the cart page is scoped to.

                         Those five controls were emitted at
                         `.kbb-cartpage .items .ci.ci`, which is EVERY row in the
                         basket. The owner: "the set row padding etc is disturbing
                         the whole cart all rows, these controls must be apply only
                         and only on Set rows, not on other rows!!!!" A screen
                         called Appearance → SET moving the padding of an ordinary
                         product's row is a control doing something its name does
                         not say, which is the one thing a settings screen may
                         never do.

                         $kbbSet is already computed above for the fanned stack and
                         is SetContents::NONE for every line that is not a set, so
                         this costs no query and no second definition of what a set
                         is.

                         ▲ AND THE COMMENT'S CLOSING BRACE TOUCHES THE ELEMENT,
                         on purpose, with no newline between them. A Blade
                         comment is removed at compile time but the NEWLINE AND
                         INDENTATION around it are not, so a comment on its own
                         lines above this element shifts every byte after it on
                         every /cart in the shop. StorefrontEnglishUnchangedTest
                         caught exactly that here, at byte 22394, which is the same
                         lesson the note further down this file records about a
                         directive eating the newline after it. --}}<div class="ci{{ $kbbSet['members'] ? ' ci-set' : '' }}">
                        <div class="cth" style="{{ $thumb }}">{{ $imgCss !== '' ? '' : Gradient::initials($brand ?: ($name ?? '?')) }}</div>
                        <div class="cmid">
                            @if ($brand)<div class="cbrand">{{ $brand }}</div>@endif
                            <div class="cn"><a href="{{ $p?->url() ?? '#' }}">{{ $name }}</a></div>
                            @if ($attrs)<div class="cvar">{{ $attrs }}</div>@endif
                            @includeWhen($kbbBt, 'partials.buy-together.line-tag', ['cls' => 'cbt', 'percent' => $kbbBt['percent'] ?? 0])@if ($kbbSet['members'])@include('partials.set-row', ['contents' => $kbbSet, 'surface' => 'cart', 'key' => 'c' . $item->id])@endif{{-- (Lane SET) AT THE START OF THIS LINE and never at the end of the one above. A Blade directive compiles to a PHP close tag, and PHP eats a single newline immediately after one -- so a conditional appended to the end of a line SWALLOWS THAT LINE'S NEWLINE, which is a byte changed on every basket in the shop whether or not it holds a set. Measured: StorefrontEnglishUnchangedTest went red on /cart, /checkout and the account order page for exactly that. Here the directives are followed by the line's own content, so nothing is emitted and nothing is eaten when the line is not a set. --}}<div class="qty">
                                <button type="button" data-kcpq="{{ $item->id }}" data-d="-1" aria-label="{{ __('store.cart.decrease_quantity') }}">−</button>
                                <span>{{ $item->quantity }}</span>
                                <button type="button" data-kcpq="{{ $item->id }}" data-d="1" aria-label="{{ __('store.cart.increase_quantity') }}">+</button>
                            </div>
                        </div>
                        <div class="cright">
                            <div class="cpr">{!! \App\Support\Money::format($line, $wasDp) !!}@if ($was > $line)<span class="cwas">{!! \App\Support\Money::format($was, $wasDp) !!}</span>@endif</div>
                            <button class="crm" type="button" data-kcprm="{{ $item->id }}">{{ __('store.cart.remove_item') }}</button>
                        </div>
                    </div>
                @endforeach
@include('partials.free-gifts.box', app(\App\Services\FreeGifts::class)->box($totals) + ['kbbFgClass' => 'fgb-page'])
            </div>
        </div>
@if ($kbbSq)
        {{-- Recommended for you.

             FULL BLEED and no rounded corners: "it should be full width section
             with no border radius, just the background animated changing
             colors, but slight". The wash is a ::before layer so the cards on
             top of it stay opaque and the animation repaints nothing else, and
             it stops entirely for a phone that has asked for reduced motion.

             The whole section disappears when no products have been chosen on
             the admin screen. An empty horizontal scroller under a heading is
             worse than no section. --}}
        @php $kbbRec = $kbbCpg['rec_on'] ? $kbbCartPage->recommended() : collect(); @endphp
        @if ($kbbRec->isNotEmpty())
        <section class="cpg-rec">
            <h2>{{ $kbbCpg['rec_heading'] }}</h2>
            {{-- The carousel arrows. Rendered only when the desktop layout AND
                 the arrows are both switched on, and hidden by CSS below the
                 breakpoint on top of that — a phone swipes, and a button a
                 thumb can press by accident while scrolling is worse than no
                 button. They are OUTSIDE .cpg-rail: inside a scroller they
                 would scroll away with the cards they move. --}}
            @if ($kbbCpg['d_on'] && $kbbCpg['d_arrows'])
            <button class="cpg-arr cpg-arr-l" type="button" data-cpg-rail="-1" aria-label="{{ __('store.cart.recommended_prev') }}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.5 5.5 8 12l6.5 6.5"/></svg></button>
            <button class="cpg-arr cpg-arr-r" type="button" data-cpg-rail="1" aria-label="{{ __('store.cart.recommended_next') }}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9.5 5.5 6.5 6.5-6.5 6.5"/></svg></button>
            @endif
            <div class="cpg-rail">
                @foreach ($kbbRec as $recProduct)
                    @php
                        $recSeed  = ($recProduct->brand?->name ?? '') . $recProduct->name;
                        $recImg   = $recProduct->image;
                        // (Lane IM) The recommended card's picture, same substitution.
                        $recImgCss = CssUrl::value(\App\Support\ImageVariants::variantUrl((string) $recImg, 400));
                        $recStyle = $recImgCss !== ''
                            ? "background-image:url('" . e($recImgCss) . "')"
                            : 'background:' . Gradient::for($recSeed);
                        // Same substitution as the basket line above, and here
                        // it does print: a recommended variable product that is
                        // marked down now shows the figure it was marked down
                        // from, exactly as the tiles on /shop do.
                        $recWas   = $recProduct->isOnSale() ? (int) $recProduct->compareAtPrice() : 0;
                        $recNow   = (int) $recProduct->effectivePrice();
                    @endphp
                    {{-- The card is a link and the + is a button BESIDE it, not
                         inside it: a <button> nested in an <a> is invalid, and
                         browsers disagree about which of the two a tap lands on.

                         `kc-badd` with `data-add` is cart.js's OWN one-tap add,
                         bound on `document`, so this needs no second add path
                         and no script from this lane: the plus becomes a tick,
                         the basket re-renders, and the `busy` class that drives
                         the loading shimmer is set and cleared by the same code
                         that does every other cart write on this page. --}}
                    <div class="cpg-card">
                        <span class="im" style="{{ $recStyle }}">{{ $recImgCss !== '' ? '' : Gradient::initials($recProduct->brand?->name ?: $recProduct->t('name')) }}<button class="kc-badd" type="button" data-add="{{ $recProduct->id }}" aria-label="{{ __('store.cart_drawer.browsed_add') }}">+</button></span>
                        <a class="lk" href="{{ $recProduct->url() }}">
                            <span class="nm">{{ $recProduct->t('name') }}</span>
                            <span class="pr">{!! \App\Support\Money::format($recNow) !!}@if ($recWas > $recNow)<span class="cwas">{!! \App\Support\Money::format($recWas) !!}</span>@endif</span>
                        </a>
                    </div>
                @endforeach
            </div>
        </section>
        @endif

        {{-- The coupon box, minimal and directly under the rail.

             Moved here rather than copied: the block inside the summary below
             is switched off on this layout, so there is exactly one discount
             field on the page whichever layout is on. The applied-coupon row
             and the promo hint stay where they are — they are a state and a
             suggestion, not an entry field. --}}
        @if ($kbbCartCoupon)
        <div class="coupon">
@if ($kbbCartFl)
            <span class="fld kbb-fl kbb-fl-coupon ico"><span class="lead" aria-hidden="true">@include('partials.icon-tag')</span><input type="text" id="kbbCartCoupon" placeholder=" " autocomplete="off"><label for="kbbCartCoupon">{{ __('store.cart.coupon_placeholder') }}</label></span>
@else
            <input type="text" id="kbbCartCoupon" placeholder="{{ __('store.cart.coupon_placeholder') }}" autocomplete="off">
@endif
            <button type="button" data-kcpcoupon>{{ __('store.cart.coupon_apply') }}</button>
        </div>
            @if ($couponHint)
                <div class="cohint"><span>🎁</span><div>{!! $couponHint !!}</div></div>
            @endif
        @endif
@endif

@if ($kbbSq)<div class="cpg-side">{{-- the right-hand column on desktop; display:contents below the breakpoint, so a phone lays these two out exactly as before. See cart-squeeze.blade.php --}}@endif        <aside class="sum">
@php
    /*
     * THE WIDTH EVERY ROW OF THIS SUMMARY PRINTS AT — Lane FA.
     *
     * The basket this lane started from printed "Subtotal AED 90 / − AED 1 /
     * Total AED 90" because each row was rounded on its own on the way to the
     * screen. See CartService::totals()' `decimals` key: 0 when every figure is
     * a whole dirham, which is the ordinary case under the whole-dirham policy,
     * and the currency's full precision for the WHOLE column the moment one of
     * them is not.
     *
     * AT COLUMN 0, WITH NO BLANK LINE AROUND IT, and that is not tidiness.
     * Blade compiles a raw-PHP block to one <?php ?> and PHP swallows the
     * single newline after it, so a block written this way contributes zero
     * bytes to the rendered page — which is what
     * StorefrontEnglishUnchangedTest, comparing this page byte for byte,
     * requires. Indented, it leaves its own indentation behind; given a blank
     * line of its own, it adds one.
     */
    $kbbCartDp = (int) ($totals['decimals'] ?? 0);
    // (Lane RE) The "Buy-together discount" row's figure, signed the way the
    // coupon's row beside it is.
    $kbbBtAmount = \App\Support\Bidi::number('– ' . \App\Support\Money::format((int) ($totals['bundle_discount'] ?? 0), $kbbCartDp));
@endphp
@if (! $kbbSq)
            <h2>{{ __('store.cart.summary_heading') }}</h2>
            <div class="srow"><span>{{ __('store.cart.subtotal') }}</span><span>{!! \App\Support\Money::format($totals['subtotal'], $kbbCartDp) !!}</span></div>
@else
@php
/*
 * Order Value, with the struck-through "before" beside it.
 *
 * The before-price is COMPUTED FROM THE LINES rather than marked up from the
 * subtotal by a percentage: it is the sum of each line's regular price where
 * that line is on sale, and its own price where it is not. A percentage would
 * print a discount the shop is not actually giving, which is the one thing a
 * struck-through figure must never do.
 *
 * It prints only when it is genuinely higher. A "was" equal to the "now" is
 * either noise or a lie, and both read as a lie.
 */
/*
 * ▲ IT IS THE SUM OF EXACTLY THE FIGURES STRUCK ON THE LINES ABOVE.
 *
 * The rule at the head of this note -- "the regular price where the line is on
 * sale, its own price where it is not" -- was spelt as an either/or, and that
 * is safe only while every on-sale product HAS a regular price to offer. A
 * variable parent does not: `products.price` is NULL on it and the money is on
 * the variations. Once Product::isOnSale() started answering true for a
 * variation markdown, the on-sale branch contributed `(int) null` -- ZERO --
 * for that line instead of what the shopper is paying, and the struck order
 * value came out UNDERSTATED: a saving smaller than the one being given, on the
 * screen where somebody decides to pay.
 *
 * Both halves of that now live in $kbbLineWas(), at the top of this file, which
 * the line above reads too -- one definition, so a row and the sum beside it
 * cannot state two different savings. Measured on a basket of one simple
 * product marked AED 200 down to AED 50 beside the AED 190 option of a variable
 * product marked to AED 140 -- subtotal AED 190 -- this row printed **AED 200**
 * before that fix, **AED 340** while the parent's from-price was the only
 * compare-at a variable line had, and **AED 390** now that the line reads the
 * option's own regular price. Every one of those numbers is pinned in
 * VariableProductSaleVisibleTest, and the last is the honest one: the shopper
 * is saving AED 150 and AED 390 is what the two lines cost undiscounted.
 *
 * It is the same number as before for every basket with no variable line at
 * all: a simple product on sale has a compare-at above its line by definition,
 * and one that is not on sale takes the line.
 */
$kbbWasTotal = 0;
foreach ($items as $kbbWasItem) {
    $kbbWasTotal += $kbbLineWas($kbbWasItem);
}
/*
 * THE TOTAL IS THE SUM OF EXACTLY WHAT IS PRINTED ABOVE IT, with one stated
 * exception.
 *
 * A switched-off row adds nothing, because a charge a shopper cannot see on
 * the line above is a charge they meet for the first time at the payment step
 * — and this file already carries a note about the last time the cart and the
 * checkout disagreed about a total.
 *
 * The exception is Express, which is QUOTED and never added even when its row
 * is on: it is an option somebody picks at checkout, not a charge applied
 * behind them, and the reference screen shows exactly that — Express priced
 * beside a free Standard, and a total that matches Standard.
 *
 * The fee is worked out ONCE, in CartPage::serviceFee(), and both the summary
 * and the docked bar read this one variable. Two roundings of the same number
 * is how two totals end up a fil apart on the same screen.
 */
$kbbFee = $kbbCartPage->serviceFee((int) $totals['total']);
$kbbGrand = (int) $totals['total'] + $kbbFee;
@endphp
@php
/* 2.60.495: Appearance -> Cart page -> 13 October layout. "The order value
   should come in the greenish box, and the order total row will be removed";
   the applied coupon shows once, as a ticket inside the same box (its look is
   the checkout's own setting). Off: the rows exactly as before. */
$kbbLoBox = (bool) $kbbCpg['lo_ov_box'];
$kbbLoLook = app(\App\Services\CheckoutPage::class)->couponLook();
$kbbLoTicket = $kbbLoBox && $kbbLoLook !== 'classic';
@endphp
@if (! $kbbLoBox)
            <div class="srow"><span>{{ $kbbCpg['sum_value_label'] }} <span class="cpg-n">({{ trans_choice('store.cart.item_count', $totals['item_count']) }})</span></span><span>@if ($kbbWasTotal > $totals['subtotal'])<span class="cpg-was">{!! \App\Support\Money::format($kbbWasTotal, $kbbCartDp) !!}</span>@endif{!! \App\Support\Money::format($totals['subtotal'], $kbbCartDp) !!}</span></div>
@endif
@endif
            @includeWhen(($totals['bundle_discount'] ?? 0) > 0, 'partials.buy-together.total-row', ['cls' => 'srow disc cbt-row', 'label' => __('store.buy_together.bundle_row'), 'amount' => $kbbBtAmount])@if ($totals['discount'] && ! ($kbbSq && $kbbLoTicket))
                <div class="srow disc">
                    <span>{{ $totals['coupon_code'] }}</span>
                    <span>{!! \App\Support\Bidi::number('– ' . \App\Support\Money::format($totals['discount'], $kbbCartDp)) !!}</span>
                </div>
                <div class="appliedcoupon"><span>✓ {{ strtoupper($totals['coupon_code']) }}</span><a data-kcpremovecoupon="{{ $totals['coupon_code'] }}">{{ __('store.cart.remove_coupon') }}</a></div>
            @endif

            {{-- The entry UI only. The applied-coupon row above stays visible
                 whatever this is set to: hiding it would leave a shopper with a
                 discount they can see on the total and no way to take it off.

                 `! $kbbSq` because the squeezed layout renders this same field
                 under the recommended rail instead. Moved, not copied: two
                 inputs carrying id="kbbCartCoupon" would be one id twice, and
                 cart.js reads the value by id. --}}
            @if ($kbbCartCoupon && ! $kbbSq)
                <div class="coupon">
@if ($kbbCartFl)
                    <span class="fld kbb-fl kbb-fl-coupon ico"><span class="lead" aria-hidden="true">@include('partials.icon-tag')</span><input type="text" id="kbbCartCoupon" placeholder=" " autocomplete="off"><label for="kbbCartCoupon">{{ __('store.cart.coupon_placeholder') }}</label></span>
@else
                    <input type="text" id="kbbCartCoupon" placeholder="{{ __('store.cart.coupon_placeholder') }}" autocomplete="off">
@endif
                    <button type="button" data-kcpcoupon>{{ __('store.cart.coupon_apply') }}</button>
                </div>
                @if ($couponHint)
                    <div class="cohint"><span>🎁</span><div>{!! $couponHint !!}</div></div>
                @endif
            @endif

@if ($kbbSq)
            {{-- The delivery and fee rows.

                 EACH ONE CARRIES ITS OWN (i), and that is a control rather
                 than decoration: every one of these charges is a rule the shop
                 can change, and a shopper who cannot ask why assumes the worst.
                 It is a `title`, so it needs no script and works on a keyboard.

                 EXPRESS IS QUOTED, NOT ADDED. The reference screen shows
                 Express priced beside a free Standard and a total that matches
                 Standard — so it is an option a shopper picks at checkout, and
                 a total that silently included it would surprise them at the
                 payment step. Both rows hide themselves at zero. --}}
            @if ($kbbCpg['sum_express_on'])
                <div class="srow"><span>{{ $kbbCpg['sum_express_label'] }} <i class="cpg-i" title="{{ $kbbCpg['sum_express_help'] }}">i</i></span><span>{!! \App\Support\Money::format((int) $kbbCpg['sum_express'], $kbbCartDp) !!}</span></div>
            @endif
            @if ($kbbCpg['sum_delivery_on'])
                <div class="srow"><span>{{ $kbbCpg['sum_std_label'] }} <i class="cpg-i" title="{{ $kbbCpg['sum_std_help'] }}">i</i></span><span class="free">{{ $kbbCpg['sum_std_free'] }}</span></div>
            @endif
            @if ($kbbCpg['sum_service_on'])
                <div class="srow"><span>{{ $kbbCpg['sum_service_label'] }} <i class="cpg-i" title="{{ $kbbCpg['sum_service_help'] }}">i</i></span><span>{!! \App\Support\Money::format($kbbFee, $kbbCartDp) !!}</span></div>
            @endif
            {{-- WHAT TAKES THE DELIVERY ROW'S PLACE: the free-delivery bar this
                 shop already has, moved here rather than rebuilt.

                 THE SAME CLASSES AND THE SAME TRANSLATION KEYS as the block at
                 the top of this file — `.ship > .t` and `.bar > .fill`,
                 store.cart.free_delivery_away and
                 store.cart.free_delivery_unlocked — so it inherits kbb-cart.css
                 and needs no new strings for words that are already translated
                 into Arabic. It is the same markup twice rather than a shared
                 partial for one reason: the block above is compared BYTE FOR
                 BYTE against the base commit by StorefrontEnglishUnchangedTest,
                 and extracting it would move its indentation. The copy up there
                 is switched off on this layout, so only one renders.

                 BOTH STATES, not only the happy one. "You're AED 40 away from
                 free delivery" is the more useful half: it answers the delivery
                 question AND gives a reason to add another item, which a
                 sentence about the checkout page does neither of.

                 The threshold is the shop's existing one — CartService::totals()
                 already resolves it into $totals['free_shipping_threshold'] —
                 so this lane adds no second setting for it.

                 $kbbCpg['sum_fallback'] is the fallback to the fallback: a shop
                 with no threshold configured has no bar to draw, and a summary
                 that says nothing at all about delivery is the thing all of
                 this exists to avoid. --}}
            @if (! $kbbCpg['sum_delivery_on'])
                @if ($free && ! $kbbFsBar)
                {{-- Lane QK7: switched off, and NOT the fallback line below
                     either -- that one is for a shop with no free-delivery
                     amount, and this shop has one. Nothing is printed. --}}
                @elseif ($free)
                <div class="ship">
                    <div class="t">
                        @if ($left > 0)
                            {!! __('store.cart.free_delivery_away', ['amount' => '<b>' . \App\Support\Money::format($left, $leftDp) . '</b>', 'free_delivery' => '<b>' . e(__('store.cart.free_delivery_phrase')) . '</b>']) !!}
                        @else
                            🎉 <b>{!! \App\Support\Phrase::inline(__('store.cart.free_delivery_unlocked')) !!}</b>
                        @endif
                    </div>
                    {{-- `cpg-flat` at zero, and only there. The fill carries a
                         flowing gradient and a glowing bloom on its leading
                         edge; at 0% there is no edge to ride and the bloom
                         would sit outside the track looking like a stray mark.
                         Decided here, where the number is, rather than by the
                         stylesheet guessing at the inline width. --}}
                    <div class="bar"><div class="fill{{ $pct > 0 ? '' : ' cpg-flat' }}" style="width:{{ $pct }}%"></div></div>
                </div>
                @elseif ($kbbCpg['sum_fallback'] !== '')
                <div class="srow cpg-later"><span>{{ $kbbCpg['sum_fallback'] }}</span></div>
                @endif
            @endif
                {{-- No VAT note. It is inclusive, the checkout says so, and a
                     second place saying it is a second place to keep true. --}}
@if ($kbbLoBox)
                @php $kbbLoShown = ($totals['discount'] && $kbbCpg['lo_ov_after']) ? $kbbGrand : (int) $totals['subtotal']; @endphp
                <div class="cpg-totband cpg-tb2">
@if ($kbbLoTicket && $totals['discount'])
                    <span class="co-tk co-tk-{{ $kbbLoLook }}">@include('partials.icon-tag')<b class="co-tk-code">{{ $totals['coupon_code'] }}</b><span class="co-tk-off">&minus;&nbsp;{!! \App\Support\Money::format($totals['discount'], $kbbCartDp) !!}</span>@if ($kbbCpg['lo_coupon_x'])<button type="button" class="co-tk-x" data-kcpremovecoupon="{{ $totals['coupon_code'] }}" aria-label="{{ __('store.checkout.coupon_remove_label', ['code' => $totals['coupon_code']]) }}">&times;</button>@endif</span>
@endif
                    <div class="cpg-ov"><span>{{ $kbbCpg['sum_value_label'] }} <span class="cpg-n">({{ trans_choice('store.cart.item_count', $totals['item_count']) }})</span></span><span class="tr">@if ($kbbWasTotal > $kbbLoShown)<span class="cpg-was">{!! \App\Support\Money::format($kbbWasTotal, $kbbCartDp) !!}</span>@endif<b>{!! \App\Support\Money::format($kbbLoShown, $kbbCartDp) !!}</b></span></div>
@if ($kbbCpg['lo_ship_on'])
                    <div class="cpg-ship">{{ $kbbCpg['lo_ship_line'] }}</div>
@endif
                </div>
@else
                <div class="cpg-totband">
                    <span>{{ $kbbCpg['sum_total_label'] }}</span>
                    <span class="tr"><b>{!! \App\Support\Money::format($kbbGrand, $kbbCartDp) !!}</b></span>
                </div>
@endif
            {{-- The secure badge, a rule, and the marks. One row, tiny, as
                 asked.

                 THE MARKS ARE DRAWN ARTWORK NOW, not the text chips that used
                 to sit here. The owner asked for proper payment icons, and a
                 brand name set in 6.5px type reads as a label rather than as a
                 mark. They are simplified renderings in each scheme's own
                 colours -- the kind a merchant acceptance row carries -- and
                 NOT the schemes' licensed asset kits. That is a real
                 distinction and the note that stood here before was right to
                 raise it: Visa, Mastercard, Apple Pay, Google Pay, tabby and
                 tamara are trademarks with brand rules about size and clear
                 space. If the owner obtains their supplied kits, or a scheme
                 asks for its own file, App\Support\PaymentMarkArt is the single
                 place any of it is swapped -- nothing else in the application
                 knows what a payment mark looks like. --}}
            @if ($kbbCpg['trust_on'])
                <div class="cpg-trust">
                    <span class="sec"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4.5 12.5 5 5 10-11"/></svg>{{ $kbbCpg['trust_text'] }}</span>
                    <span class="sep" aria-hidden="true">|</span>
                    {{-- The marks come from CartPage::paymentMarks(), not from
                         six literals here. They carry COMPANY NAMES — a
                         translated one is a different company — and prose in a
                         storefront template is what
                         StorefrontStringsAreKeyedTest exists to catch;
                         silencing it with six allowlist entries would spend
                         that guard's credibility on something that should not
                         be in a template at all. The brand names now live in
                         each drawing's aria-label and <title>, still in PHP,
                         which is what keeps this row's meaning for a screen
                         reader once the words became pictures.

                         {!! !!} and not {{ }}: the markup IS the mark. It is
                         safe to print unescaped for one reason only — the list
                         is a hardcoded constant, so nothing user-supplied can
                         reach it. Keep it that way. --}}
                    <span class="paylogos">@foreach ($kbbCartPage->paymentMarks() as $kbbMark)<span>{!! $kbbMark !!}</span>@endforeach</span>
                </div>
            @endif
@else
            <div class="srow tot"><span>{{ __('store.cart.total') }}</span><span>{!! \App\Support\Money::format($totals['total'], $kbbCartDp) !!}</span></div>
@endif
@if (! $kbbSq)
            {{-- CartController::payload() calls totals() with no shipping cost,
                 so this figure is the subtotal less any discount and nothing
                 else. A basket of AED 130 read "Total AED 130" here and became
                 AED 150 on the very next screen. The number is right; the word
                 beside it was not, and one line is cheaper than a shopper
                 discovering the difference at the payment step. --}}
            <div class="srow note">{{ __('store.cart.delivery_at_checkout') }}</div>
            <a class="cobtn" href="{{ Url::to('/checkout/') }}">{{ __('store.cart.checkout_cta') }}</a>
            <a class="conti" href="{{ Url::to('/shop/') }}">{{ __('store.cart.continue_shopping_link') }}</a>
            {{-- Asked, not typed — App\Support\PaymentChips gates the two wallets on
                 App\Services\Payments\Wallets, so this row cannot go on claiming
                 Apple Pay after the shop has stopped being able to take it. Same
                 source as the trust row above, the footer and the product page. --}}<div class="paylogos">@foreach (\App\Support\PaymentChips::row('cart') as $kbbChip)<span>{{ $kbbChip }}</span>@endforeach<span>{{ __('store.footer.pay_cod') }}</span></div>
@endif
@include('partials.policy-links', ['on' => (bool) $kbbCpg['policy_links']])
        </aside>
@if ($kbbSq)
        {{-- The two rows that float at the foot of the screen.

             INSIDE #cartInner, and deliberately, unlike the address sheet in
             cart.blade.php. cart.js replaces this div's contents on every
             quantity change, so the count and the total in the checkout row are
             re-rendered by the server along with the basket that produced them
             — there is no second code path keeping them in step, and therefore
             no way for them to fall out of step.

             The chosen address is rendered here too, from the session, for the
             same reason: a shopper who reloads the page, or who changes a
             quantity, keeps the address they picked without any script running.
             The sheet's script only has to update the row for the tap that has
             just happened.

             FIXED, not sticky. "it must be floating at the bottom of the
             screen" — and a sticky element only floats while its own containing
             block is still under the viewport, so a two-line basket would leave
             the checkout button stranded halfway up the page. .wrap carries
             padding-bottom of exactly these two heights, so the last row is
             never underneath them.

             The address row is the SHORTER of the two, as asked, and both
             heights are sliders. --}}
        <div class="cpg-docked">
        @if ($kbbAddrRowOn)
            {{-- cpg-has is what turns the fade-off-the-right on, and it is
                 rendered by the server so the row is never briefly wrong: a
                 shopper who reloads with an address already chosen gets the
                 fade in the first paint, and one who has not chosen never sees
                 the prompt dissolve. paintRow() keeps it in step after a tap. --}}
            <div class="cpg-addrbar{{ $kbbAddr ? ' cpg-has' : '' }}">
                <div class="who">
                    <b id="cpgAddrHead">{{ $kbbAddr ? str_replace('{tag}', $kbbCpg['sheet_' . $kbbAddr['tag']], $kbbCpg['addr_chosen']) : $kbbCpg['addr_heading'] }}</b>
                    <span id="cpgAddrSub" @if (! $kbbAddr) hidden @endif>{{ $kbbAddr['line'] ?? '' }}</span>
                </div>
                <button class="cpg-addrbtn" id="cpgAddrBtn" type="button">{{ $kbbAddr ? $kbbCpg['addr_btn_change'] : ($kbbSignedIn ? $kbbCpg['addr_btn_change'] : $kbbCpg['addr_btn_add']) }}</button>
            </div>
        @endif
            <div class="cpg-cobar">
                <div class="tally">
                    <span>{{ trans_choice('store.cart.item_count', $totals['item_count']) }}</span>
                    <b>{!! \App\Support\Money::format($kbbGrand, $kbbCartDp) !!}</b>
                </div>
                <a class="cobtn{{ $kbbCpg['lo_btn_black'] ? ' cpg-cob2' : '' }}{{ $kbbCpg['lo_btn_case'] === 'caps' ? ' cpg-cobcaps' : '' }}" href="{{ Url::to('/checkout/') }}"@if ($kbbCpg['lo_btn_black']) style="--cpg-cob-f:{{ (int) $kbbCpg['lo_btn_size'] }}px"@endif>@if ($kbbCpg['lo_btn_icon'] === 'lock')<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>@endif{!! $kbbCpg['lo_btn_icon'] === 'none' ? '' : '<span>' !!}{{ $kbbCpg['co_label'] }}{!! $kbbCpg['lo_btn_icon'] === 'none' ? '' : '</span>' !!}@if ($kbbCpg['lo_btn_icon'] === 'arrow')<span aria-hidden="true">›</span>@endif</a>
            </div>
        </div>
@endif
@if ($kbbSq)</div>@endif
    </div>
@endif
