<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Support\ExportProbe;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\Payments\PaymentRefunder;
use App\Support\DemoSeed;
use App\Support\Money;
use App\Support\OrderEmirate;
use App\Support\StoreTime;
use Carbon\CarbonImmutable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * Store → Orders.
 *
 * WHAT WAS HERE BEFORE. AdminController::orders() returned every order the
 * store has ever taken in one array, and the screen counted the chips by
 * filtering that array in the browser. No pagination, no search, no date or
 * value filter, no export, and the totals were whatever the client had already
 * been handed. Pointed at the 2,419 orders the WooCommerce import brings across
 * that is one enormous response per visit and a chip count that is only ever as
 * right as the page happens to be. That endpoint stays registered — routes/web.php
 * is not this lane's to edit — but nothing reads it any more; see
 * routes/orders-admin.php.
 *
 * WHAT THIS DOES NOT TOUCH. The order DETAIL screen already exists and is
 * already good: AdminOrderController::show backs it, PaymentSettlementController
 * backs the capture panel beside it, and AdminOrderController::refund moves real
 * money through PaymentRefunder. None of that is reimplemented here and no
 * route below overlaps theirs. This controller is the LIST — and the list's View
 * button opens the screen those controllers already serve.
 *
 * WHAT COUNTS AS REVENUE. Order::REAL_STATUSES — processing, onhold, shipped,
 * completed — the same definition the dashboard's revenue figure, Catalog →
 * Reorder and Store → Customers all read. A cancelled, failed, pending, draft or
 * refunded order is a row on this screen but it is not money, and the summary
 * says so. Every row carries counts_as_revenue so the screen never has to
 * re-derive that rule in JavaScript and get it subtly different.
 *
 * WHICH STATUSES EXIST. Not a hard-coded list. `orders.status` is a free-form
 * string precisely so imported Woo statuses survive — the schema's own comment
 * names wc-shipped and wc-tamara-p-failed — so the chips are built from a
 * DISTINCT over the column, with the statuses this application writes itself
 * always present even at a count of zero. A hard-coded vocabulary would quietly
 * hide every imported order whose status nobody thought of.
 *
 * MONEY. Integer fils (AED x 100) end to end. SUM() in SQL, intdiv() for the
 * average order value, Money::plain() for display. No float is constructed
 * anywhere on the path, including in the CSV, where majorString() builds the
 * decimal by integer division.
 *
 * ONE QUERY, NOT ONE PER ROW. /shop once ran 390 queries for four products in
 * this repo. The list is a fixed number of statements whatever the order count:
 * two grouped derived tables (line items, refunds) and one plain join
 * (customers) are LEFT JOINed onto `orders`, so unit counts, refunded totals and
 * the buyer's name all arrive with the page of rows.
 *
 * AND ONLY ONTO THE STATEMENTS THAT READ THEM. A fixed statement count says
 * nothing about what each statement costs, and for a long time all four this
 * endpoint issues carried both derived tables — including the pagination COUNT
 * and the chip counts, which name no column of either. See rowQuery() and
 * withLineAndRefundTotals(): 131.1 ms of SQL to 76.1 ms at 6,000 orders and
 * 27,000 order lines, with the response byte-for-byte identical.
 * docs/page-cost.md.
 *
 * GUEST AND IMPORTED ORDERS. customer_id is nullable and on an import of Woo
 * guest orders it is null for a large share of the table. Such an order still
 * has to show a name, so the name falls back to billing_address, which is JSON
 * on the row itself — decoded in PHP, never with a dialect-specific JSON
 * function in SQL. Missing phone, missing city and historical created_at dates
 * are all expected rather than exceptional.
 *
 * WHAT IS DELIBERATELY NOT RETURNED. `orders` carries ip_address and two full
 * JSON address blobs. The list and the export expose neither: a name, a city and
 * a country are what a list needs, and the customer's IP and street address are
 * already on the detail screen where looking at them is a deliberate act. The
 * rule behind Product::toApi() and SettingController::PUBLIC_KEYS applies with
 * more force to an admin screen holding every buyer's contact details, not less.
 */
class OrdersApiController extends Controller
{
    use \App\Support\AggregatesQueries;

    private const PER_PAGE_DEFAULT = 50;
    private const PER_PAGE_MIN = 10;
    private const PER_PAGE_MAX = 500;

    /** Hard ceiling on one CSV. A modest host is not a reporting server. */
    private const EXPORT_MAX = 50000;

    /** Rows per database round trip while streaming the CSV. */
    private const EXPORT_CHUNK = 500;

    /** Ceiling on one bulk action, so a stuck loop cannot rewrite the table. */
    private const BULK_MAX = 200;

    /**
     * Ceiling on one bulk STATUS change (Lane ORD): the largest page the list
     * shows, so "tick the header box, set a status" works on every page size
     * the screen offers. It was BULK_MAX, and a 500-row page with every box
     * ticked was refused whole with "nothing was changed". The selection is
     * read BULK_CHUNK ids per query rather than in one IN() of 500.
     */
    public const BULK_STATUS_MAX = self::PER_PAGE_MAX;

    private const BULK_CHUNK = 100;

    /**
     * Statuses this application itself writes, so they are offered as chips
     * even before any order has reached them. Imported statuses are added to
     * this from the column at query time — see statusCounts().
     *
     * Sourced from the vocabulary already in the codebase: AdminOrderController
     * writes 'cancelled' and 'draft', PaymentRefunder writes 'refunded',
     * checkout writes 'pending', and Order::REAL_STATUSES names the four that
     * count as revenue.
     */
    private const KNOWN_STATUSES = [
        'draft', 'pending', 'processing', 'onhold', 'shipped',
        'completed', 'cancelled', 'refunded', 'failed',
    ];

    /**
     * Statuses a bulk action may SET.
     *
     * 'refunded' is absent on purpose. That status is written by
     * PaymentRefunder when the refunded total reaches the captured total, and
     * it is a statement about money that actually moved. A bulk button that
     * could set it would be a way to make the books say a refund happened
     * without one having happened.
     */
    private const BULK_SETTABLE = ['pending', 'processing', 'onhold', 'shipped', 'completed', 'cancelled'];

    /* ------------------------------------------------------------------ list */

    public function index(Request $request): JsonResponse
    {
        /*
         * A database error here is reported, not swallowed — the same decision
         * Store → Customers made after a live 500 cost a diagnostic release to
         * even name. Only the driver's message is returned, never the SQL and
         * never the bindings; the bindings carry the operator's search term.
         */
        try {
            return $this->listing($request);
        } catch (\Illuminate\Database\QueryException $e) {
            // New code against the old schema, for the seconds an update
            // takes: the list is drawn without the emirate rather than not at
            // all. Every other database error is reported as before.
            if (OrderEmirate::ready() && OrderEmirate::isMissingColumn($e)) {
                OrderEmirate::markMissing();

                return $this->listing($request);
            }

            report($e);

            return response()->json([
                'message' => 'The order list could not be read from the database.',
                'db_error' => $e->getPrevious()?->getMessage() ?? $e->getMessage(),
            ], 500);
        }
    }

    private function listing(Request $request): JsonResponse
    {
        $page = max(1, (int) $request->query('page', 1));
        $perPage = $this->clampPerPage((int) $request->query('per_page', self::PER_PAGE_DEFAULT));
        $filter = $this->filter($request);
        $sort = (string) $request->query('sort', 'newest');

        // Everything the operator typed EXCEPT the chip, so the chip counts
        // describe the list the other filters have already narrowed to.
        $base = $this->baseQuery($request);

        // Lane EM: the chip counts and the "Orders by emirate" strip come from
        // ONE grouped statement over the view WITHOUT the emirate filter -- the
        // strip has to show every emirate while one is picked, the way the
        // status chips show every status while one is picked.
        $emirate = $this->emirateFilter($request);
        $counts = $this->statusCounts($this->baseQuery($request, false), $request, $emirate, $filter);

        /*
         * An order nobody has read the emirate of yet (placed since the last
         * look; the checkout does not write the column) shows up in that same
         * statement as a NULL group. Only then are the newest such orders read
         * and the counts taken again, BEFORE the rows and the filter use them.
         * So a list with nothing new costs no query for this at all -- the
         * page stays inside the budget AdminOrdersTest holds it to -- and an
         * order placed a second ago is counted under its emirate on the first
         * look. fillMissing() never throws.
         */
        if ($counts['unread'] > 0 && OrderEmirate::fillMissing() > 0) {
            $counts = $this->statusCounts($this->baseQuery($request, false), $request, $emirate, $filter, $counts['counts']['trashed']);
        }

        $query = $this->applyFilter(clone $base, $filter);

        $total = (clone $query)->toBase()->getCountForPagination();
        $lastPage = max(1, (int) ceil($total / $perPage));
        $page = min($page, $lastPage);

        // The aggregates are added HERE, to the clone that fetches rows, and
        // not to $query — which is still needed, unaggregated, by summaryFor()
        // below. applySort() and forPage() mutate what they are given.
        $rows = $this->applySort($this->withLineAndRefundTotals(clone $query), $sort)
            ->forPage($page, $perPage)
            ->get()
            ->map(fn ($o) => $this->rowToApi($o))
            ->values();

        return response()->json([
            'orders' => $rows,
            // $total is passed in rather than counted again: it is already the
            // row count for exactly this filtered view, and summaryFor()'s own
            // note explains why that one figure is not demo-excluded.
            'summary' => $this->summaryFor($query, $total),
            'total' => $total,
            'page' => $page,
            'last_page' => $lastPage,
            'per_page' => $perPage,
            'counts' => $counts['counts'],
            // Chip order, so the screen renders the same sequence every time
            // instead of whatever order the database felt like returning.
            'statuses' => $counts['statuses'],
            // The Source filter's choices (Lane AN): a constant, no query.
            'sources' => ['unknown' => 'Unknown'] + \App\Services\Analytics\Channels::MAP,
            'revenue_statuses' => Order::REAL_STATUSES,
            // Lane EM: orders by emirate in this view (null in the trash, or
            // while the column is not there yet) and the emirate picked.
            'emirates' => $counts['emirates'],
            'emirate' => $emirate === null ? null : ($emirate === '' ? OrderEmirate::OTHER : $emirate),
            // Lane ORD: for the bulk bar's confirmation line.
            'status_emails' => self::emailingStatuses(),
            /*
             * How many invented rows the money above left out, so the screen
             * can say so rather than leaving the owner to wonder why the tiles
             * and the list disagree. The same block the Dashboard, Analytics
             * and Customers endpoints already hand their screens.
             */
            'demo' => DemoSeed::disclosure(),
            'currency' => Money::currency(),
        ]);
    }

    /* ---------------------------------------------------------------- export */

    /**
     * CSV of the CURRENT filtered view — the same rows, in the same order, as
     * the screen the operator is looking at.
     *
     * Streamed in chunks, because a modest host will not hold 2,419 orders and
     * their aggregates in memory alongside the request. Every cell goes through
     * csvCell(): a buyer whose billing name is `=HYPERLINK(...)` must not become
     * a live formula when the owner opens the file, and every name, email and
     * phone in this table was typed by the public at checkout.
     */
    public function export(Request $request): StreamedResponse|JsonResponse
    {
        /*
         * THE SESSION PROBE, BEFORE ANYTHING IS QUERIED. (Lane SEC)
         *
         * The console navigates the whole page at this address rather than
         * fetching it, because that is what puts the file in Downloads instead
         * of in memory and what keeps this response STREAMED. An expired
         * session therefore used to take the administrator to the admin login;
         * since that redirect stopped naming the secret admin path it takes him
         * to a blank 404 with the console gone, which is worse than what it
         * replaced.
         *
         * So the button asks first, with `?probe=1`, and navigates only on a
         * yes. The question passes through this action's own capability
         * (`orders.export`) because AdminCapabilities matches on the route's URI
         * and a query string is not part of it -- so it answers "may THIS
         * operator run THIS export", which a shared liveness endpoint could not.
         *
         * FIRST STATEMENT, so a probe builds no query and no closure.
         * App\Support\ExportProbe carries the whole argument.
         */
        if ($probe = ExportProbe::answer($request)) {
            return $probe;
        }

        $filter = $this->filter($request);
        $sort = (string) $request->query('sort', 'newest');

        /*
         * NO ->limit(self::EXPORT_MAX) HERE, DELIBERATELY. It used to be, and
         * it did nothing at all.
         *
         * chunk() walks the query with forPage(), and forPage() SETS limit and
         * offset — it does not intersect with a limit already on the builder.
         * So the 50,000 ceiling was overwritten by `limit 500 offset 0` on the
         * first round trip and the export streamed the entire filtered table.
         * Proved by the statements the endpoint issues: EXPORT_MAX never
         * appeared in any of them.
         *
         * The ceiling is enforced where it can actually be enforced — by
         * counting rows written and stopping the walk. Returning false from the
         * chunk callback is how chunk() is told to stop.
         */
        $build = fn () => $this->applySort(
            $this->withLineAndRefundTotals(
                $this->applyFilter($this->baseQuery($request), $filter)
            ),
            $sort
        );
        $query = $build();

        $filename = 'orders-' . now()->format('Y-m-d') . '.csv';

        $headers = [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'X-Content-Type-Options' => 'nosniff',
        ];

        return response()->stream(function () use ($query, $build) {
            $out = fopen('php://output', 'w');

            // UTF-8 BOM: without it Excel on Windows reads an Arabic or accented
            // billing name as mojibake, and this order table has both.
            fwrite($out, "\xEF\xBB\xBF");

            fputcsv($out, [
                'id', 'wc_order_id', 'order_number', 'status', 'counts_as_revenue',
                'customer_id', 'customer_name', 'email', 'phone', 'city', 'country',
                'units', 'lines', 'total_fils', 'total', 'refunded_fils', 'refunded',
                'net_fils', 'net', 'payment', 'placed_at', 'paid_at', 'completed_at',
                'trashed', 'currency',
                /*
                 * APPENDED, AND LAST, DELIBERATELY.
                 *
                 * rowToApi() has always computed `is_demo` and this file has
                 * always thrown it away, so a seeded demo order — or a sample
                 * order from Safety -> Demo Content — left this export looking
                 * exactly like a real one. That matters more here than on the
                 * screen: a CSV gets opened in a spreadsheet, summed, and
                 * pasted into something, away from the badge that would have
                 * said what it was.
                 *
                 * At the END of the row rather than beside `status` where it
                 * reads better, because every existing column keeps its
                 * position: anything already reading this file by index is
                 * unaffected, and anything reading it by header name finds the
                 * new one. Rule 1 says the shop does not change under somebody;
                 * a column appended at the end is the smallest change that
                 * tells the truth.
                 */
                'is_demo',
                /*
                 * Lane EM: the emirate the order went to (Dubai, Al Ain ...),
                 * blank abroad or unreadable. APPENDED LAST for the reason
                 * is_demo is: every column before it keeps its position.
                 */
                'emirate',
                /*
                 * Lane OLG: EN or AR, the language the order was placed in.
                 * APPENDED LAST for the reason is_demo and emirate are: every
                 * column before it keeps its position.
                 */
                'language',
                /*
                 * Lane FG: free-gift units on the order (AED 0, not in `units`).
                 * APPENDED LAST for the reason is_demo, emirate and language are.
                 */
                'free_gifts',
            ]);

            $currency = Money::currency();

            $written = 0;

            $walk = function ($chunk) use ($out, $currency, &$written) {
                foreach ($chunk as $order) {
                    if ($written >= self::EXPORT_MAX) {
                        return false;
                    }

                    $written++;

                    $row = $this->rowToApi($order);

                    fputcsv($out, array_map($this->csvCell(...), [
                        $row['id'],
                        $row['wc_order_id'] ?? '',
                        $row['order_number'],
                        $row['status'],
                        $row['counts_as_revenue'] ? 'yes' : 'no',
                        $row['customer_id'] ?? '',
                        $row['customer_name'] ?? '',
                        $row['email'] ?? '',
                        $row['phone'] ?? '',
                        $row['city'] ?? '',
                        $row['country'] ?? '',
                        $row['units'],
                        $row['lines'],
                        $row['total_fils'],
                        $this->majorString($row['total_fils']),
                        $row['refunded_fils'],
                        $this->majorString($row['refunded_fils']),
                        $row['net_fils'],
                        $this->majorString($row['net_fils']),
                        $row['payment'] ?? '',
                        $row['placed_at'] ?? '',
                        $row['paid_at'] ?? '',
                        $row['completed_at'] ?? '',
                        $row['trashed'] ? 'yes' : 'no',
                        $currency,
                        $row['is_demo'] ? 'yes' : 'no',
                        $row['emirate'] ?? '',
                        strtoupper($row['locale']),
                        $row['free_gifts'] ?? 0,
                    ]));
                }
            };

            try {
                $query->chunk(self::EXPORT_CHUNK, $walk);
            } catch (\Illuminate\Database\QueryException $e) {
                // Lane EM: new code against the old schema for the seconds an
                // update takes -- the file is written without the stored
                // emirate (rowToApi() reads it from the addresses) rather than
                // cut off after its header.
                if ($written !== 0 || ! OrderEmirate::ready() || ! OrderEmirate::isMissingColumn($e)) {
                    throw $e;
                }

                OrderEmirate::markMissing();
                $build()->chunk(self::EXPORT_CHUNK, $walk);
            }

            fclose($out);
        }, 200, $headers);
    }

    /* ----------------------------------------------------------------- bulk */

    /**
     * Set the status on a selection.
     *
     * Three refusals, all deliberate. 'refunded' cannot be set at all — see
     * BULK_SETTABLE. Moving a revenue-carrying order to a status that is
     * NOT revenue (cancelling four completed orders, say) takes the money off
     * the store's own figures, so without force those orders are skipped and
     * reported back by name rather than the whole call failing: the operator
     * asked for the selection, and the safe half of it is still what they meant.
     *
     * And an order REVIVED out of `cancelled` or `failed` — which this endpoint
     * can do, because BULK_SETTABLE carries `pending`, `processing` and
     * `onhold` — has to take back the units the cancellation put on the shelf
     * and the coupon use it handed out. When it cannot, that order is skipped
     * and reported the same way, with the sentence naming the product that is
     * short. `force` does NOT override this one; see the catch below for why.
     *
     * Every entry in `skipped` therefore carries a `reason` and a `forceable`
     * flag now. They were implicit while there was one kind of skip; a screen
     * that offers "change those too" over a refusal that force cannot change
     * would be a button that silently does nothing.
     *
     * Every change writes an order note, so the detail screen's history shows
     * who did it and when. A bulk edit with no trace is how a store ends up
     * unable to explain its own numbers.
     *
     * ONE ORDER AT A TIME, THROUGH App\Services\Orders\OrderStatus, and that is
     * a deliberate trade of statements for correctness. What stood here was a
     * single mass whereIn()->update(), kept as one statement on the argument
     * that looping is hundreds — which was true, and was also why this screen
     * had to send its own emails and insert its own notes: a mass update fires
     * no model events, so the observer that tells the customer never saw it.
     * Now that a cancellation also has to hand a coupon use back per order, and
     * the release must know each order's own previous status, the work is
     * per-order whatever shape the write takes. So it goes through the one
     * funnel, the emails come back to the observer that every other screen
     * uses, and the note is written by the thing that made the change. The
     * selection is capped at BULK_MAX; the cost is bounded and paid once per
     * order that actually moves.
     */
    public function bulkStatus(Request $request): JsonResponse
    {
        $data = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:' . self::BULK_STATUS_MAX],
            'ids.*' => ['integer'],
            'status' => ['required', 'string', 'in:' . implode(',', self::BULK_SETTABLE)],
            // "Email the customer about this change", for the whole selection.
            // Absent means no view was expressed and the standing per-status
            // rule decides each one — which is what every caller written before
            // this field existed means.
            'notify' => ['sometimes', 'nullable', 'boolean'],
        ]);

        $ids = $this->uniqueIds($data['ids']);
        $status = (string) $data['status'];
        $force = $request->boolean('force');

        /*
         * Recorded before anything is written, and read by
         * OrderMailer::statusChanged() through the observer. It is the
         * same override the single-order screen sets, applied to every order in
         * the batch rather than to one — deliberately the SAME mechanism, so
         * that "do not email anybody about this" means the same thing whether
         * the operator is looking at one order or forty.
         */
        app(\App\Services\Mail\OrderStatusMailPolicy::class)->decideForRequest(
            $request->has('notify') ? $request->boolean('notify') : null,
        );

        $wasRevenue = in_array($status, Order::REAL_STATUSES, true);

        /*
         * THE CUSTOMER EMAILS GO AFTER THE ANSWER (Lane ORD). Every order that
         * moves can send its status email, and on this shop's SMTP relay a
         * message is a TLS handshake, a login and a DATA exchange — OrderMailer
         * measured ~600 ms each. In line, fifty "Completed" emails held the
         * owner's Proceed for half a minute, past most hosts' time limit, with
         * the rest of the selection unchanged behind the one that timed out.
         * The checkout already defers its mail exactly this way; the same
         * emails, the same gate and the same try/catch per send, just after
         * fastcgi_finish_request() instead of before it. Nothing on this
         * screen reports a send outcome, so nothing is lost by not waiting.
         */
        \App\Services\Mail\OrderMailer::deferUntilResponse();

        // In chunks, never one IN() of the whole selection: the cap is the
        // largest page now, and the four columns are all this loop reads.
        $orders = collect();
        foreach (array_chunk($ids, self::BULK_CHUNK) as $chunk) {
            $orders = $orders->concat(Order::query()
                ->whereIn('id', $chunk)
                ->get(['id', 'order_number', 'status', 'total']));
        }

        // Keyed for the refusal path below, which needs an order's number and
        // value to report it by name and has already loaded both.
        $byId = $orders->keyBy(fn ($o) => (int) $o->id);

        $changeable = [];
        $skipped = [];
        // Already at the status asked for. Not an error and not a refusal,
        // but the owner asked about these orders, so the answer names them
        // ("1 skipped: already Completed") instead of quietly counting less.
        $unchanged = [];

        foreach ($orders as $order) {
            $current = (string) $order->status;

            if ($current === $status) {
                $unchanged[] = (int) $order->id;

                continue;
            }

            $losesRevenue = in_array($current, Order::REAL_STATUSES, true) && ! $wasRevenue;

            if ($losesRevenue && ! $force) {
                $skipped[] = [
                    'id' => (int) $order->id,
                    'label' => (string) $order->order_number,
                    'status' => $current,
                    'total_fils' => (int) $order->total,
                    'total_display' => Money::plain((int) $order->total),
                    // Why this one was left alone. It was implicit while there
                    // was only ever one answer; there are two now, and a
                    // dialog that prints "counts as revenue" over a refusal
                    // about stock is worse than no dialog.
                    'reason' => 'It counts as revenue, so changing it takes its value off the store\'s figures.',
                    // Forceable: the operator can confirm this one and it will
                    // go through. The refusals below cannot, and the screen has
                    // to be able to tell them apart before it offers a button
                    // that would do nothing.
                    'forceable' => true,
                ];

                continue;
            }

            $changeable[] = (int) $order->id;
        }

        $statuses = app(\App\Services\Orders\OrderStatus::class);
        $author = auth('admin')->user()?->name ?: 'Admin';
        $changed = 0;
        $changedIds = [];

        foreach ($changeable as $id) {
            /*
             * THE SAME GUARD THE SINGLE-ORDER SCREEN GETS, because a guard the
             * bulk action walks around is not a guard — and this is the path
             * that walks around it forty orders at a time. BULK_SETTABLE
             * carries `pending`, `processing` and `onhold`, so a selection of
             * cancelled orders set back to `processing` from this list was,
             * until now, forty oversells in one press.
             *
             * Reported rather than fatal, which is the shape this endpoint
             * already uses for the revenue guard above: the operator asked for
             * a selection, the half of it that adds up is still what they
             * meant, and the half that does not is named. One order refused
             * must not cost the other thirty-nine their transition, and it
             * cannot — each moveTo() is its own transaction and a refusal
             * rolls back only its own.
             */
            try {
                $statuses->moveTo($id, $status, by: $author, reason: 'Set from the orders list.');
                $changed++;
                $changedIds[] = $id;
            } catch (\App\Services\Orders\OrderReviveRefused $e) {
                $order = $byId[$id] ?? null;

                $skipped[] = [
                    'id' => $id,
                    'label' => (string) ($order?->order_number ?? $id),
                    'status' => (string) ($order?->status ?? ''),
                    'total_fils' => (int) ($order?->total ?? 0),
                    'total_display' => Money::plain((int) ($order?->total ?? 0)),
                    'reason' => $e->getMessage(),
                    // NOT forceable. `force` is the operator's answer to "this
                    // takes money off your figures", which is a question only
                    // they can settle. It is not an answer to "that jar has
                    // been sold", and wiring it to one would put a button on
                    // the screen whose whole job is to create the oversell.
                    'forceable' => false,
                ];
            }
        }

        return response()->json([
            'ok' => true,
            'status' => $status,
            // What actually moved, not what was scheduled to. A refusal in the
            // loop above has to come off this number or the screen reports
            // forty orders updated over thirty-nine.
            'changed' => $changed,
            'skipped' => $skipped,
            // Lane ORD: what the screen needs to redraw the rows in place
            // rather than reload the list -- which ids moved, which were
            // already there, and whether the new status counts as revenue.
            'changed_ids' => $changedIds,
            'unchanged_ids' => $unchanged,
            'revenue' => $wasRevenue,
        ]);
    }

    /**
     * Which settable statuses email the customer as things stand (Lane ORD),
     * so the bulk bar can say "customers will be emailed" BEFORE Proceed.
     *
     * Asked of OrderStatusMailPolicy -- the one gate OrderMailer itself asks --
     * so the line on the screen and the email that does or does not go can
     * never disagree. A status with no message is false whatever the switch.
     *
     * @return array<string,bool>
     */
    public static function emailingStatuses(): array
    {
        $policy = app(\App\Services\Mail\OrderStatusMailPolicy::class);
        $out = [];

        foreach (self::BULK_SETTABLE as $status) {
            $out[$status] = $policy->supported($status) && $policy->enabled($status);
        }

        return $out;
    }

    /**
     * Move a selection to the trash. Reversible, and it refuses by default.
     *
     * Soft delete, so the rows and their line items survive and bulkRestore
     * brings them straight back. It is still money leaving the store's figures,
     * so an order that counts as revenue is skipped and reported unless force
     * says otherwise — the same shape as the guarded deletes on the customers,
     * brands and categories screens.
     */
    public function bulkDestroy(Request $request): JsonResponse
    {
        $data = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:' . self::BULK_MAX],
            'ids.*' => ['integer'],
        ]);

        $ids = $this->uniqueIds($data['ids']);
        $force = $request->boolean('force');

        $orders = Order::query()
            ->whereIn('id', $ids)
            ->get(['id', 'order_number', 'status', 'total']);

        $deletable = [];
        $skipped = [];

        foreach ($orders as $order) {
            if (in_array((string) $order->status, Order::REAL_STATUSES, true) && ! $force) {
                $skipped[] = [
                    'id' => (int) $order->id,
                    'label' => (string) $order->order_number,
                    'status' => (string) $order->status,
                    'total_fils' => (int) $order->total,
                    'total_display' => Money::plain((int) $order->total),
                ];

                continue;
            }

            $deletable[] = (int) $order->id;
        }

        if ($deletable !== []) {
            Order::query()->whereIn('id', $deletable)->delete();
        }

        return response()->json([
            'ok' => true,
            'deleted' => count($deletable),
            'skipped' => $skipped,
        ]);
    }

    /** Undo a trashing for a selection. Never destructive, so never guarded. */
    public function bulkRestore(Request $request): JsonResponse
    {
        $data = $request->validate([
            'ids' => ['required', 'array', 'min:1', 'max:' . self::BULK_MAX],
            'ids.*' => ['integer'],
        ]);

        $ids = $this->uniqueIds($data['ids']);

        $restored = Order::query()->onlyTrashed()->whereIn('id', $ids)->restore();

        return response()->json(['ok' => true, 'restored' => (int) $restored]);
    }

    /* --------------------------------------------------------------- queries */

    /**
     * `orders` with the joins EVERY statement on this screen needs, and only
     * those.
     *
     *   c   customers, for the account holder's name. A guest order joins to
     *       nothing here and falls back to billing_address in PHP. It stays
     *       here rather than moving to withLineAndRefundTotals() because the
     *       search box matches c.name and the `customer` sort orders by it, so
     *       the FILTERED set is defined in terms of it. It is an eq_ref join on
     *       a primary key and costs a lookup per row returned.
     *
     * WHAT MOVED OUT, AND WHY IT HAD TO.
     *
     * The two grouped derived tables — order_items for units, refunds for the
     * refunded total — used to be joined here, which meant EVERY statement the
     * list issues carried them: the page of 50 rows, the pagination COUNT, the
     * per-status chip counts and the summary strip. A derived table is
     * materialised in full before it can be joined, so each of those four
     * statements aggregated the WHOLE of `order_items` to answer a question
     * about at most fifty orders.
     *
     * Measured on MySQL 8.0 against 6,000 orders and 27,000 order lines
     * (docs/page-cost.md, and `artisan kbb:page-cost` reproduces it):
     *
     *     GET /admin-api/orders-list    10 statements, 131.1 ms of SQL
     *
     * and the split, in one such request:
     *
     *          the page of rows          52.6 ms   needs ia and ra
     *          the summary strip         46.2 ms   names ra; never names ia
     *          the per-status chips      42.5 ms   names neither
     *          the pagination COUNT      41.4 ms   names neither
     *
     * Three of those four do not name a single column of either derived table.
     * `aggregateQuery()` discards the select list precisely so that an
     * aggregate is legal, so `ia` and `ra` were joined, materialised, and then
     * referenced by nothing at all.
     *
     * REMOVING THEM CANNOT CHANGE A COUNT, and that is a property rather than a
     * hope: both subqueries GROUP BY order_id, so each produces at most one row
     * per order, and a LEFT JOIN onto at most one row neither multiplies rows
     * nor drops them. The count over `orders` is therefore identical with the
     * joins and without. Asserted from the other end in
     * tests/Feature/PageCostBudgetTest.php, which compares every figure this
     * endpoint returns against the same figures computed the slow way.
     *
     * After: 10 statements, 76.1 ms. The row page still pays for `ia` because
     * it genuinely prints units and lines; nothing else does.
     *
     * No select bindings are added here. The revenue rule is applied in PHP
     * from the status string rather than as a CASE in the select list, which
     * keeps the binding slot empty and the aggregate() helper simple.
     */
    private function rowQuery(?Builder $from = null): Builder
    {
        $query = ($from ?? Order::query())
            ->leftJoin('customers as c', 'c.id', '=', 'orders.customer_id')
            ->select([
                // An explicit allowlist. `orders` also carries ip_address and
                // two full JSON address blobs; `customers` carries a bcrypt
                // hash, a WordPress phpass hash and a remember token. A screen
                // that selected either whole row would hand all of it to
                // anything that could reach this endpoint.
                'orders.id',
                'orders.wc_order_id',
                'orders.order_number',
                'orders.status',
                'orders.customer_id',
                'orders.email',
                'orders.phone',
                'orders.total',
                'orders.currency',
                'orders.payment_method',
                'orders.payment_method_title',
                'orders.shipping_method',
                'orders.coupon_code',
                // Where the order came from (Lane AN): two short columns, so the
                // Source chip costs the list no query of its own.
                'orders.src_channel',
                'orders.src_campaign',
                // Lane OLG: the language the order was placed in ('en' / 'ar',
                // recorded by App\Support\OrderLocale). One short column on the
                // row already read, so the Lang badge costs the list no query.
                'orders.locale',
                // Selected for the name/city fallback on a guest order and
                // reduced to three fields in rowToApi(). Never returned raw.
                'orders.billing_address',
                'orders.shipping_address',
                'orders.captured_at',
                'orders.paid_at',
                'orders.completed_at',
                'orders.created_at',
                'orders.deleted_at',
                DB::raw('c.name as account_name'),
                DB::raw('c.first_name as account_first_name'),
                DB::raw('c.last_name as account_last_name'),
            ]);

        // Lane EM: the stored emirate, when the column is there. Without it
        // (mid-update) rowToApi() reads the addresses it already has.
        return OrderEmirate::ready() ? $query->addSelect('orders.ship_emirate') : $query;
    }

    /**
     * The two grouped derived tables, added to a query that is about to FETCH
     * ROWS — the page of the list, or the export.
     *
     *   ia  order_items, for units and line count.
     *   ra  refunds, for the refunded total. Restricted to the same statuses
     *       PaymentRefunder::COUNTED sums, so this screen and the refund
     *       ceiling on the detail page can never disagree about how much of an
     *       order has been sent back.
     *
     * addSelect(), not select(): the allowlist rowQuery() built is the point of
     * that method and must survive. Replacing it here would quietly put
     * `orders.*` — ip_address and both address blobs — back on the wire.
     */
    private function withLineAndRefundTotals(Builder $query): Builder
    {
        $items = DB::table('order_items')
            ->groupBy('order_id')
            // Lane FG: free gifts are not units sold; they are counted on their own.
            ->selectRaw('order_id, COALESCE(SUM(CASE WHEN is_gift = 1 THEN 0 ELSE quantity END), 0) as units,'
                . ' COALESCE(SUM(CASE WHEN is_gift = 1 THEN 0 ELSE 1 END), 0) as lines_count,'
                . ' COALESCE(SUM(CASE WHEN is_gift = 1 THEN quantity ELSE 0 END), 0) as gift_units');

        return $this->withRefundTotals($query)
            ->leftJoinSub($items, 'ia', 'ia.order_id', '=', 'orders.id')
            ->addSelect([
                DB::raw('COALESCE(ia.units, 0) as units'),
                DB::raw('COALESCE(ia.lines_count, 0) as lines_count'),
                DB::raw('COALESCE(ia.gift_units, 0) as gift_units'),
            ]);
    }

    /**
     * Refunds alone.
     *
     * The summary strip sums `ra.refunded_fils` and needs nothing from
     * `order_items`, so it takes this and not the pair above. `refunds` is a
     * small table filtered by an indexed status; the cost this saves is the
     * 27,000-row aggregation next door, not this one.
     */
    private function withRefundTotals(Builder $query): Builder
    {
        $refunds = DB::table('refunds')
            ->whereIn('status', PaymentRefunder::COUNTED)
            ->groupBy('order_id')
            ->selectRaw('order_id, COALESCE(SUM(amount), 0) as refunded_fils');

        return $query
            ->leftJoinSub($refunds, 'ra', 'ra.order_id', '=', 'orders.id')
            ->addSelect([DB::raw('COALESCE(ra.refunded_fils, 0) as refunded_fils')]);
    }

    /**
     * Everything the operator typed, except the chip -- and, with $emirate
     * false, except the emirate too (the strip's own view).
     */
    private function baseQuery(Request $request, bool $emirate = true): Builder
    {
        $query = $this->rowQuery();

        $search = trim((string) $request->query('search', ''));

        if ($search !== '') {
            // Somebody searching for "100%" must not turn it into a wildcard.
            $like = '%' . $this->escapeLike($search) . '%';

            $columns = [
                'orders.order_number',
                'orders.email',
                'orders.phone',
                'c.name',
                'c.first_name',
                'c.last_name',
                // A GUEST order has no customers row, so the buyer's name
                // exists only inside the billing_address JSON. Matching the
                // stored text finds it on both MySQL and SQLite without a
                // dialect-specific JSON function; the cost is that a term which
                // happens to be a street or a city matches too. A name search
                // that silently cannot find half the orders on an imported
                // store would be the worse trade.
                'orders.billing_address',
            ];

            $query->where(function ($q) use ($columns, $like, $search) {
                foreach ($columns as $column) {
                    // The column names are literals from the list above, never
                    // anything the request supplies; only the pattern is bound.
                    $q->orWhereRaw($column . ' like ? escape ' . self::LIKE_ESCAPE_SQL, [$like]);
                }

                // (Lane VPA) A line's SKU or option finds its order: "TT-MF-21N"
                // or "Bright Beige" answers "who bought this shade?". One
                // correlated EXISTS on the indexed order_id, asked only while
                // a search is typed.
                if (mb_strlen($search) >= 2) {
                    $q->orWhereExists(function ($sub) use ($like) {
                        $sub->selectRaw('1')->from('order_items as vpa_i')
                            ->whereColumn('vpa_i.order_id', 'orders.id')
                            ->where(function ($w) use ($like) {
                                $w->whereRaw('vpa_i.sku like ? escape '.self::LIKE_ESCAPE_SQL, [$like])
                                    ->orWhereRaw('vpa_i.variant_attributes like ? escape '.self::LIKE_ESCAPE_SQL, [$like]);
                            });
                    });
                }

                // Typing an id finds that order, and typing a WooCommerce order
                // id finds the row it was imported into — the only way to
                // answer "did Woo order 18422 come across?".
                if (ctype_digit($search)) {
                    $q->orWhere('orders.id', '=', (int) $search)
                        ->orWhere('orders.wc_order_id', '=', (int) $search);
                }
            });
        }

        $from = trim((string) $request->query('from', ''));
        $to = trim((string) $request->query('to', ''));

        /*
         * An imported order can have any date at all, including one years old.
         *
         * A SHOP-LOCAL DAY AGAINST A UTC COLUMN -- the same defect the
         * Customers screen carried, in the same shape, fixed the same way.
         * The owner types a date on the shop's clock; `orders.created_at`
         * holds a UTC instant. Comparing the two as calendar days filed an
         * order placed at 01:30 Dubai under the previous day, while the row
         * beside it showed the Dubai date StoreTime::iso() renders into
         * `created_at`. The list and the filter described different days.
         *
         * shopDayStartUtc() converts each shop-local boundary to the UTC
         * instant it actually falls at, and the range is HALF-OPEN so the
         * operator's last day is included whole at any column precision.
         */
        $fromAt = $this->shopDayStartUtc($from);
        $toAt = $this->shopDayStartUtc($to, 1);

        if ($fromAt !== null) {
            $query->where('orders.created_at', '>=', $fromAt);
        }

        if ($toAt !== null) {
            $query->where('orders.created_at', '<', $toAt);
        }

        // Order value, in whole dirhams on the wire and fils in the comparison.
        // A real column, never a SELECT alias: MySQL will not have an alias in
        // a WHERE clause and SQLite accepting one is how that ships unnoticed.
        $min = $request->query('total_min');
        $max = $request->query('total_max');

        if ($min !== null && trim((string) $min) !== '') {
            $query->where('orders.total', '>=', Money::fromMajor((float) $min));
        }

        if ($max !== null && trim((string) $max) !== '') {
            $query->where('orders.total', '<=', Money::fromMajor((float) $max));
        }

        $payment = trim((string) $request->query('payment', ''));

        if ($payment !== '') {
            $query->where('orders.payment_method', '=', $payment);
        }

        // Source (Lane AN): one of Channels::MAP's keys, or "unknown" for the
        // orders nothing recorded (before analytics, imports, manual orders).
        // Anything else is ignored rather than matched.
        $source = trim((string) $request->query('source', ''));

        if ($source === 'unknown') {
            $query->whereNull('orders.src_channel');
        } elseif (\App\Services\Analytics\Channels::valid($source)) {
            $query->where('orders.src_channel', '=', $source);
        }

        // Emirate (Lane EM): a name, the owner's code (DXB, ALAIN ...) or
        // "other"; anything else is ignored, as Source ignores it.
        $picked = $emirate ? $this->emirateFilter($request) : null;

        if ($picked !== null) {
            $query->where('orders.ship_emirate', '=', $picked);
        }

        return $query;
    }

    /**
     * The emirate picked, as the stored value it selects ('' for Other), or
     * null for none, for junk, and while the column is not there yet.
     */
    private function emirateFilter(Request $request): ?string
    {
        return OrderEmirate::ready() ? OrderEmirate::filterValue($request->query('emirate')) : null;
    }

    /**
     * The chip. 'all', 'paid' (every revenue status at once), 'trashed', or one
     * literal status out of the column.
     */
    private function filter(Request $request): string
    {
        return trim((string) $request->query('filter', 'all')) ?: 'all';
    }

    private function applyFilter(Builder $query, string $filter): Builder
    {
        if ($filter === 'all' || $filter === '') {
            return $query;
        }

        if ($filter === 'trashed') {
            return $query->onlyTrashed();
        }

        if ($filter === 'paid') {
            return $query->whereIn('orders.status', Order::REAL_STATUSES);
        }

        // Anything else is a literal status. An unknown one is not rewritten to
        // 'all': a chip that quietly showed every order when the operator asked
        // for one status would be a worse answer than an empty list.
        return $query->where('orders.status', '=', $filter);
    }

    /**
     * The same filtered set, but as an aggregate-only query.
     *
     * selectRaw() APPENDS to the select list, it does not replace it. A
     * "(clone $base)->toBase()->selectRaw('COUNT(*)')" therefore keeps all 24
     * allowlisted columns from rowQuery() and adds an aggregate after them with
     * no GROUP BY on the outer query. SQLite permits that and invents a row for
     * the bare columns; MySQL refuses it outright:
     *
     *   SQLSTATE[42000] 1140 Mixing of GROUP columns (MIN(),MAX(),COUNT(),...)
     *   with no GROUP columns is illegal if there is no GROUP BY clause
     *
     * which is exactly what the live Customers screen returned while every test
     * passed. The joins and the WHERE must survive — the figures describe the
     * filtered set — so only the columns are discarded, and the select bindings
     * go with them: leaving bindings behind for markers that no longer exist
     * sends the driver more values than the statement has placeholders.
     */

    /**
     * Every chip's count.
     *
     * One grouped statement over the whole filtered set for the per-status
     * counts, plus one for the trash — `orders` soft-deletes, so trashed rows
     * are outside the default scope and cannot be counted in the same pass.
     *
     * The status list returned alongside is the union of what this application
     * writes (KNOWN_STATUSES) and what the column actually holds, so an
     * imported `wc-tamara-p-failed` gets a chip rather than being invisible.
     *
     * @return array{counts: array<string,int>, statuses: list<string>}
     */
    private function statusCounts(Builder $base, Request $request, ?string $emirate = null, string $filter = 'all', ?int $trashed = null): array
    {
        /*
         * Lane EM: grouped by emirate as well, in the SAME statement, so the
         * "Orders by emirate" strip costs no query of its own. $base carries no
         * emirate filter; the status chips take the rows of the emirate picked,
         * the strip takes the rows of the chip picked.
         */
        $byEmirate = OrderEmirate::ready();

        $rows = $byEmirate
            ? $this->aggregateQuery($base, 'orders.status as s, orders.ship_emirate as e, COUNT(*) as c')
                ->groupBy('orders.status', 'orders.ship_emirate')
                ->get()
            : $this->aggregateQuery($base, 'orders.status as s, COUNT(*) as c')
                ->groupBy('orders.status')
                ->get();

        $counts = [];
        $all = 0;
        $paid = 0;
        $places = array_fill_keys(array_keys(OrderEmirate::CODES), 0);
        $other = 0;
        $unread = 0;
        $anyUnread = 0;

        foreach ($rows as $row) {
            $status = (string) ($row->s ?? '');
            $n = (int) $row->c;

            if ($byEmirate) {
                $e = $row->e === null ? null : (string) $row->e;
                $known = $e !== null && isset($places[$e]);

                if ($e === null) {
                    $anyUnread += $n;
                }

                if ($this->chipTakes($filter, $status)) {
                    if ($e === null) {
                        $unread += $n;
                    } elseif ($known) {
                        $places[$e] += $n;
                    } else {
                        $other += $n;
                    }
                }

                // The status chips describe the emirate picked.
                if ($emirate !== null && $e !== $emirate) {
                    continue;
                }
            }

            $counts[$status] = ($counts[$status] ?? 0) + $n;
            $all += $n;

            if (in_array($status, Order::REAL_STATUSES, true)) {
                $paid += $n;
            }
        }

        // Lane EM: a recount after reading new orders' emirates keeps the
        // trash figure it already has -- reading an emirate trashes nothing.
        $trashed ??= (int) $this->applyFilter($this->baseQuery($request), 'trashed')
            ->toBase()
            ->getCountForPagination();

        $statuses = array_values(array_unique(array_merge(
            self::KNOWN_STATUSES,
            array_filter(array_keys($counts), fn ($s) => $s !== '')
        )));

        foreach ($statuses as $status) {
            $counts[$status] = $counts[$status] ?? 0;
        }

        $counts['all'] = $all;
        $counts['paid'] = $paid;
        $counts['trashed'] = $trashed;

        $strip = null;

        if ($byEmirate && $filter !== 'trashed') {
            arsort($places);
            $strip = [
                'rows' => array_map(
                    fn (string $name, int $n) => ['key' => $name, 'code' => OrderEmirate::CODES[$name], 'orders' => $n],
                    array_keys($places),
                    array_values($places)
                ),
                'other' => $other,
                'unread' => $unread,
                'total' => array_sum($places) + $other + $unread,
            ];
        }

        return ['counts' => $counts, 'statuses' => $statuses, 'emirates' => $strip, 'unread' => $anyUnread];
    }

    /** Whether a row of this status is in the view the chip $filter picks. */
    private function chipTakes(string $filter, string $status): bool
    {
        return match ($filter) {
            'all', '' => true,
            'paid' => in_array($status, Order::REAL_STATUSES, true),
            'trashed' => false,
            default => $status === $filter,
        };
    }

    /**
     * The figures across the top of the screen, for the filtered view.
     *
     * Revenue is the total of orders in a REAL status only, refunds subtracted.
     * The average order value divides that revenue by the number of REVENUE
     * orders, not by every row — a screen filtered to "cancelled" has an
     * average of nothing, not a division by the wrong denominator. Integer
     * division throughout.
     */
    private function summaryFor(Builder $query, int $rowsInView): array
    {
        $marks = implode(',', array_fill(0, count(Order::REAL_STATUSES), '?'));

        /*
         * ── THE MONEY EXCLUDES DEMO ROWS. THE ROW COUNT DOES NOT. ───────────
         *
         * This screen's four tiles sat on the same query as the list, and the
         * list deliberately SHOWS demo rows and badges them. So a sample order
         * or a seeded demo order was left out of the Dashboard's revenue and
         * out of Analytics -- both of which go through App\Support\DemoSeed --
         * and then counted, in full, in the tile on this screen that says
         * REVENUE in capitals. Three screens agreed on what money is and the
         * fourth quietly did not. Found by creating one sample order and
         * reading the tile: "ORDERS IN THIS VIEW 1 / REVENUE AED 542", against
         * a dashboard that had not moved.
         *
         * `orders` -- "orders in this view" -- is NOT excluded, and that is the
         * distinction rather than an oversight. It is a count of the rows
         * underneath it, which include the demo ones because that is this
         * application's stated policy: figures exclude demo, lists show it and
         * mark it. A row count that disagreed with the visible rows would be a
         * second lie told to fix the first. Everything below it is money, and
         * money is real money.
         *
         * The `demo` block beside `summary` in the response is the other half.
         * Subtracting silently is its own kind of lie -- DemoSeed::disclosure()
         * exists so a screen can say how many rows it left out, and the
         * Dashboard, Analytics and Customers already carry it. This is the
         * fourth.
         */
        $money = DemoSeed::exclude($this->withRefundTotals(clone $query), Order::class, 'orders');

        $row = $this->aggregate(
            // `ra` and nothing else: this reads refunded_fils and no column of
            // the order_items aggregate.
            $money,
            "COUNT(*) as orders,
             COALESCE(SUM(orders.total), 0) as gross,
             COALESCE(SUM(COALESCE(ra.refunded_fils, 0)), 0) as refunded,
             SUM(CASE WHEN orders.status IN ($marks) THEN 1 ELSE 0 END) as paid_orders,
             COALESCE(SUM(CASE WHEN orders.status IN ($marks) THEN orders.total ELSE 0 END), 0) as paid_gross,
             COALESCE(SUM(CASE WHEN orders.status IN ($marks) THEN COALESCE(ra.refunded_fils, 0) ELSE 0 END), 0) as paid_refunded",
            array_merge(Order::REAL_STATUSES, Order::REAL_STATUSES, Order::REAL_STATUSES)
        );

        /*
         * HANDED IN, NOT COUNTED AGAIN. This is how many rows the operator can
         * see rather than how much money there is, so it comes from the
         * unexcluded query -- and the caller has already run exactly that count
         * for the pager. Counting it a second time here was the obvious way and
         * it cost a ninth query on a page AdminOrdersTest budgets at eight;
         * CLAUDE.md says to find another way before raising a budget, and the
         * number was already in the caller's hand.
         */
        $orders = $rowsInView;

        $gross = (int) ($row->gross ?? 0);
        $refunded = (int) ($row->refunded ?? 0);
        $paidOrders = (int) ($row->paid_orders ?? 0);
        $revenue = (int) ($row->paid_gross ?? 0) - (int) ($row->paid_refunded ?? 0);
        $aov = $paidOrders > 0 ? intdiv($revenue, $paidOrders) : 0;

        return [
            'orders' => $orders,
            'paid_orders' => $paidOrders,
            'gross_fils' => $gross,
            'gross_display' => Money::plain($gross),
            'refunded_fils' => $refunded,
            'refunded_display' => Money::plain($refunded),
            'revenue_fils' => $revenue,
            'revenue_display' => Money::plain($revenue),
            'aov_fils' => $aov,
            'aov_display' => Money::plain($aov),
        ];
    }

    private function applySort(Builder $query, string $sort): Builder
    {
        return match ($sort) {
            'oldest' => $query->orderBy('orders.created_at')->orderBy('orders.id'),
            'number' => $query->orderBy('orders.order_number')->orderBy('orders.id'),
            'total_desc' => $query->orderByDesc('orders.total')->orderByDesc('orders.id'),
            'total_asc' => $query->orderBy('orders.total')->orderBy('orders.id'),
            'units_desc' => $query->orderByRaw('COALESCE(ia.units, 0) desc')->orderByDesc('orders.id'),
            'status' => $query->orderBy('orders.status')->orderByDesc('orders.id'),
            // COALESCE/NULLIF because a guest order has no customers row at
            // all; sorting by customer must not bury every guest together
            // under a blank. Falls back to the email, which is never null.
            'customer' => $query->orderByRaw('COALESCE(NULLIF(c.name, ?), orders.email) asc', [''])
                ->orderBy('orders.id'),
            default => $query->orderByDesc('orders.created_at')->orderByDesc('orders.id'),
        };
    }

    /*
     * The two helpers that stood here are gone, and their absence is the point.
     *
     * notifyStatus() existed because a mass update fires no model events, so
     * this screen had to ask OrderMailer::statusChanged() itself — the bug it
     * was written for was marking one order dispatched emailing the customer
     * and marking forty emailing nobody, silently. noteAll() existed because
     * the same mass update could not write its own history.
     *
     * Both were the cost of writing the column here. The write now happens in
     * App\Services\Orders\OrderStatus, as a model save, so the observer every
     * other screen relies on sees a bulk change exactly as it sees a single
     * one, and the note is written beside the change that caused it. Nothing
     * about the behaviour this screen promises has been dropped; it is being
     * provided by the thing that makes the change instead of being remembered
     * by the thing that asks for it.
     */

    /* ------------------------------------------------------------ formatting */

    /**
     * The demo-seeded order ids, read once per request.
     *
     * Memoised on the INSTANCE rather than in a static, for the reason given
     * on the twin in CustomersApiController: a controller is built per request,
     * so the memo expires exactly when the answer might.
     *
     * @var array<int, true>|null
     */
    private ?array $demoOrderIds = null;

    /** @return array<int, true> */
    private function demoOrderIds(): array
    {
        return $this->demoOrderIds ??= DemoSeed::idsFor(Order::class);
    }

    /**
     * One row, as an explicit allowlist of fields.
     *
     * Nothing here is the model, and the two JSON address blobs selected for
     * the fallbacks are reduced to a name, a city and a country before they
     * leave. The customer's IP and street address are on the detail screen,
     * which is a deliberate act to open; a list of 50 rows is not.
     */
    private function rowToApi(object $o): array
    {
        $status = (string) $o->status;
        $total = (int) $o->total;
        $refunded = (int) $o->refunded_fils;
        $demo = $this->demoOrderIds();

        $billing = $this->address($o->billing_address);
        $shipping = $this->address($o->shipping_address);

        $emirate = $o->ship_emirate ?? null;
        if (! is_string($emirate)) {
            $emirate = OrderEmirate::read($shipping, $billing);
        }

        $name = trim((string) ($o->account_name ?? ''));

        if ($name === '') {
            $name = trim(((string) ($o->account_first_name ?? '')) . ' ' . ((string) ($o->account_last_name ?? '')));
        }

        if ($name === '') {
            $name = trim(((string) ($billing['first_name'] ?? '')) . ' ' . ((string) ($billing['last_name'] ?? '')));
        }

        if ($name === '') {
            $name = trim((string) ($billing['name'] ?? ''));
        }

        return [
            'id' => (int) $o->id,
            // The import mapping, on the row, on the screen. Null means this
            // order was placed on this store rather than brought across.
            'wc_order_id' => $o->wc_order_id === null ? null : (int) $o->wc_order_id,
            'order_number' => (string) ($o->order_number ?? $o->id),
            'status' => $status,
            'counts_as_revenue' => in_array($status, Order::REAL_STATUSES, true),
            'customer_id' => $o->customer_id === null ? null : (int) $o->customer_id,
            'customer_name' => $name === '' ? null : $name,
            // A guest order has no customers row. Saying so on the row is how
            // the screen can show it without pretending the buyer has an
            // account it could link to.
            'guest' => $o->customer_id === null,
            'email' => $this->blankToNull($o->email),
            'phone' => $this->blankToNull($o->phone),
            'city' => $this->blankToNull($shipping['city'] ?? $billing['city'] ?? null),
            'country' => $this->blankToNull($shipping['country'] ?? $billing['country'] ?? null),
            // Lane EM: the emirate the order went to ('Dubai' ... 'Al Ain') and
            // the owner's short code (DXB ... ALAIN); null abroad or unread.
            // Stored on the row; read from the two addresses already in hand
            // while it is not (a row the fill has not reached, or mid-update).
            'emirate' => $emirate === '' ? null : $emirate,
            'emirate_code' => OrderEmirate::code($emirate),
            // Lane OLG: 'ar' for an order placed on /ar, otherwise 'en' -- the
            // column's default, and what every imported WooCommerce order is.
            // Never the raw value: anything that is not 'ar' reads as 'en'.
            'locale' => self::orderLocale($o->locale ?? null),
            'units' => (int) $o->units,
            'lines' => (int) $o->lines_count,
            'free_gifts' => (int) ($o->gift_units ?? 0),
            'total_fils' => $total,
            'total_display' => Money::plain($total),
            'refunded_fils' => $refunded,
            'refunded_display' => Money::plain($refunded),
            // Never below zero: a refund recorded for more than the order total
            // is a data problem, not a negative amount the store owes itself.
            'net_fils' => max(0, $total - $refunded),
            'net_display' => Money::plain(max(0, $total - $refunded)),
            // The merchant's own wording snapshotted at checkout wins, exactly
            // as Order::paymentLabel() decides it. The gateway-registry lookup
            // that method falls back to is deliberately NOT done here: it is a
            // per-gateway config read, and a list of 50 rows is the wrong place
            // to do 50 of them. The detail screen still shows the full label.
            'payment' => $this->paymentLabel($o),
            'source' => \App\Services\Analytics\Attribution::chip($o->src_channel, $o->src_campaign),
            'source_key' => $o->src_channel,
            'payment_method' => $this->blankToNull($o->payment_method),
            'shipping_method' => $this->blankToNull($o->shipping_method),
            'coupon_code' => $this->blankToNull($o->coupon_code),
            'captured' => $o->captured_at !== null,
            'placed_at' => $this->iso($o->created_at),
            'paid_at' => $this->iso($o->paid_at),
            'completed_at' => $this->iso($o->completed_at),
            'trashed' => $o->deleted_at !== null,
            /*
             * FIGURES EXCLUDE DEMO ROWS; LISTS SHOW THEM AND SAY SO.
             *
             * The Orders table has drawn a "demo" badge from `o.is_demo` since
             * Demo Content shipped, but that badge was DEAD: the screen moved
             * to /admin-api/orders-list, and this serialiser -- an explicit
             * allowlist -- never carried the field. Only the superseded
             * AdminController::orders() did, and nothing calls it. So a seeded
             * order sat on the live list looking exactly like a real one while
             * being left out of every money figure on the Dashboard and in
             * Analytics, which is the same silence the Customers list was
             * carrying. Same definition of "demo" everywhere -- see
             * App\Support\DemoSeed, which answers from `demo_seed_log`.
             */
            'is_demo' => isset($demo[(int) $o->id]),
        ];
    }

    /**
     * Lane OLG: the order's language as the list and the export show it --
     * 'ar' only for an order recorded as Arabic, 'en' for everything else
     * (the column default, imports, and anything unexpected).
     */
    public static function orderLocale(mixed $value): string
    {
        return is_string($value) && strtolower(trim($value)) === 'ar' ? 'ar' : 'en';
    }

    /** payment_method_title, else the humanised id, else nothing recorded. */
    private function paymentLabel(object $o): string
    {
        $title = trim((string) ($o->payment_method_title ?? ''));

        if ($title !== '') {
            return $title;
        }

        $code = trim((string) ($o->payment_method ?? ''));

        return $code === '' ? 'Not recorded' : ucfirst(str_replace(['_', '-'], ' ', $code));
    }

    /**
     * A stored address, whether it arrived already cast to an array or as the
     * raw JSON string a query-builder select hands back.
     *
     * Imported rows carry every shape there is: a well-formed object, an empty
     * string, the literal "null", and occasionally a JSON array. None of them
     * may throw — a malformed address on one order must not take out the page.
     *
     * @return array<string, mixed>
     */
    private function address(mixed $value): array
    {
        if (is_array($value)) {
            return $value;
        }

        if (! is_string($value) || trim($value) === '') {
            return [];
        }

        $decoded = json_decode($value, true);

        return is_array($decoded) ? $decoded : [];
    }

    /** ISO-8601, whether the value arrived as a Carbon instance or a raw string. */
    private function iso(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        if ($value instanceof \DateTimeInterface) {
            return Carbon::instance($value)->toIso8601String();
        }

        try {
            return Carbon::parse((string) $value)->toIso8601String();
        } catch (\Throwable) {
            return null;
        }
    }

    private function blankToNull(mixed $value): ?string
    {
        if (is_array($value)) {
            return null;
        }

        $value = trim((string) ($value ?? ''));

        return $value === '' ? null : $value;
    }

    /**
     * Make a search term literal inside a LIKE pattern, identically on both
     * dialects.
     *
     * The usual `str_replace(['\\', '%', '_'], ...)` and a plain ->where(…,
     * 'like', …) is a dialect trap. MySQL treats a backslash as the default
     * LIKE escape; SQLite has NO default escape at all, so the same pattern
     * that finds "KBB-100%-OFF" on production matches nothing under the test
     * suite — green here, and a search box that silently drops results only
     * where it is being measured.
     *
     * An explicit `ESCAPE '!'` removes the difference. Both engines accept the
     * clause, and '!' has no special meaning in a string literal on either, so
     * there is no second layer of escaping to get wrong. The escape character
     * itself is doubled first, or a term containing '!' would escape the
     * character after it.
     */
    private const LIKE_ESCAPE = '!';

    /** The literal as it is written into SQL. No binding: it is a constant. */
    private const LIKE_ESCAPE_SQL = "'!'";

    private function escapeLike(string $term): string
    {
        return str_replace(
            [self::LIKE_ESCAPE, '%', '_'],
            [self::LIKE_ESCAPE . self::LIKE_ESCAPE, self::LIKE_ESCAPE . '%', self::LIKE_ESCAPE . '_'],
            $term
        );
    }

    /**
     * Neutralise a spreadsheet formula before it reaches a cell.
     *
     * Excel, LibreOffice and Sheets all execute a cell beginning =, +, - or @,
     * and a leading tab or carriage return sneaks past a naive check of the
     * first character. Every value in this export is supplied by the public:
     * the billing name, the email and the phone are typed at checkout. Prefixing
     * a single quote is the mitigation those applications understand — the cell
     * reads as text and the original characters survive in the raw file.
     */
    private function csvCell(mixed $value): string
    {
        $string = (string) $value;

        if ($string !== '' && str_contains("=+-@\t\r", $string[0])) {
            return "'" . $string;
        }

        return $string;
    }

    /**
     * Fils as a plain decimal string, for a spreadsheet column.
     *
     * Built by integer division, not by dividing a float, and without the
     * thousands separators Money::amount() adds — a grouped number stops being
     * a number once it is in a CSV.
     */
    private function majorString(int $fils): string
    {
        $exponent = Money::minorExponent();

        $sign = $fils < 0 ? '-' : '';
        $abs = abs($fils);

        if ($exponent <= 0) {
            return $sign . $abs;
        }

        $unit = 10 ** $exponent;

        return $sign . intdiv($abs, $unit) . '.' . str_pad((string) ($abs % $unit), $exponent, '0', STR_PAD_LEFT);
    }

    /** @return list<int> */
    private function uniqueIds(array $ids): array
    {
        return array_values(array_unique(array_map('intval', $ids)));
    }

    /**
     * The UTC instant at which a shop-local calendar day begins, for a date the
     * operator typed into a filter box -- or null when they typed nothing, or
     * nothing usable.
     *
     * The twin of CustomersApiController::shopDayStartUtc(), which carries the
     * long form of the argument. In short: storage is UTC, the owner reads and
     * types Dubai, and this is the query-bound direction of that conversion --
     * see App\Support\StoreTime. $plusDays gives the start of the day AFTER
     * the one typed, so a closing bound covers the operator's whole last day
     * without naming a last second the column's precision might outrun; the
     * step is taken on the shop's clock so a DST zone cannot make the next day
     * 23 or 25 hours. The result is handed to the builder as a CarbonImmutable
     * and never as a string, because SQLite compares TEXT and 'T' sorts above
     * ' '. A bound that is not a real Y-m-d is treated as absent; the screen's
     * inputs are `type="date"` and cannot produce one.
     */
    private function shopDayStartUtc(string $day, int $plusDays = 0): ?CarbonImmutable
    {
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) !== 1) {
            return null;
        }

        try {
            $local = CarbonImmutable::createFromFormat('!Y-m-d', $day, StoreTime::timezone());
        } catch (\Throwable) {
            return null;
        }

        if (! $local instanceof CarbonImmutable) {
            return null;
        }

        return StoreTime::startOfDayUtc($local->addDays($plusDays)->format('Y-m-d'));
    }

    private function clampPerPage(int $requested): int
    {
        if ($requested <= 0) {
            return self::PER_PAGE_DEFAULT;
        }

        return max(self::PER_PAGE_MIN, min(self::PER_PAGE_MAX, $requested));
    }
}
