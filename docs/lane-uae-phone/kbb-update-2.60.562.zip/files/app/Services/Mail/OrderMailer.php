<?php

declare(strict_types=1);

namespace App\Services\Mail;

use App\Mail\NewOrderAlert;
use App\Mail\OrderConfirmation;
use App\Mail\OrderRefunded;
use App\Mail\OrderStatusChanged;
use App\Models\Order;
use App\Models\Refund;
use App\Services\SettingsService;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

/**
 * Every order email this store sends, and the one rule that governs all of them.
 *
 * THE RULE: PLACING AN ORDER MUST NEVER FAIL BECAUSE EMAIL FAILED.
 *
 * This is not a general preference for robustness. The store runs on modest
 * hosting through the host's own SMTP, and the ways that goes wrong are
 * ordinary: the relay refuses the From address, the mailbox password expires,
 * outbound 465 is silently dropped so the connection hangs until the
 * 20-second timeout in MailConfigurator fires. Each of those throws a Symfony
 * TransportException. If one of them reached CheckoutController::place() the
 * shopper would see a 500 on a card that had already been charged — and this
 * project has already had a checkout outage (the missing $giftFee in the
 * transaction closure) that nothing caught until a test finally POSTed to the
 * endpoint.
 *
 * So every send in this class is wrapped. A failure is logged with the order
 * number and the exception class, and the caller is told nothing, because there
 * is nothing the caller could usefully do: the order is placed, the money is
 * taken, and a missing email is a support question rather than a failed sale.
 *
 * NOTHING IS QUEUED, AND NOTHING MAY BE. There is no queue worker on this host.
 * A queued Mailable would be written to the jobs table and never sent, which is
 * worse than a logged failure because it looks like success. The two marketing
 * modules that need a worker (`abandoned_cart`, `back_in_stock`) are still marked
 * `todo` in the registry for exactly this reason.
 *
 * THE SWITCHES ARE READ LITERALLY, NOT BUILT. Each check below spells its module
 * key out in full rather than interpolating one. Phase3ModuleSwitchesTest greps
 * the source for `moduleEnabled('<key>'` to prove that a registry row marked
 * `live` really has a reader, and a key assembled at runtime would defeat that
 * check — which is the same class of fault as a toggle that silently does
 * nothing, three of which this project has already shipped.
 */
class OrderMailer
{
    /**
     * Where a merchant alert goes when the owner has not named an address.
     *
     * The From address, because on this host it must already be a real mailbox on
     * the domain — a modest host rejects anything else — so it is the one address
     * we know exists and can receive. Better than dropping the alert silently.
     */
    public const MERCHANT_FALLBACK_KEY = 'mail_from_address';

    public function __construct(
        private SettingsService $settings,
        private MailSettings $mail,
    ) {}

    // ------------------------------------------------------------------
    // AFTER THE RESPONSE, ON THE CHECKOUT'S OWN REQUESTS (Lane PO).
    //
    // Every send below talks to a mail server -- Gmail's SMTP relay or this
    // host's MTA -- and every one used to happen INSIDE the shopper's request.
    // Cash on delivery sent two (the receipt and the merchant alert) before
    // place() answered, and the card's confirmation sent the receipt before the
    // shopper could see the thank-you page. On Gmail that is a TLS handshake, a
    // login and a DATA exchange per message: the measured preview, with a
    // 600 ms stand-in per message, had place() at 1,313 ms of which 1,200 was
    // mail.
    //
    // NOT A QUEUE -- the header above says why there must not be one. It is
    // app()->terminating(), which Laravel runs after Symfony's send() has
    // called fastcgi_finish_request(): the shopper has the answer and the PHP
    // worker carries on into the mail, in the same process, with the same
    // try/catch around each send. OwnerAppEvents and OwnerAppAlerts already
    // send this way on the same host.
    //
    // OPT-IN PER REQUEST, never global. Only the checkout's place() and its
    // order-received page switch it on; every admin screen that reports
    // "sent" or "failed" back to the owner (resend, on-hold, invoice) still
    // sends in line, because their answer is the point.
    //
    // ARMED ONCE PER CONTAINER: terminating callbacks are not cleared after
    // they run, so one per call would resend earlier mail at every later
    // terminate in a long-lived process (OwnerAppAlerts' note).
    // ------------------------------------------------------------------

    private static bool $deferring = false;

    /** @var list<callable> */
    private static array $pending = [];

    /** From here to the end of this request, order mail goes after the response. */
    public static function deferUntilResponse(): void
    {
        self::$deferring = true;

        try {
            $app = app();
            if (! $app->bound('kbb.order-mail.armed')) {
                $app->instance('kbb.order-mail.armed', true);
                $app->terminating(static fn () => self::flushDeferred());
            }
        } catch (\Throwable) {
            // No container to wait for: send in line, as before.
            self::$deferring = false;
        }
    }

    /** Drop what is waiting without sending it -- a test's reset, never the shop's. */
    public static function forget(): void
    {
        self::$deferring = false;
        self::$pending = [];
    }

    /** Whether a send right now would wait for the response. */
    public static function deferring(): bool
    {
        return self::$deferring;
    }

    /** Send what waited. Returns how many sends ran. Cannot throw. */
    public static function flushDeferred(): int
    {
        self::$deferring = false;
        $todo = self::$pending;
        self::$pending = [];

        foreach ($todo as $send) {
            try {
                $send();
            } catch (\Throwable) {
                // send() logs its own failures; nothing here may reach the shopper.
            }
        }

        return count($todo);
    }

    // ------------------------------------------------------------------
    // The switches. One literal key each — see the class header.
    // ------------------------------------------------------------------

    public function confirmationEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_confirmation', true);
    }

    public function merchantAlertEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_merchant_new_order', true);
    }

    /** "Payment not received" to the shop, 30 minutes after an unpaid order. */
    public function unpaidAlertEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_merchant_unpaid', true);
    }

    public function shippedEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_shipped', true);
    }

    public function cancelledEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_cancelled', true);
    }

    public function refundEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_refunded', true);
    }

    /*
     * ── LANE RL: THE REST OF THE STATUSES, AND THE TWO REMINDERS ────────────
     *
     * The owner, 3 October: "New emails for on hold, delivered/completed and
     * payment failed ... for hold keep OFF, as we will have manual option to
     * send for it." Processing, Completed (the shop's "delivered"), Refunded
     * and Payment failed therefore ship ON, because he asked for them; On hold
     * ships OFF, because he said so, with "Send on-hold email" on the order
     * screen as the manual way. Literal keys, one reader each — see the class
     * header.
     *
     * `email_order_marked_refunded` is NOT `email_order_refunded`. That one is
     * the money email, sent when a refund row settles; this one is the status,
     * for an order marked Refunded when the money went back some other way.
     * statusChanged() keeps them from both firing for one refund.
     */

    public function processingEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_processing', true);
    }

    public function onholdEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_onhold', false);
    }

    public function completedEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_completed', true);
    }

    public function markedRefundedEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_marked_refunded', true);
    }

    public function failedEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_failed', true);
    }

    /** "Complete your order", 30 minutes after an unpaid order was placed. */
    public function firstReminderEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_reminder_1', true);
    }

    /** And again at 24 hours. */
    public function secondReminderEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_reminder_2', true);
    }

    /** "How is your glow?", 3 hours after the Delivered email went. */
    public function feedbackEnabled(): bool
    {
        return $this->settings->moduleEnabled('email_order_feedback', true);
    }

    /**
     * Which status changes email, and the per-order exception to it.
     *
     * Resolved lazily rather than injected, because the policy resolves THIS
     * class back — it asks shippedEnabled() and cancelledEnabled() above rather
     * than reading the two keys a second time, so that each module key keeps
     * exactly one reader in this application. Two scoped services that
     * construct each other would not resolve; two scoped services that fetch
     * each other on use resolve fine, and both are the request's own instance,
     * which is what carries the operator's per-order decision from the
     * controller to the observer.
     */
    private function statusPolicy(): OrderStatusMailPolicy
    {
        return app(OrderStatusMailPolicy::class);
    }

    // ------------------------------------------------------------------
    // The sends
    // ------------------------------------------------------------------

    /**
     * An order has just been placed: receipt the customer, tell the store.
     *
     * Called from CheckoutController::place() AFTER the database transaction has
     * committed and after the gateway has accepted the order. Not before either:
     * inside the transaction a mail failure would roll the order back, and before
     * the gateway a declined payment would have receipted an order that does not
     * exist.
     *
     * The two sends are independent. A merchant address that bounces must not cost
     * the customer their receipt, so each is attempted in its own guard.
     */
    public function placed(Order $order): void
    {
        if ($this->isSample($order)) {
            return;
        }

        /*
         * The outermost guard, and the reason it is here rather than only around
         * each send: CheckoutController calls this method directly, so anything
         * that throws BEFORE the per-send try — reading the module toggles when
         * the cache store is broken, loading the items relation, resolving the
         * merchant address — would surface as a 500 on a checkout whose order is
         * already placed and whose payment may already be taken.
         */
        try {
            $this->sendPlaced($order);
        } catch (\Throwable $e) {
            Log::error('order mail failed before sending', [
                'order' => $order->order_number,
                'kind' => 'placed',
                'exception' => class_basename($e),
                'message' => $this->redact($e->getMessage()),
            ]);
        }
    }

    private function sendPlaced(Order $order): void
    {
        $order->loadMissing('items');

        /*
         * B1 — NO RECEIPT FOR AN ORDER NOBODY HAS PAID FOR (Lane RL).
         *
         * This used to send the customer's receipt for every order the moment
         * the gateway had STARTED, which for card, Tabby and Tamara is while
         * the order is still `pending`: a shopper who abandoned the card form
         * kept "we are packing it with care" for an order that was never paid.
         * The owner: the receipt goes "only once the order is actually
         * paid/placed for real".
         *
         * So it is sent here only when the order has already left `pending`
         * by the time the gateway hands back — cash on delivery, which moves
         * it to `processing` inside start(). Everything else is receipted by
         * receipt(), called from OrderMailObserver when the payment confirms
         * and the order moves out of pending — every gateway's webhook and
         * return path reaches that through PaymentConfirmer and the
         * OrderStatus funnel, and "Mark as paid" does too. receipt() claims
         * the send in `order_emails`, so the COD path (observer AND here)
         * still sends exactly one.
         *
         * The merchant alert below is unchanged: still at placement, paid or
         * not. Nobody asked for that to move.
         */
        if ($this->isPlaced($order)) {
            $this->receipt($order);
        }

        if ($this->merchantAlertEnabled()) {
            /*
             * THE ONE EMAIL THAT IS NOT SENT IN THE ORDER'S LANGUAGE, and the
             * reason the flag exists at all. This goes to the SHOP, not to the
             * shopper. An Arabic order would otherwise put the owner's own "new
             * order" alert into Arabic — a language he may not read — because of
             * a choice his customer made. It renders in the process's locale,
             * which is what it did before this lane and what NewOrderAlert's
             * CUSTOMER_FACING = false already says about it.
             */
            $this->send(static fn () => new NewOrderAlert($order), $this->merchantAddress(), $order, 'merchant_alert', false);
        }
    }

    /** The statuses an order is in once it has really been placed. */
    public const PLACED_STATUSES = ['processing', 'onhold', 'shipped', 'completed'];

    /** The statuses an order sits in while nobody has paid for it. */
    public const UNPAID_STATUSES = ['pending', 'failed'];

    private function isPlaced(Order $order): bool
    {
        return in_array((string) $order->status, self::PLACED_STATUSES, true);
    }

    /**
     * The customer's receipt, AT MOST ONCE PER ORDER — Lane RL.
     *
     * Called when the order is placed for real: at checkout for cash on
     * delivery, and from OrderMailObserver when a payment confirmation (or a
     * person) moves the order out of pending/failed. A webhook and the
     * browser's own return can both confirm one payment; PaymentConfirmer
     * applies only one of them, and the `order_emails` claim below is the
     * second lock, so a receipt cannot go twice even if two paths reach here.
     *
     * Honours, in this order: sample orders (never), imported WooCommerce
     * orders (never — WooCommerce receipted them), an import's suppression,
     * the operator's tick for THIS change if they took one, and the
     * Order confirmation switch. Only then is the send claimed.
     */
    public function receipt(Order $order): void
    {
        try {
            if ($this->isSample($order) || $order->wc_order_id !== null) {
                return;
            }

            $decision = $this->statusPolicy()->receiptDecision($order);

            if ($decision === false || ($decision === null && ! $this->confirmationEnabled())) {
                return;
            }

            if (trim((string) $order->email) === '') {
                return;
            }

            if (! app(OrderEmailLog::class)->claim($order, 'confirmation')) {
                return;
            }

            $order->loadMissing('items');

            $this->send(static fn () => new OrderConfirmation($order), (string) $order->email, $order, 'confirmation');
        } catch (\Throwable $e) {
            Log::error('order receipt failed before sending', [
                'order' => $order->order_number,
                'exception' => class_basename($e),
                'message' => $this->redact($e->getMessage()),
            ]);
        }
    }

    /**
     * An order's status moved from $from to $to. What OrderMailObserver calls.
     *
     * OUT OF pending/failed INTO A PLACED STATUS is the moment the order became
     * real, so that is the receipt. When the destination is `processing` the
     * receipt IS the message — a "we are preparing your order" in the same
     * second as "thank you for your order" would be two emails about one
     * event — so the status email is not sent as well. Anything else (an
     * order paid and marked shipped in one step, say) gets both.
     */
    public function transition(Order $order, ?string $from, string $to): void
    {
        if ($from !== null
            && in_array($from, self::UNPAID_STATUSES, true)
            && in_array($to, self::PLACED_STATUSES, true)) {
            $this->receipt($order);

            if ($to === 'processing') {
                return;
            }
        }

        $this->statusChanged($order, $to);
    }

    /**
     * "Complete your order", reminder 1 (30 minutes) or 2 (24 hours).
     *
     * Called by OrderReminders, which has already decided the order is due and
     * claimed the send. Swallows like every automatic send here.
     */
    public function reminder(Order $order, int $stage): void
    {
        if ($this->isSample($order)) {
            return;
        }

        $order->loadMissing('items');

        $this->send(
            static fn () => new \App\Mail\OrderPaymentReminder($order, $stage),
            (string) $order->email,
            $order,
            'reminder_' . $stage,
        );
    }

    /**
     * "Payment not received", to the shop (17 October 2026).
     *
     * Called by OrderReminders, which has already decided the order is still
     * unpaid 30 minutes on and claimed the send. In the shop's language, like
     * the new-order alert. Swallows like every automatic send here.
     */
    public function unpaidAlert(Order $order): bool
    {
        if ($this->isSample($order)) {
            return false;
        }

        $order->loadMissing('items');

        return $this->send(static fn () => new \App\Mail\UnpaidOrderAlert($order), $this->merchantAddress(), $order, 'merchant_unpaid', false);
    }

    /**
     * "Send order link" -> Email, pressed on the order screen (Lane OL).
     *
     * REPORTS, like resendConfirmation(): a person pressed it and is owed the
     * truth. No module switch, for the reason emailInvoice() gives — this only
     * happens because somebody asked, for one order, now. Through send(), so
     * it is labelled in the delivery record ("Payment link") and lands in the
     * order's Emails card, in the ORDER's language.
     *
     * @return array{ok: bool, message: string}
     */
    public function payLink(Order $order, string $url, string $subject = ''): array
    {
        if ($this->isSample($order)) {
            return $this->sampleRefusal();
        }

        $to = trim((string) $order->email);

        if ($to === '' || ! str_contains($to, '@')) {
            return ['ok' => false, 'message' => 'This order has no email address on it.'];
        }

        $order->loadMissing('items');

        // Not deferred: the answer is what the person pressing it reads.
        $deferring = self::$deferring;
        self::$deferring = false;

        try {
            $sent = $this->send(static fn () => new \App\Mail\OrderPayLink($order, $url, $subject), $to, $order, 'paylink');
        } finally {
            self::$deferring = $deferring;
        }

        return $sent
            ? ['ok' => true, 'message' => 'Order link emailed to ' . $to . '.']
            : ['ok' => false, 'message' => 'The email could not be sent. Store → Emails → Sent mail has the reason.'];
    }

    /**
     * "Ask for UAE number", pressed beside the phone on the order screen
     * (2.60.562). REPORTS, like payLink(): a person pressed it and reads the
     * answer. No module switch, for the same reason -- it only happens because
     * somebody asked, for one order, now. In the ORDER's language; the signed
     * link is built inside that render (OrderPhoneRequest's constructor).
     *
     * @return array{ok: bool, message: string}
     */
    public function phoneRequest(Order $order): array
    {
        if ($this->isSample($order)) {
            return $this->sampleRefusal();
        }

        $to = trim((string) $order->email);

        if ($to === '' || ! str_contains($to, '@')) {
            return ['ok' => false, 'message' => 'This order has no email address on it.'];
        }

        $deferring = self::$deferring;
        self::$deferring = false;

        try {
            $sent = $this->send(static fn () => new \App\Mail\OrderPhoneRequest($order), $to, $order, 'phone_request');
        } finally {
            self::$deferring = $deferring;
        }

        return $sent
            ? ['ok' => true, 'message' => 'UAE number request emailed to ' . $to . '.']
            : ['ok' => false, 'message' => 'The email could not be sent. Store → Emails → Sent mail has the reason.'];
    }

    /**
     * "Send on-hold email", pressed on the order screen — Lane RL.
     *
     * The owner keeps the on-hold email OFF and sends it by hand, so this does
     * NOT consult the switch: the switch decides what the shop sends by
     * itself, and this is the owner asking, for one order, now (the argument
     * emailInvoice() makes). It REPORTS, like the other two buttons, because
     * a person is waiting for the answer.
     *
     * $note is the owner's own sentence ("What we need: ..."), plain text,
     * printed escaped. Only for an order that is actually on hold — an
     * on-hold email about an order that is not on hold would be untrue.
     *
     * @return array{ok: bool, message: string}
     */
    public function sendOnHold(Order $order, string $note = ''): array
    {
        if ($this->isSample($order)) {
            return $this->sampleRefusal();
        }

        if ((string) $order->status !== 'onhold') {
            return ['ok' => false, 'message' => 'This order is not on hold. Change its status to On hold first.'];
        }

        $to = trim((string) $order->email);

        if ($to === '' || ! str_contains($to, '@')) {
            return ['ok' => false, 'message' => 'This order has no email address on it.'];
        }

        try {
            $order->loadMissing('items');

            $this->inLocale($order, true, function () use ($to, $order, $note): void {
                $this->log()?->labelNext('order.status_onhold');

                Mail::mailer(MailConfigurator::MAILER)
                    ->to($to)
                    ->send(new OrderStatusChanged($order, 'onhold', $note));
            });

            return ['ok' => true, 'message' => 'On-hold email sent to ' . $to . '.'];
        } catch (\Throwable $e) {
            $this->log()?->recordFailure($e);

            Log::error('on-hold email failed', [
                'order' => $order->order_number,
                'exception' => class_basename($e),
                'message' => $this->redact($e->getMessage()),
            ]);

            return ['ok' => false, 'message' => 'Could not send: ' . $this->redact($e->getMessage())];
        }
    }

    /**
     * Send the customer's receipt again, on purpose, from the admin.
     *
     * NOT placed(): that also fires the merchant alert, and a second "new
     * order" landing in the owner's inbox because they re-sent a customer's
     * receipt is a lie about what happened.
     *
     * And unlike every other method here, this one REPORTS. The swallowing in
     * placed() exists because a dead SMTP host must not take down a checkout
     * whose payment is already taken; nothing is waiting on the answer. Here a
     * person pressed a button and is owed the truth — a button that says
     * "Sent" whatever happened is worse than one that refuses.
     *
     * The module switch is honoured: if the owner has turned confirmations off,
     * a resend is refused rather than quietly overriding their setting.
     *
     * @return array{ok: bool, message: string}
     */
    public function resendConfirmation(Order $order): array
    {
        if ($this->isSample($order)) {
            return $this->sampleRefusal();
        }

        if (! $this->confirmationEnabled()) {
            return [
                'ok' => false,
                'message' => 'Order confirmation emails are switched off in Store → Modules → Order emails.',
            ];
        }

        $to = trim((string) $order->email);

        if ($to === '') {
            return ['ok' => false, 'message' => 'This order has no email address on it.'];
        }

        try {
            $order->loadMissing('items');

            // In the ORDER's language, not the admin's. A resend is the case
            // inLocale() exists for: the operator pressing this button is
            // looking at an English back office, and the customer it goes to is
            // not necessarily reading one.
            $this->inLocale($order, true, static function () use ($to, $order): void {
                Mail::mailer(MailConfigurator::MAILER)
                    ->to($to)
                    ->send(new OrderConfirmation($order));
            });

            return ['ok' => true, 'message' => 'Confirmation re-sent to ' . $to . '.'];
        } catch (\Throwable $e) {
            Log::error('resend confirmation failed', [
                'order' => $order->order_number,
                'exception' => class_basename($e),
                'message' => $this->redact($e->getMessage()),
            ]);

            return [
                'ok' => false,
                // The driver's own words, redacted of the SMTP password, because
                // "it failed" sends the owner to a log file they cannot read on
                // modest hosting.
                'message' => 'Could not send: ' . $this->redact($e->getMessage()),
            ];
        }
    }

    /**
     * Send this order's invoice to the customer, on purpose, from the admin.
     *
     * The second method in this class that REPORTS rather than swallows, and for
     * the same reason resendConfirmation() gives: the swallowing everywhere else
     * exists because a dead SMTP host must not take down a checkout whose payment
     * is already taken, and nothing is waiting on the answer. Here a person
     * pressed "Email invoice" and is owed the truth. A button that says "Sent"
     * whatever happened is worse than one that refuses.
     *
     * THE NUMBER IS ALLOCATED BEFORE THE SEND, NOT AFTER. An invoice with no
     * number on it is not an invoice, and a customer who receives one and then
     * receives a second copy carrying a number has been sent two documents for
     * one debt. Allocation is idempotent and race-safe (see InvoiceNumbers), so
     * emailing an order that has already been printed re-sends THAT invoice
     * rather than minting a new one — the emailed document and the printed one
     * are the same document, by number and by figure.
     *
     * If the send fails the number is NOT rolled back, deliberately. It has been
     * issued; it belongs to this order now. Releasing it would mean the next
     * order could be given a number that a half-delivered email may already be
     * carrying, which is the one thing an invoice sequence may never do.
     *
     * NO MODULE SWITCH IS CONSULTED, and that is a decision rather than an
     * oversight. The five keys above guard emails the store sends BY ITSELF, and
     * a toggle exists so the owner can stop them happening without being asked.
     * This one only ever happens because the owner asked for it, one order at a
     * time, from a screen they are looking at. A switch whose only effect is to
     * make a button the owner just pressed refuse is not a setting, it is a
     * trap. (ModuleRegistry belongs to another lane; adding a row there is the
     * integrator's call if the owner ever wants one.)
     *
     * @return array{ok: bool, message: string, invoice_number?: int}
     */
    public function emailInvoice(Order $order): array
    {
        /*
         * BEFORE the invoice number is allocated, which is the whole of why
         * this is the first line. allocate() MINTS a number out of the sequence
         * an accountant reconciles, and it is idempotent, so a sample order
         * that reached it would keep that number for good — a gap in the books
         * with nothing behind it. InvoiceController::invoice() refuses in the
         * same way and says so at more length.
         */
        if ($this->isSample($order)) {
            return $this->sampleRefusal();
        }

        $to = trim((string) $order->email);

        if ($to === '') {
            return ['ok' => false, 'message' => 'This order has no email address on it.'];
        }

        try {
            $number = app(\App\Services\Invoices\InvoiceNumbers::class)->allocate($order);
        } catch (\Throwable $e) {
            Log::error('invoice number allocation failed', [
                'order' => $order->order_number,
                'exception' => class_basename($e),
                'message' => $this->redact($e->getMessage()),
            ]);

            return [
                'ok' => false,
                'message' => 'Could not allocate an invoice number for this order: ' . $this->redact($e->getMessage()),
            ];
        }

        try {
            // Re-read before rendering: under contention the number written may
            // be another request's, and the document must print what the
            // database holds rather than what this process hoped to write.
            $order->refresh();
            $order->loadMissing('items');

            // Same again, and the invoice is the document most likely to be
            // regenerated long after the order — see inLocale().
            $this->inLocale($order, true, static function () use ($to, $order): void {
                Mail::mailer(MailConfigurator::MAILER)
                    ->to($to)
                    ->send(new \App\Mail\OrderInvoice($order));
            });

            return [
                'ok' => true,
                'message' => 'Invoice ' . \App\Services\Invoices\InvoiceNumbers::format($number)
                    . ' sent to ' . $to . '.',
                'invoice_number' => $number,
            ];
        } catch (\Throwable $e) {
            Log::error('email invoice failed', [
                'order' => $order->order_number,
                'invoice_number' => $number,
                'exception' => class_basename($e),
                'message' => $this->redact($e->getMessage()),
            ]);

            return [
                'ok' => false,
                // The driver's own words, redacted of the SMTP password, because
                // "it failed" sends the owner to a log file they cannot read on
                // modest hosting.
                'message' => 'Could not send: ' . $this->redact($e->getMessage()),
                'invoice_number' => $number,
            ];
        }
    }

    /**
     * The order's status column changed to something the customer is owed a
     * message about.
     *
     * OrderStatusChanged::WORDING is the closed list, and it explains which
     * statuses are deliberately silent. Anything not on it returns here without
     * sending, rather than inventing wording for a status nobody designed.
     */
    public function statusChanged(Order $order, string $status): void
    {
        if ($this->isSample($order)) {
            return;
        }

        if (! OrderStatusChanged::handles($status)) {
            return;
        }

        /*
         * THE ONE GATE, AND THE ONE PLACE IT MAY LIVE.
         *
         * `orders.status` is written from five places, and one of them —
         * OrdersApiController::bulkStatus — is a query-builder `update()` that
         * fires no model events at all. That is how bulk status changes once
         * emailed nobody in this store: marking one order shipped from the
         * detail screen sent an email, marking forty from the list sent none,
         * with no error and no difference on screen. A per-status switch
         * implemented in the order-detail controller would have exactly that
         * hole, and it would be invisible in exactly the same way.
         *
         * So it is asked HERE, in the method both the observer and the bulk
         * path already call, and every writer is governed by it whether or not
         * it knows OrderStatusMailPolicy exists.
         *
         * The policy folds together the standing per-status rule (the module
         * switches read literally below, which is what Phase3ModuleSwitchesTest
         * greps for) and the operator's decision about THIS order, if they took
         * one on the screen they were looking at.
         */
        if (! $this->statusPolicy()->shouldNotify($order, $status)) {
            return;
        }

        /*
         * THE SHOP APP'S PUSH (Lane PN), behind the SAME gate as the email: an
         * operator who unticks "notify the customer", or an import that is
         * silent, silences both. Queued here, sent after the response; it can
         * neither fail nor delay the email below.
         */
        try {
            app(\App\Services\Push\PushAutomations::class)->orderStatus($order, $status);
        } catch (\Throwable) {
        }

        /*
         * ONE REFUND, ONE EMAIL (Lane RL). A refund made through the payment
         * screen settles a `refunds` row — which sends OrderRefunded, the money
         * email — and then PaymentRefunder moves the order to `refunded`, which
         * arrives here. The status email is for the other case: an order marked
         * Refunded by hand because the money went back some other way. If this
         * shop has a refund on record for the order, the money email has said
         * it already.
         */
        if ($status === 'refunded') {
            try {
                if (app(\App\Services\Payments\PaymentRefunder::class)->refundedFils($order) > 0) {
                    return;
                }
            } catch (\Throwable) {
                return;
            }
        }

        $order->loadMissing('items');

        $sent = $this->send(
            static fn () => new OrderStatusChanged($order, $status),
            (string) $order->email,
            $order,
            'status_' . $status,
        );

        /*
         * WHEN THE DELIVERED EMAIL ACTUALLY WENT (Lane RL) — the feedback
         * request's clock starts here, and only here: an unticked box or a
         * switched-off status returned above, and a send that failed returns
         * false, so neither starts it. The first one counts; a second
         * Completed later does not restart it.
         */
        if ($sent && $status === 'completed') {
            app(OrderEmailLog::class)->claim($order, 'status_completed');
        }
    }

    /**
     * "How is your glow?" — the feedback request (Lane RL). OrderReminders
     * decides it is due and claims it; this only sends. One row per product
     * still on sale, each linking to that product's reviews.
     */
    public function feedback(Order $order): bool
    {
        if ($this->isSample($order)) {
            return false;
        }

        $order->loadMissing('items.product');

        // Nothing still on sale to review: nothing to ask.
        if (! $order->items->contains(fn ($i) => $i->product !== null && (string) $i->product->status === 'publish')) {
            return false;
        }

        return $this->send(
            static fn () => new \App\Mail\OrderFeedbackRequest($order),
            (string) $order->email,
            $order,
            'feedback',
        );
    }

    /**
     * "What did you think?" — the review request, N days after the order was
     * completed (Lane RV). App\Services\Reviews\ReviewRequests decides it is
     * due, claims it and chooses the products; this only sends, through the
     * one choke point every order email takes (the order's language, the
     * sample-order refusal, the delivery record as `order.review_request`).
     *
     * @param  callable(): \Illuminate\Mail\Mailable  $build
     */
    public function reviewRequest(Order $order, callable $build): bool
    {
        if ($this->isSample($order)) {
            return false;
        }

        return $this->send($build, (string) $order->email, $order, 'review_request');
    }

    /**
     * Money has actually gone back.
     *
     * Driven by the refunds row settling, never by orders.status — see
     * App\Mail\OrderRefunded for why those are not the same event.
     */
    public function refunded(Order $order, Refund $refund): void
    {
        if ($this->isSample($order)) {
            return;
        }

        if (! $this->refundEnabled()) {
            return;
        }

        $order->loadMissing('items');

        $this->send(static fn () => new OrderRefunded($order, $refund), (string) $order->email, $order, 'refund');
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    /**
     * The store's own notification address.
     *
     * A dedicated setting first (Store → Mail), falling back to the From address.
     * Both are trimmed and checked for an @ before use: a half-filled form must
     * produce a skipped send and a log line, never a transport exception on the
     * checkout path.
     */
    public function merchantAddress(): string
    {
        $configured = trim((string) $this->mail->get('mail_merchant_address'));

        if ($configured === '') {
            $configured = trim((string) $this->mail->get(self::MERCHANT_FALLBACK_KEY));
        }

        return $configured;
    }

    /**
     * One send, and the only place a mail exception may be swallowed.
     *
     * THE MAILABLE IS BUILT INSIDE THE TRY, which is why this takes a factory
     * rather than a Mailable. Constructing one runs OrderEmailPresenter over the
     * order — relations, casts, money formatting — and none of that is
     * guaranteed not to throw on a half-imported order with a null address or a
     * line whose product vanished. A receipt that cannot be built must cost the
     * checkout exactly as little as a receipt that cannot be delivered: nothing.
     *
     * Mail::mailer() names the store's own mailer explicitly rather than relying
     * on the default, so this keeps working if MAIL_MAILER is ever set in the
     * environment for some other purpose. MailServiceProvider fills that mailer
     * in from the database on first resolution of the mail manager.
     *
     * The log line carries the order number, the kind of email and the exception
     * class and message. It does NOT carry the body, the recipient's other
     * details, or anything from the mail configuration: MailTester's redact()
     * exists because Symfony transport exceptions quote the DSN, password
     * included, and a log written on every checkout is the last place for that.
     * Only the transport's message is recorded, with the configured password
     * stripped out of it the same way.
     */
    /**
     * Run one send in the language the order was placed in — Lane FB.
     *
     * ── WHY THIS WRAPS THE BUILD AND NOT JUST THE RENDER ────────────────────
     *
     * Laravel offers $mailable->locale(), and it is not enough here. OrderMail's
     * CONSTRUCTOR runs App\Services\Mail\OrderEmailPresenter over the order and
     * keeps the finished strings — every totals row label, and in
     * OrderStatusChanged the whole cancellation money sentence. Those are
     * decided before a Mailable has a locale to set, so $mailable->locale()
     * would translate the view and leave the presented array in whatever
     * language the PROCESS happened to be in. The factory is therefore called
     * inside the wrapper, which is also why send() takes a factory rather than a
     * Mailable.
     *
     * ── WHY THIS MATTERS MORE THAN IT LOOKS ─────────────────────────────────
     *
     * The confirmation is sent in the request that placed the order, so it was
     * in the right language by accident. NOTHING AFTERWARDS IS: the dispatch
     * email, the cancellation, the refund notice and the invoice are sent from
     * an admin click or a queue worker weeks later, in a process whose locale is
     * whatever it was last set to. Before this, an Arabic shopper got an Arabic
     * checkout and English paperwork forever — App\Support\OrderLocale was
     * written for exactly this and had no caller outside its own tests.
     *
     * OrderLocale::render() puts the previous locale back in a `finally`, so one
     * Arabic order cannot leave a queue worker set to Arabic for every job
     * behind it.
     */

    /**
     * A sample order never mails anybody. The refusal, in one place, asked by
     * every entry point in this class.
     *
     * ── WHY IT IS HERE AND NOT ONLY IN send() ───────────────────────────────
     *
     * send() is the choke point for three of the five, and putting the whole
     * guarantee there would miss the two that matter MOST. resendConfirmation()
     * and emailInvoice() build and send their own message directly, because
     * they REPORT a failure to the operator instead of swallowing it — and they
     * are the two that exist as BUTTONS on the order detail screen. An owner
     * looking at a sample order to check that its invoice renders is one click
     * away from both of them, which is precisely the accident this feature must
     * not make possible. So the question is asked at every entry, and send()
     * asks it again on the way past.
     *
     * ── WHY IT READS `origin` AND NOT `demo_seed_log` ───────────────────────
     *
     * Two reasons, and the second is the real one.
     *
     * It costs nothing: `origin` is a column on the model already in hand, so
     * this adds no query to a checkout that is already the slowest request in
     * the shop, on a code path taken by every real order.
     *
     * And it cannot go missing underneath the guarantee. A log row can be
     * deleted on its own — DemoContentController::removeType() deletes log rows
     * by type, and a half-finished removal is a state that has existed here
     * before. An order whose log row has gone is an order this class would
     * read as real and MAIL. `origin` lives on the order row itself: it goes
     * when the order goes. App\Services\Orders\SampleOrder's header sets out
     * the same argument from the other side — the money question reads the log,
     * because for a FIGURE the safe error is to count a row you can see.
     *
     * The address on a sample order is in `.invalid`, which RFC 2606 reserves
     * as permanently unresolvable, so a message that got past this could still
     * reach nobody. That is the third layer and not the guarantee; this is.
     */
    private function isSample(Order $order): bool
    {
        return \App\Services\Orders\SampleOrder::is($order);
    }

    private function sampleRefusal(): array
    {
        return [
            'ok' => false,
            'message' => 'This is a sample order. Sample orders never send email to anybody — '
                . 'remove it from Safety → Demo Content → Sample order when you are done with it.',
        ];
    }

    private function inLocale(Order $order, bool $enabled, \Closure $run): void
    {
        if (! $enabled) {
            $run();

            return;
        }

        try {
            \App\Support\OrderLocale::render($order, $run);
        } catch (\Illuminate\View\ViewException $e) {
            /*
             * AN ARABIC RENDER THAT FAILS STILL DELIVERS — Lane AEM. The owner:
             * "a rendering failure in Arabic must never stop a mail from going
             * out". A ViewException is thrown while the BODY is being drawn,
             * before anything reaches the transport, so nothing has been sent
             * and sending once in English cannot be a duplicate. Only for an
             * order in another language: an English render that fails has no
             * other language to fall back to, and rethrows exactly as before.
             * A transport failure is not a ViewException and is never retried.
             */
            $locale = (string) ($order->locale ?? \App\Support\Locale::DEFAULT);

            if ($locale === \App\Support\Locale::DEFAULT) {
                throw $e;
            }

            Log::error('order mail: the ' . $locale . ' render failed; sent in English instead', [
                'order' => $order->order_number,
                'exception' => class_basename($e->getPrevious() ?? $e),
                'message' => $this->redact($e->getMessage()),
            ]);

            $previous = app()->getLocale();
            app()->setLocale(\App\Support\Locale::DEFAULT);

            try {
                $run();
            } finally {
                app()->setLocale($previous);
            }
        }
    }

    /** @return bool  true when the message was handed to the transport without an exception. */
    private function send(callable $build, string $to, Order $order, string $kind, bool $inOrderLocale = true): bool
    {
        if (self::$deferring) {
            self::$pending[] = fn () => $this->send($build, $to, $order, $kind, $inOrderLocale);

            return true;
        }

        /*
         * Asked again here, although all three callers have asked already. This
         * is the backstop for the SIXTH send, written next month by somebody
         * who has not read this file: a new public method that goes through
         * send() is covered without being told to be.
         */
        if ($this->isSample($order)) {
            return false;
        }

        $to = trim($to);

        if ($to === '' || ! str_contains($to, '@')) {
            Log::warning('order mail skipped: no recipient', [
                'order' => $order->order_number,
                'kind' => $kind,
            ]);

            return false;
        }

        try {
            $this->inLocale($order, $inOrderLocale, function () use ($build, $to, $kind): void {
                $mailable = $build();

                /*
                 * Name the message before it goes, so the delivery record says
                 * "order.confirmation" rather than "unknown". The mail events
                 * MailLog listens on cannot work this out for themselves: by the
                 * time Symfony has a Message the only thing left that identifies
                 * the feature is the subject line, and subject lines here are
                 * owner-editable wording.
                 */
                $this->log()?->labelNext('order.' . $kind);

                Mail::mailer(MailConfigurator::MAILER)->to($to)->send($mailable);
            });

            return true;
        } catch (\Throwable $e) {
            /*
             * Recorded where the owner can see it, as well as in the log he
             * cannot. This is the line that turns "the customer says they never
             * got it" from an unanswerable question into a row with the
             * transport's own words in it.
             *
             * Still swallowed. Everything this class's header says about a mail
             * failure never becoming an order failure is unchanged: the record
             * is a side effect of the failure, never a second thing that can
             * fail the checkout, and MailLog's own methods cannot throw.
             */
            $this->log()?->recordFailure($e);

            Log::error('order mail failed', [
                'order' => $order->order_number,
                'kind' => $kind,
                'exception' => class_basename($e),
                'message' => $this->redact($e->getMessage()),
            ]);

            return false;
        }
    }

    /**
     * The delivery record, or null if it cannot be built.
     *
     * Resolved on use rather than injected, and allowed to be absent. This
     * class is constructed on the checkout's own request; a container binding
     * that is missing -- an older package where this lane's provider changes
     * did not land -- must not be the reason an order cannot be placed.
     */
    private function log(): ?MailLog
    {
        try {
            return app(MailLog::class);
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * Keep the SMTP password out of the log.
     *
     * The same removal MailTester::redact() performs, for the same reason: an
     * AUTH failure can echo the credential back and a transport exception quotes
     * the DSN. Both the literal and the base64 form are stripped, because both
     * have been seen in a mailer exception message.
     */
    private function redact(string $message): string
    {
        /*
         * Itself guarded. This runs on the failure path, and the failure being
         * handled may well be "the mail_credentials table is not there" — a
         * redactor that throws while redacting would turn a logged mail failure
         * back into the 500 this whole class exists to prevent.
         */
        try {
            $password = $this->mail->password();
        } catch (\Throwable) {
            return trim($message);
        }

        if ($password !== '') {
            $message = str_replace(
                [$password, rawurlencode($password), base64_encode($password)],
                '[password redacted]',
                $message,
            );
        }

        return trim($message);
    }
}
