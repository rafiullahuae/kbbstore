{{--
    Checkout — matched field for field against the live page source.

    Differences that were found and corrected: Emirate is a text input (the
    select reloaded the page on change), Country is hidden, Phone is optional,
    the labels and placeholders are the live wording, and prices use the Arabic
    dirham symbol with no decimals.
--}}
@extends('layouts.store')
@php use App\Support\Money; use App\Support\Url; @endphp

@section('bare', '1')
@section('title', __('store.checkout.page_title'))
@section('kbb-wa-tab', '1')
@section('kbb-wa-page', 'checkout')

@push('styles')
    @vite('resources/css/kbb/kbb-checkout.css')
@endpush

@section('content')
@php
    /*
     * Appearance -> Checkout page. Resolved here rather than passed in, because
     * this template is reached from more than one place and a controller that
     * forgot the key would 500 the checkout rather than lose a slider.
     *
     * Both calls emit NOTHING while every control is at its default, so the
     * rendered element is byte for byte `<section class="kbb-checkout">` on a
     * shop that has never opened the screen.
     */
    $kbbCoPage = app(\App\Services\CheckoutPage::class);
    // 2.60.495: the method the payment list will open checked (its own rule:
    // the asked-for one while offered, else the first), so the pay button's
    // first paint already says "Pay now" or "Complete Order".
    $kbbPayIds = array_column($gateways ?? [], 'id');
    $kbbPayFirst = in_array(old('payment_method'), $kbbPayIds, true) ? old('payment_method') : ($kbbPayIds[0] ?? null);
    // 2.60.495: Contact folded into Delivery Information -- the numbers move up one.
    $kbbOneStep = $kbbCoPage->lo('one_step');
    // The pay button's two sets of words, for the layout script (null = "Place order" as before).
    $kbbLoWords = $kbbCoPage->lo('btn_words') ? ['pay' => $kbbCoPage->payButton('stripe'), 'cod' => $kbbCoPage->payButton('cod')] : null;
@endphp
{!! $kbbCoPage->fitStyle() !!}<section class="kbb-checkout{{ $kbbCoPage->bodyClass() }}"{!! $kbbCoPage->styleAttr() !!}>{{-- Lane PO: the diagnostic panel, /checkout/?kbbdiag=1 only; an echo rather than @if, because @endif at a line's end eats its newline and every other checkout must render not one byte more. --}}{!! request()->query('kbbdiag') === '1' ? view('partials.checkout.diag')->render() : '' !!}

    <!-- slim secure-checkout header (design .head) -->
    <header class="co-head"><div class="in">
@if (app(\App\Services\HeaderSettings::class)->logoLockup())
        @include('partials.logo-lockup', ['href' => Url::to('/')])
@else
        <a class="logo" href="{{ Url::to('/') }}"><bdi>K-Beauty<span>Bliss</span></bdi></a>
@endif
@if ($kbbCoPage->lo('head_cart'))
        {{-- 2.60.495: "remove the right side secure checkout green text beside
             the logo, and place there cart icon, which will go to the cart
             page". The shop's own bag icon, with its size written on the svg
             (the header rule: every inline svg here carries width/height). --}}
        <a class="co-cart" href="{{ Url::to('/cart/') }}" aria-label="{{ __('store.checkout.cart_icon_label') }}">{!! str_replace('<svg ', '<svg width="24" height="24" ', \App\Support\HeaderIcons::cart()) !!}</a>
@else
        <span class="secure">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>
            {{ __('store.checkout.secure_badge') }}        </span>
@endif
    </div></header>

    {{-- ONLY WHEN THERE IS SOMETHING TO SAY.
         This band rendered on every load, errors or not, and its 16px of top
         padding sat between the header and the page as permanently empty space
         -- half of the "empty spaces on top and bottom" the owner reported,
         and the half no slider could reach, because an empty div is not a
         margin anybody thinks to look at. With it gone, the gap under the
         header is Page padding - top on the Layout tab, which is a control. --}}
    @if ($errors->any())
    <div class="co-notices" style="max-width:1040px;margin:0 auto;padding:16px 20px 0">
        <div class="co-note err">{{ $errors->first() }}</div>
    </div>
    @elseif (\App\Services\Checkout\UnfinishedPayment::noticeFor(request()) !== '')
    {{-- (Lane BK) The basket an unfinished payment held, given back on this very request: the Back button from Tabby or Tamara lands here. Same band, same geometry. --}}
    <div class="co-notices" style="max-width:1040px;margin:0 auto;padding:16px 20px 0">
        <div class="co-note ok" role="status">{{ \App\Services\Checkout\UnfinishedPayment::noticeFor(request()) === 'merged' ? __('store.checkout.return_merged') : __('store.checkout.return_restored') }}</div>
    </div>
    @endif
{{-- ONE JAR, CLAIMED TWICE (Lane SEC). Rendered only when a set in this basket
     has taken the last of something the shopper also added loose:
     App\Services\SetStockReconciler removed the loose line before the totals
     below were computed, so this is what says why the figures moved. Same band
     and the same inline geometry as the error notice above it, so nothing new
     is introduced to this page's layout.

     ZERO BYTES WHEN THERE IS NOTHING TO SAY: the block starts at COLUMN 0, the
     comment's closer touches the conditional, and PHP swallows the newline
     after the conditional's compiled closing tag. Indented and on its own line
     it added a blank line to every checkout in the shop, which is how
     StorefrontEnglishUnchangedTest found it. --}}@if ((($setStockNotices ?? [])) !== [])<div class="co-notices" style="max-width:1040px;margin:0 auto;padding:16px 20px 0">@include('partials.set-stock-notice')</div>@endif

    <form name="checkout" method="post" class="checkout woocommerce-checkout" action="{{ Url::to('/checkout/place') }}" enctype="multipart/form-data" id="kbbCheckoutForm">
        @csrf
        <div class="co-grid">
{{-- Lane QK6: Appearance -> Checkout page -> Coupon line, ON as the owner
     asked. Column 0 and glued to the conditional, so a checkout with no line
     to draw renders not one byte more. --}}@if (($kbbClCode = $kbbCoPage->couponLineCode()) !== null)@include('partials.checkout.coupon-top')@endif

{{-- 2.60.495: "remove the checkout page title and description completely" --
     13 October layout -> "Show the Checkout title", OFF as asked. The row is
     still drawn for the two back links if either is switched on. --}}@if ($kbbCoPage->lo('title') || $kbbCoPage->showShopLink() || $kbbCoPage->showCartLink())
            <div class="co-titlebar">
                <div class="co-titlebar-main">
{{-- Lane QK6: "turn off the back to shop link and back to cart button on
     checkout completely!" Appearance -> Checkout page -> Back to shop & cart,
     both OFF as asked. Directives at column 0, so OFF leaves no line and ON is
     byte for byte what was here. --}}@if ($kbbCoPage->showShopLink())
                    <a class="backlink" href="{{ Url::to('/shop/') }}">{{ __('store.checkout.back_to_shop') }}</a>
@endif
@if ($kbbCoPage->lo('title'))
@if ($kbbCoPage->showHeadBack())
                    <a class="co-back" href="{{ Url::to('/cart/') }}" aria-label="{{ __('store.checkout.head_back') }}" title="{{ __('store.checkout.head_back') }}"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>
@endif
                    <h1 class="co-h">{{ __('store.checkout.heading') }}</h1>
                    <p class="co-lead">{{ __('store.checkout.lead') }}</p>
@endif
                </div>
@if ($kbbCoPage->showCartLink())
                @include('partials.checkout.back-to-cart')
@endif
            </div>
@endif

            <!-- LEFT -->
            <div>
@if (! $kbbCoPage->lo('coupon_in'))
                @include('partials.checkout.coupon-box')
@endif
{{--
     APPLE PAY AND GOOGLE PAY, under the coupon box (Lane CO). Stripe's Express
     Checkout Element, drawn by the partial and revealed only once Stripe says
     this browser has a wallet: no wallet, no row, no heading, no OR line and
     no gap. It is still inside #kbbCheckoutForm, and the script finds the form
     by id, so the fields it checks, the amount it opens the sheet with and the
     order it places are exactly what they were when it sat under "4 Payment".
     Glued to the </div>, so a shop with no wallet renders not one byte more.
--}}@include('partials.checkout.express-wallets')


                <div class="formbox" id="customer_details">

{{-- 2.60.495, "the contact section i want to remove ... the email will go
     above the name field, the sign in row will be in the heading row, rename
     to Delivery Information ... bring the create account line here": 13
     October layout -> "Email inside Delivery Information", ON as asked. The
     fields MOVE; their names, ids and order of validation are unchanged, so
     what is posted is exactly what it was. Off draws Contact as before. --}}@if (! $kbbOneStep)
                    <!-- 1 · Contact -->
                    <div class="sec">
                        <h2><span class="n">1</span> {{ __('store.checkout.step_contact') }}@include('partials.checkout.step-signin')
</h2>
@include('partials.checkout.contact-email')

                            @include('partials.checkout.contact-account')
                    </div>
@endif

                    <!-- 2 · Shipping address -->
                    <div class="sec{{ $kbbOneStep ? ' co-onestep' : '' }}">
@if ($kbbOneStep)
                        <h2><span class="n">1</span> <span class="co-h2t">{{ __('store.checkout.step_delivery_info') }}</span>@include('partials.checkout.step-signin', ['stack' => true])
</h2>
@include('partials.checkout.contact-email', ['hint' => true])
@else
                        <h2><span class="n">2</span> {{ __('store.checkout.step_shipping') }}</h2>
@endif
{{-- NAME FIRST, then PHONE, at the top of Shipping Details (Lane QK6), above
     the address. A MOVE, NOT A REWRITE: both shapes of the name field, their
     validation priorities and their autocomplete tokens are unchanged, and
     `billing_first_name` is still what the form posts. --}}@if ($singleName ?? true)
{{-- autocomplete="name", not "given-name". This one box holds the
                                 whole name -- splitName() in the controller cuts it up -- and a
                                 browser told "given-name" fills it with the first name alone,
                                 leaving the surname to be typed by hand on a phone. --}}
                            <x-checkout.field name="billing_first_name" :label="__('store.checkout.field_full_name')" required icon="user"
                                validate="validate-required" priority="10"
                                :placeholder="__('store.checkout.field_full_name_placeholder')"
                                autocomplete="section-billing billing name"
                                :value="old('billing_first_name', $prefill['name'] ?? '')" />
@else
                            {{-- Store → Ecommerce → Checkout → Form fields, off. The single field
                                 above is still what the backend sees when this is on — splitName()
                                 in the controller has accepted this shape all along; only the form
                                 itself never offered it. --}}
                            <div class="row2">
                                <x-checkout.field name="billing_first_name" :label="__('store.checkout.field_first_name')" required icon="user"
                                    rowClass="form-row-first" validate="validate-required" priority="10"
                                    autocomplete="section-billing billing given-name"
                                    :value="old('billing_first_name', $prefill['first_name'] ?? '')" />

                                <x-checkout.field name="billing_last_name" :label="__('store.checkout.field_last_name')" required icon="user"
                                    rowClass="form-row-last" validate="validate-required" priority="20"
                                    autocomplete="section-billing billing family-name"
                                    :value="old('billing_last_name', $prefill['last_name'] ?? '')" />
                            </div>
@endif
                            <x-checkout.field name="billing_phone" :label="__('store.checkout.field_phone')" type="tel" required icon="phone"
                                validate="validate-required validate-phone" priority="100"
                                :placeholder="__('store.checkout.field_phone_placeholder')" inputmode="tel"
                                autocomplete="section-billing billing tel"
                                :value="old('billing_phone', $prefill['phone'] ?? '')" />
{{-- The picker row, or the four typed fields it replaced. Appearance ->
     Checkout page -> Fields & attention -> "Address picker row on cart and
     checkout", OFF as the owner asked (Lane CK). Directives at column 0, so
     the ON branch renders the bytes it rendered before the switch existed;
     the comment ends on the @if's own line so it leaves no newline. --}}@if ($kbbCoPage->addressPickerRow())
@include('partials.checkout-address')
@else
@include('partials.checkout.address-fields')
@endif
@if ($kbbOneStep)
                            @include('partials.checkout.contact-account')
@endif
{{-- Lane PO: "Remember my details on this device". Nothing at all while
     Appearance -> Checkout page -> Fields & attention -> "Remember shopper
     details on this device" is off. --}}@if ($kbbCoPage->get('remember_on'))
@include('partials.checkout.remember-row')
@endif
                    </div>

                    <!-- 3 · Delivery -->
                    <div class="sec">
                        <h2><span class="n">{{ $kbbOneStep ? 2 : 3 }}</span> {{ __('store.checkout.step_delivery') }}@if ($kbbCoPage->get('dl_note_on') && is_string($kbbDn = $kbbCoPage->deliveryNoteHtml($defaultCountry ?? null, $totals['free_shipping_threshold'] ?? null)))<span class="co-dnote" id="kbbDeliveryNote"{!! ($kbbDn === '' || ($kbbCoPage->lo('dl_note_free') && (int) ($totals['shipping'] ?? 1) <= 0)) ? ' hidden' : '' !!}>{!! $kbbDn !!}</span>@endif</h2>
                        @if (!empty($unservedCountry))
                            <p class="xd-unserved">{{ __('store.checkout.unserved_country', ['country' => \App\Support\Countries::NAMES[$unservedCountry] ?? $unservedCountry]) }}</p>
                        @endif
                        <div id="kbbDeliverySlot" class="kbb-delivery">
                            @include('partials.checkout.delivery-options', ['deliveryCountry' => $defaultCountry ?? null])
                        </div>
                            @if ($kbbCoPage->get('notes_on'))
                            {{-- Not rendered rather than hidden, so nothing posts
                                 customer_note while it is off. place() has always
                                 treated it as nullable, so this needs no branch there. --}}
                            <x-checkout.field name="customer_note" :label="__('store.checkout.field_notes')" type="textarea" optional icon="note"
                                rowClass="form-row-wide kbb-note" rows="2" maxlength="600"
                                :placeholder="__('store.checkout.field_notes_placeholder')"
                                :value="old('customer_note')" />
                            @endif
                            @if (app(\App\Services\SettingsService::class)->get('gift_enabled', '1'))
                            <p class="form-row form-row-wide kbb-gift" id="gift_field">
                                @php
                                    $giftOn = app(\App\Services\SettingsService::class)->get('gift_enabled', '1');
                                    $giftFee = (int) app(\App\Services\SettingsService::class)->get('gift_fee', '1500');
                                @endphp
                                <label class="kbb-gift-opt" for="is_gift">
                                    <input type="checkbox" name="is_gift" id="is_gift" value="1" @checked(old('is_gift', session('kbb_gift')))>
                                    <span>{{ __('store.checkout.gift_option') }}</span>
                                    @if ($giftFee > 0)
                                        <b class="kbb-gift-fee">+{!! \App\Support\Money::format($giftFee) !!}</b>
                                    @endif
                                </label>
@if ($kbbCoPage->floatLabels())
                                <span class="woocommerce-input-wrapper kbb-gift-msg" id="gift_note_wrap" hidden>
                                    <span class="fld kbb-fl ico"><span class="lead" aria-hidden="true">@include('partials.icon-gift')</span><textarea name="gift_note" id="gift_note" class="input-text" rows="3" maxlength="600"
                                              placeholder=" ">{{ old('gift_note') }}</textarea><label for="gift_note">{{ __('store.checkout.gift_note_placeholder') }}</label></span>
@else
                                <span class="woocommerce-input-wrapper kbb-gift-msg" id="gift_note_wrap" hidden>
                                    <textarea name="gift_note" id="gift_note" class="input-text" rows="3" maxlength="600"
                                              placeholder="{{ __('store.checkout.gift_note_placeholder') }}">{{ old('gift_note') }}</textarea>
@endif
                                    <span class="kbb-gift-count">{!! trans_choice('store.checkout.gift_characters_left', 600, ['remaining' => '<span id="gift_left">600</span>']) !!}</span>
                                </span>
                            </p>
                            @endif
                    </div>

                    <!-- 4 · Payment -->
                    <div class="sec pay">
                        <h2><span class="n">{{ $kbbOneStep ? 3 : 4 }}</span>@if (($kbbPaySecure = $kbbCoPage->paySecureLine()) !== '') <span class="co-h2t">{{ __('store.checkout.step_payment') }}<small class="co-psec"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>{{ $kbbPaySecure }}</small></span>@else {{ __('store.checkout.step_payment') }}@endif</h2>

                        {{-- Apple Pay and Google Pay moved up, under the coupon box (Lane CO). --}}
                        {{-- The list itself lives in its own partial: adding a
                             product from Browsed can move the order total
                             across the Cash-on-delivery window, and the refresh
                             has to render THIS markup rather than a second copy
                             of it. old('payment_method') is honoured for the
                             same reason it is on every other field here — a
                             rejected Place order should not silently reset the
                             choice. --}}
                        <div id="payment" class="woocommerce-checkout-payment">@include('partials.checkout.payment-methods', ['selectedMethod' => old('payment_method')])</div>
                    </div>

                    {{-- Lane QK9: the reviews & authenticity card, OFF as the owner asked (Appearance -> Checkout page -> Trust & reviews -> first switch). --}}@if ($kbbCoPage->get('trust_card'))@include('partials.checkout.reassurance')@endif                </div>
            </div>

            <!-- RIGHT summary -->
            <aside class="summary{{ $kbbCoPage->get('sum_row') ? ' cosr-on' : '' }}" id="kbbSummary">
{{-- The one-row summary (Lane CK): Appearance -> Checkout page -> Fields &
     attention -> "Order summary: collapsed to one row", ON as asked. Column 0
     and one line, so OFF adds not a byte. --}}@if ($kbbCoPage->get('sum_row'))@include('partials.checkout.summary-row')@endif
                @if ($showBrowsed)
                <div class="sumtabs" role="tablist">
                    <button type="button" class="stab on" data-stab="summary">{{ __('store.checkout.tab_summary') }}</button>
                    <button type="button" class="stab" data-stab="browsed">{{ __('store.checkout.tab_browsed') }} <span class="bcount">{{ $browsed->count() }}</span></button>
                </div>
                @endif

                <div class="panels" id="kbbPanels">
                    <!-- Order summary panel -->
                    <div class="spanel on" data-spanel="summary">
                        <div class="co-items">
                            @include('partials.checkout.summary-items')                        </div>
{{-- 2.60.495: the coupon field inside the order summary, under the items, as
     asked -- the same partial, so the same ids, here instead of above the form.
     Outside .co-items, which checkout.js re-renders on a quantity change. --}}@if ($kbbCoPage->lo('coupon_in'))<div class="co-sumcoupon">@include('partials.checkout.coupon-box')</div>@endif

                        {{-- A stable container round the order block, for the
                             same reason .kbb-freeship-slot inside it has one:
                             the block is rendered twice (here and in the mobile
                             box), so it cannot carry an id, and the one-tap add
                             swaps every copy of it in one go. --}}
                        <div class="kbb-order-slot">@include('partials.checkout.order-block', ['withActions' => true])</div>                    </div>

                    @if ($showBrowsed)
                    <!-- Browsed panel -->
                    <div class="spanel" data-spanel="browsed">
                        {{-- The "Added" confirmation is pinned to this heading,
                             not to the row: a successful add replaces the list
                             below, which would take a note living on the row
                             with it. It is absolutely positioned so appearing
                             costs no height — nothing on the page moves. --}}
                        <p class="bhead">{{ __('store.checkout.browsed_heading') }}<span class="baddnote" id="kbbBrowsedNote" role="status" aria-live="polite"></span></p>
                        <div id="kbbBrowsedList" data-add-url="{{ Url::to('/checkout/browsed-add') }}">@include('partials.checkout.browsed-list')</div>
                    </div>
                    @endif

                    <div class="peekfade"></div>
                </div>

                <!-- mobile: expand/collapse the summary -->
                <button type="button" class="viewfull" id="kbbViewItems" aria-controls="kbbPanels" aria-expanded="false">{{ __('store.checkout.view_summary_open') }}</button>
            </aside>

        </div>

        <!-- mobile-only: full on-page Place order box (sticky bar is optional) -->
        {{-- The mobile bag strip — "Your bag · N items", the round thumbnails
             with their ×n badges — and, immediately under it, the order block
             whose first element is the free-delivery progress bar. Both are in
             their own slots: a one-tap add from Browsed has to bring a new
             thumbnail, a new count and a moved progress bar with it, and a bar
             still reading 80% while the summary says "Free" is worse than one
             that never moved at all. --}}
        <div class="kbb-mobile-order">
            <div class="kbb-thumbs-slot">@include('partials.checkout.thumbs')</div>{{--
     2.60.495: the box at the foot of the page folds to Total only (13 October
     layout -> "Box at the foot of the page"); the arrow beside the total opens
     this: the heading, a copy of the summary's lines and the coupon field,
     MOVED here from the top summary (never copied: checkout.js finds it by
     id). It sits OUTSIDE .kbb-order-slot on purpose -- checkout.js replaces
     that slot's contents on every coupon and quantity answer, and a coupon
     field inside it would be thrown away by its own Apply. --}}@if ($kbbCoPage->lo('total_only'))<div class="co-osbox"><button type="button" class="co-osh" aria-expanded="true"><span>{{ __('store.checkout.tab_summary') }}</span><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></button><div class="co-ositems"></div><div class="co-oscoupon"></div></div>@endif<div class="kbb-order-slot">@include('partials.checkout.order-block', ['withActions' => true])</div>        </div>
    </form>
{{-- Lane CO: the "Sign in" window, OUTSIDE the checkout form (a form inside a form is not a form). Guests only, and only while the link above is drawn. --}}@if ($kbbCoPage->signInLink() && ! auth('customer')->check())
@include('partials.checkout.sign-in')
@endif

    @php $kbbFloat = $kbbCoPage->floatBar(); @endphp
    @if ($kbbFloat !== 'off')
    {{-- The phone-only Place order bar. Appearance -> Checkout page -> Mobile
         chooses between never, "only once the in-page button scrolls away"
         (the default) and always; floatBar() resolves that against the older
         `mobile_sticky_bar` switch under Store -> Ecommerce, so a shop that
         asked for an always-there bar before this control existed keeps one.

         `hidden` is NOT used and must not be: the bar has to be in the layout
         for its transform to animate, and an element that is `hidden` cannot
         transition into view. The resting state is CSS -- see .mpbar in
         kbb-checkout.css -- so a page whose script never runs shows no bar
         rather than one stuck across the bottom. --}}
    <div class="mpbar">
        <div><div class="ml">{{ __('store.checkout.total') }}</div><div class="mt js-total">{!! Money::format($totals['total']) !!}</div></div>
        <button type="button" class="mb" data-place="1" autocomplete="off">{{ $kbbCoPage->payButton($kbbPayFirst) ?? __('store.checkout.place_order') }}</button>
    </div>
    @if ($kbbFloat === 'smart')
    @push('scripts')
    <script>
    /*
     * The floating bar waits for the in-page Place order button to leave.
     *
     * IntersectionObserver AND NOT A SCROLL HANDLER. A scroll handler would
     * have to ask the button where it is on every frame, which is the
     * layout-measuring JavaScript this project does not write -- and it would
     * be wrong as well as expensive, because the button MOVES: choosing an
     * address, opening the gift box or applying a coupon all change the height
     * of the page above it, so a remembered position is stale the moment the
     * shopper does anything. The observer is told the element, not a number,
     * and the browser answers from layout it has already done.
     *
     * The target is the button inside .kbb-mobile-order, not `.place` -- there
     * are two of those, and the other one is in the desktop summary, which is
     * display:none on a phone. An observer on a display:none element never
     * reports as intersecting, so watching the wrong one would leave the bar
     * showing for the whole page.
     *
     * No threshold and no rootMargin: the owner asked for the bar to go "as
     * soon as the on page place order button appears", and the default
     * threshold of 0 is exactly that -- the first pixel in, or out.
     */
    (function () {
        var bar = document.querySelector('.kbb-checkout .mpbar');
        var target = document.querySelector('.kbb-checkout .kbb-mobile-order .place');
        var form = document.getElementById('kbbCheckoutForm');

        if (!bar || !target || !form || !('IntersectionObserver' in window)) { return; }

        var away = false;

        /*
         * IS THE ORDER ACTUALLY PLACEABLE?
         *
         * "with missing fields, or selection or missing payment selection, the
         * floating place order bar will not show." A bar offering Place order
         * on a form that cannot be placed is a button that exists to be
         * refused, and on a phone it covers the field that is actually wrong.
         *
         * `:invalid` IS THE SAME TEST THE BUTTON ITSELF USES -- see the
         * [data-place] handler in checkout.js, which scrolls to
         * form.querySelector(':invalid') before it will submit. Using the
         * browser's own constraint validation rather than a second list of
         * field names means the two cannot disagree about what "complete"
         * means, and it costs no layout: :invalid is a selector match, not a
         * measurement.
         *
         * BUT :invalid IS NOT ENOUGH ON ITS OWN, and this is the part worth
         * reading. The chosen address lands in HIDDEN inputs --
         * billing_address_1, billing_city, billing_state -- and a hidden input
         * is barred from constraint validation, so it is never :invalid however
         * empty it is. The three guards below are each written as "if this
         * control exists and is unanswered", so a shop with no delivery step,
         * or one whose payment section has not loaded yet, is not held back by
         * a question it never asked.
         */
        function placeable() {
            if (form.querySelector(':invalid')) { return false; }

            var address = form.querySelector('#billing_address_1');

            if (address && address.value.trim() === '') { return false; }

            var ship = form.querySelector('input[name="shipping_method"]');

            if (ship && !form.querySelector('input[name="shipping_method"]:checked')) { return false; }

            var pay = form.querySelector('input[name="payment_method"]');

            if (pay && !form.querySelector('input[name="payment_method"]:checked')) { return false; }

            return true;
        }

        function paint() {
            bar.classList.toggle('is-on', away && placeable());
        }

        /*
         * The target is the button inside .kbb-mobile-order, not `.place` --
         * there are two of those and the other is in the desktop summary, which
         * is display:none on a phone. An observer on a display:none element
         * never reports as intersecting, so watching the wrong one would leave
         * the bar showing for the whole page.
         *
         * No threshold and no rootMargin: "as soon as the on page place order
         * button appears" is the default threshold of 0 exactly -- the first
         * pixel in, or out.
         */
        new IntersectionObserver(function (entries) {
            away = !entries[entries.length - 1].isIntersecting;
            paint();
        }).observe(target);

        /*
         * THREE DELEGATED LISTENERS AND NO POLLING. `input` and `change` catch
         * typing and the radios; `click` is the one that catches what neither
         * does -- the address sheet writes the chosen address straight into
         * those hidden inputs, and setting an input's .value from script fires
         * no event at all. Each check is four selector matches and reads no
         * geometry, so paying it on a click costs nothing worth measuring.
         */
        document.addEventListener('input', paint);
        document.addEventListener('change', paint);
        document.addEventListener('click', function () { setTimeout(paint, 0); });
    })();
    </script>
    @endpush
    @endif
    @endif
{{-- THE SLIM FOOTER, if this shop draws one. It is NOT the site footer: the
     checkout declares `bare`, so that has never rendered here and still does
     not. See App\Services\SlimFooter for why a page asking for money gets a
     bar rather than four columns of ways to leave. --}}
@if (app(\App\Services\SlimFooter::class)->onCheckout())
@include('partials.slim-footer')
@endif
    </section>

{{--
    The card fields' script is appended to the SCRIPTS PUSH BELOW rather than
    given a push of its own, and where it sits on the line is load-bearing
    rather than tidy. Both reasons are about bytes, which
    StorefrontEnglishUnchangedTest compares: a shop with no card gateway
    configured must render a checkout identical to the one it had before this
    package, and "identical" is not a thing to be argued with afterwards.

    A @push block of its own adds two blank lines before </main>, because the
    directives emit nothing but the newlines around them are literal template
    text.

    And this @include goes on ITS OWN LINE, not appended to the one above.
    Blade's echo compiler pads `{!! … !!}` with a newline to keep line numbers,
    and PHP then eats the one after the closing `?>` — so the pair nets out to
    the single newline the source had. Butting a directive straight onto the
    end of that echo puts `<?php` where the padding would go, the padding is
    not emitted, and the line silently loses its newline. Measured, not
    assumed: it moved a byte on the rendered checkout and the walk caught it.

    The partial draws nothing at all unless Stripe is on offer with a
    publishable key, so such a shop also loads no Stripe script. The mount box
    it drives is partials/checkout/stripe-card, which the payment list renders
    inside the card option's own .payment_box.

    This comment's closing marker is glued to @push for the first reason above:
    Blade strips the comment and leaves the newline that followed it.
--}}@push('scripts')
@include('partials.checkout.address-autocomplete', ['autocomplete' => \App\Support\AddressAutocomplete::config(app(\App\Services\SettingsService::class))])@include('partials.checkout.inline-validation', ['validation' => \App\Support\InlineValidation::config(app(\App\Services\SettingsService::class))]){!! app(\App\Services\MarketingPixels::class)->beginCheckout((int) $totals['total']) !!}
@include('partials.checkout.stripe-elements')
{{-- THE PLACE-ORDER OVERLAY, AND IT GOES AFTER stripe-elements ON PURPOSE.

     Both register a capture-phase click listener on `document` for
     [data-place], and capture listeners on the same node run in the order they
     were added. stripe-elements claims the press and stops it ONLY when the
     card is the chosen method; everything else falls through to the overlay's
     own listener, which posts this form and reads place()'s JSON answer.

     Swap the two lines and the card would be placed twice: the overlay would
     post the form, get `action: confirm` back for a confirmation it cannot
     perform, and refuse — while stripe-elements never saw the click at all. --}}
@include('partials.checkout.placing-overlay')
@if ($kbbLoWords !== null || $kbbCoPage->lo('total_only') || $kbbCoPage->lo('coupon_in') || $kbbCoPage->lo('dl_note_free'))
@include('partials.checkout.layout-13')
@endif
@endpush

@push('scripts')
<style>
/* Scoped to .kbb-checkout and built from the sheet's own tokens, so these
   rows inherit the same palette as every other field.

   Checkbox metrics copied from .kbb-wa rather than guessed: 17px box,
   margin-top 1px, flex-shrink 0, align-items flex-start. That row already
   sits correctly against a label that wraps to two lines, so matching it
   keeps every tick on this page on the same optical line instead of each
   one being a slightly different hand-tuned number.

   None of these may go inside .row2 -- that is a two-column grid, and a
   .form-row dropped into it becomes a grid child and interleaves with Email
   and Phone. */
.kbb-checkout .kbb-acct,
.kbb-checkout .kbb-gift,
.kbb-checkout .kbb-note{margin-top:10px}
/* label.<class>, not just .<class>: the sheet's own
   `.kbb-checkout .form-row label{display:block}` scores 0,2,1 and beat a bare
   0,2,0 selector, so display:flex never applied and the box sat inline on the
   text baseline -- which is why align-items did nothing at all. */
.kbb-checkout .form-row label.kbb-acct-opt,
.kbb-checkout .form-row label.kbb-gift-opt{display:flex;align-items:center;gap:9px;cursor:pointer;
  font-size:12px;font-weight:500;color:var(--ink-2);margin:0;line-height:1.45}
/* HIDDEN MEANS HIDDEN, ON EVERY ELEMENT OF THIS PAGE.

   The browser's own sheet says [hidden]{display:none}, and ANY author rule that
   sets display beats it, whatever its specificity -- author origin outranks
   user-agent origin before specificity is even looked at. This page is full of
   such rules: `.kbb-checkout .sumrow{display:flex}` and
   `.kbb-checkout .kbb-delivery-line{display:flex}` in kbb-checkout.css, and
   `.kbb-acct-pw`/`.kbb-gift-msg` below. So `hidden` did nothing at all on any
   element carrying one of them.

   It was fixed here once, for `.sumrow` alone, after the Gift wrapping row was
   found showing "AED 0.00" to every shopper who had not ticked "this order is a
   gift". Then partials/checkout/delivery-line.blade.php was changed to render
   the delivery line and hide it -- rendered and hidden precisely so the
   country-change refresh in checkout.js can reveal it -- and it landed on the
   same rake: a shopper in a country with no recorded delivery window got the
   bordered row and the truck icon with no words in it. Measured in Chromium at
   1280 and 390 before and after; see CheckoutHiddenRowsTest.

   One rule instead of a list of them, because the next element rendered-and-
   hidden under .kbb-checkout would otherwise be the third instance of one bug.
   `!important` because this is not a style preference that a later rule may
   reasonably overrule: the attribute states that the element is not to be
   rendered, and no rule on this page has a legitimate reason to say otherwise.
   (It is also not a tie this file can win on source order alone -- this block is
   pushed into the scripts stack, and a rule of equal specificity landing after
   it would take the element back.)

   `hidden="until-found"` would need content-visibility rather than display and
   is not used anywhere in this application; if it ever is, this rule has to
   learn about it. */
.kbb-checkout [hidden]{display:none!important}
.kbb-checkout .kbb-acct-opt input[type="checkbox"],
.kbb-checkout .kbb-gift-opt input[type="checkbox"]{width:17px;height:17px;margin-top:1px;
  accent-color:var(--pink);flex-shrink:0;margin-top:0}
.kbb-checkout .kbb-gift-fee{margin-inline-start:7px;font-weight:700;color:var(--pink)}
.kbb-checkout .kbb-acct-pw,
.kbb-checkout .kbb-gift-msg{display:block;margin-top:9px}
.kbb-checkout .kbb-acct-err{display:block;margin-top:6px;font-size:12px;color:var(--pink)}
.kbb-checkout .kbb-note textarea,
.kbb-checkout .kbb-gift textarea{resize:vertical;min-height:62px}
.kbb-checkout .kbb-gift-count{display:block;margin-top:5px;font-size:11px;color:var(--muted);text-align:end}
</style>
<script>
/* The order summary's quantity endpoint, prefixed for this deployment.
   Url::to() rather than route(): the route lives in routes/checkout-line.php,
   which the integrator wires into routes/web.php, and a page that 500s because
   a route name is not registered yet is worse than a stepper that is not wired
   up yet. Published here rather than added to the layout's route list, which
   belongs to every page on the site and not just this one. */
window.KBB.routes.checkoutLine = @json(Url::to('/checkout/line'));
window.KBB.routes.checkoutCoupon = @json(Url::to('/checkout/coupon'));
@if (class_exists(\App\Support\CheckoutEmailCapture::class) && \App\Support\CheckoutEmailCapture::onForPage())
window.KBB.routes.checkoutEmail = @json(Url::to('/api/checkout-contact'));
@endif

(function () {
  var box = document.getElementById('create_account');
  var wrap = document.getElementById('account_password_wrap');
  if (!box || !wrap) return;
  function sync() {
    wrap.hidden = !box.checked;
    // Only required while the box is ticked, so an untouched checkout still
    // submits -- the server applies the same rule with required_if.
    var pw = document.getElementById('account_password');
    if (pw) { pw.required = box.checked; pw.disabled = !box.checked; if (!box.checked) pw.value = ''; }{{-- DISABLED while hidden, not only
         "not required": a disabled field is never autofilled, never validated and never sent. Firefox filled a saved
         short password into this hidden box, its minlength made the whole form invalid, and Place order did nothing
         with nothing on screen to say why (the owner, 8 October). CheckoutPlaceOrderNeverSilentTest. --}}
  }
  box.addEventListener('change', sync);
  sync();
})();

(function () {
  var gift = document.getElementById('is_gift');
  var wrap = document.getElementById('gift_note_wrap');
  var msg = document.getElementById('gift_note');
  var left = document.getElementById('gift_left');
  if (!gift || !wrap) return;
  function sync() {
    wrap.hidden = !gift.checked;
    // Cleared rather than merely hidden. The server drops it too when the box
    // is unticked, but a field the shopper cannot see should not still be
    // carrying their words.
    if (!gift.checked && msg) { msg.value = ''; }
    count();
  }
  function count() {
    if (msg && left) { left.textContent = String(600 - msg.value.length); }
  }
  gift.addEventListener('change', function () { sync(); price(); });
  if (msg) { msg.addEventListener('input', count); }

  // The fee comes back from the server, never added up here. The browser is
  // told what wrapping costs; it does not get to decide.
  var busy = false;
  function price() {
    if (busy) return;
    busy = true;
    var country = document.getElementById('billing_country');
    var state = document.getElementById('billing_state');
    fetch(@json(route('checkout.gift')), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': window.KBB.csrf,
        Accept: 'application/json'
      },
      body: JSON.stringify({
        is_gift: gift.checked ? 1 : 0,
        country: country ? country.value : 'AE',
        state: state ? state.value : ''
      })
    })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d.ok) { window.kbbToast && window.kbbToast(d.error || 'Could not update the total.'); return; }
        document.querySelectorAll('.js-gift-row').forEach(function (el) { el.hidden = !d.on; });
        document.querySelectorAll('.js-gift').forEach(function (el) { el.innerHTML = d.giftFee; });
        // Two copies of the totals exist -- summary column and mobile box.
        document.querySelectorAll('.js-total').forEach(function (el) { el.innerHTML = d.total; });
        if (d.totalWithFee) {
          document.querySelectorAll('.js-total-fee').forEach(function (el) { el.innerHTML = d.totalWithFee; });
        }
      })
      .catch(function () { window.kbbToast && window.kbbToast('Could not update the total.'); })
      .finally(function () { busy = false; });
  }

  sync();
})();
</script>
@endpush
{{-- The delivery-address sheet, the same one the cart page opens. It sits at
     the very foot of the page and outside every box that scrolls or clips, for
     the reasons its own header sets out. --}}
@if ($kbbCoPage->addressPickerRow())
@include('partials.address-sheet')
@endif
@endsection
