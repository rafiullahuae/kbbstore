<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderNote;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Refund;
use App\Services\ManualOrderBuilder;
use App\Services\Mail\OrderMailer;
use App\Services\SettingsService;
use App\Services\ShippingService;
use App\Services\Payments\PaymentCapturer;
use App\Services\Payments\PaymentRefunder;
use App\Support\AggregatesQueries;
use App\Support\Fils;
use App\Support\ImageVariants;
use App\Support\Money;
use App\Support\OrderTax;
use App\Support\StoreTime;
use App\Support\TaxRule;
use App\Support\WholeDirhams;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

/**
 * Backs the detailed admin order page (built from Rafi's WooCommerce
 * reference screenshot). Kept separate from the older AdminController
 * order() method rather than extending it — that method has real, wrong
 * column references (`$o->delivery`, `$o->cod_fee`, `$o->ship_method`,
 * `$i->qty`, none of which exist on these models) that silently return
 * null instead of erroring, quietly showing zeros in the old order modal.
 * Not fixed here since it's a separate, pre-existing bug outside this
 * page's scope — flagged rather than silently inherited into new code.
 */
class AdminOrderController extends Controller
{
    /**
     * Counting a builder that is also used to fetch a page of rows is how this
     * repo shipped MySQL error 1140 to production twice, and how a page-two
     * total silently read zero on every engine.
     */
    use AggregatesQueries;

    /** How many rows one customer or product search returns. */
    private const PAGE = 20;

    /**
     * The LIKE escape character.
     *
     * Without it, an operator searching for "50% off" or typing an underscore
     * matches every row in the table: % and _ are wildcards inside LIKE, and a
     * bound parameter does not escape them. Binding protects against SQL
     * injection, not against pattern injection.
     */
    private const LIKE_ESCAPE = '!';

    public function __construct(
        private ManualOrderBuilder $builder,
        private ShippingService $shipping,
        private SettingsService $settings,
    ) {}

    /** Actions that are real right now vs. visible-but-not-wired-up. */
    private const REAL_ACTIONS = ['cancel', 'duplicate', 'resend_confirmation', 'email_invoice'];
    /*
     * 'resend_confirmation' left the placeholder list when order email was
     * built; 'email_invoice' has now left it too. The store has a real invoice
     * — an invoice number allocated out of the unique sequence, and a document
     * rendered from the order_items snapshot by App\Services\Invoices — so the
     * button sends one instead of apologising for not having one.
     *
     * The list itself stays rather than being deleted. It is the mechanism for
     * saying "visible, and honest about not working yet", and the next
     * half-built action should use it rather than reinventing it. Empty is the
     * correct state of an honest list with nothing to declare, and
     * InvoiceEmailTest pins that 'email_invoice' is not on it.
     */
    private const PLACEHOLDER_ACTIONS = [];

    public function show(
        int $id,
        PaymentCapturer $capturer,
        PaymentRefunder $refunder,
    ): JsonResponse
    {
        /*
         * items.product, and only three columns of it.
         *
         * order_items snapshots the name, brand, SKU and price of what was sold
         * but not its photograph, so the line item's `image` below is the LIVE
         * product's. Read lazily that was one SELECT per line every time an
         * order was opened; named here it is one for the whole order. The
         * product may legitimately be gone — order_items.product_id is
         * nullOnDelete — which is exactly the case the screen now draws initials
         * for instead of an empty square.
         */
        $order = Order::withTrashed()
            ->with(['items.product:id,image,slug', 'notes'])
            ->find($id);

        if ($order === null) {
            return response()->json(['error' => 'not_found'], 404);
        }

        $customer = $order->customer;

        /*
         * THE TWO REFUND FIGURES, ASKED FOR ONCE EACH.
         *
         * They were read five times between them — `refundedFils()` three times
         * and `capturedFils()` twice — for the two numbers below. Each is a
         * fresh aggregate over `refunds` or `payments`, so this screen was
         * paying for the same two SUMs repeatedly on the one page in the admin
         * that has money on it. Measured on the detail endpoint: 11 statements
         * down to 8 on a paid-but-uncaptured order (where `capturedFils()`
         * really does hit `payments`), and 9 down to 7 on a captured one.
         *
         * Correctness, not only cost. Three separate reads of "how much has been
         * refunded" inside one response can disagree if a refund settles between
         * them, and `refundable_aed` and `settlement.refundable_fils` are the
         * same quantity in two units — computing them from one pair of reads is
         * what makes them incapable of contradicting each other on the screen.
         */
        $refundedFils = $refunder->refundedFils($order);
        $refundableFils = max(0, $refunder->capturedFils($order) - $refundedFils);

        // Read once: the settlement block and the payment panel both need it.
        $settlement = $capturer->status($order);

        return response()->json([
            'id' => $order->id,
            'order_number' => $order->order_number ?? (string) $order->id,
            'status' => $order->status,
            'trashed' => $order->trashed(),
            'editable' => in_array($order->status, self::EDITABLE_STATUSES, true),
            /*
             * SHOP-LOCAL, not UTC. This was `toAtomString()` on the Eloquent
             * cast, which is `config('app.timezone')` — UTC — so an order
             * placed at 01:30 in Dubai opened here showing the previous day,
             * both in the "Date created" boxes (which slice this string
             * positionally) and anywhere else the drawer prints it.
             *
             * Same wire SHAPE as before — `Y-m-d\TH:i:sP`, offset included —
             * so every existing slice() in the console keeps working; only the
             * offset it carries has changed, from +00:00 to the shop's. The
             * stored instant is untouched; see App\Support\StoreTime.
             */
            'created_at' => StoreTime::iso($order->created_at),
            'currency' => $order->currency,
            // Lane OLG: the language the order was placed in, 'en' or 'ar'.
            'locale' => OrdersApiController::orderLocale($order->locale),

            'payment_method' => $order->payment_method,
            'payment_method_title' => $order->payment_method_title,
            'transaction_id' => $order->transaction_id,
            'paid_at' => StoreTime::iso($order->paid_at),
            'ip_address' => $order->ip_address,

            'billing_address' => $order->billing_address,
            'shipping_address' => $order->shipping_address,
            'email' => $order->email,
            'phone' => $order->phone,

            'customer' => $customer ? [
                'id' => $customer->id,
                'name' => $customer->name,
                'email' => $customer->email,
            ] : null,

            'items' => $order->items->map(fn ($i) => [
                'id' => $i->id,
                'name' => $i->name,
                'brand' => $i->brand,
                'sku' => $i->sku,
                'variant_attributes' => $i->variant_attributes,
                // (Lane VPA) the same snapshot as one line of text, English,
                // for the order screen: "Shade: #13 Bright Beige".
                'variant' => \App\Support\VariantText::forOrderItem($i, false, ' · '),
                /*
                 * (Lane SET) What was in the box, as one line per member, from
                 * the order's own snapshot. An EMPTY LIST for every line that is
                 * not a set, so this payload is unchanged for every order in
                 * this shop today.
                 *
                 * The strings and not the raw column: the raw snapshot carries
                 * each member's SKU and unit price, and this endpoint is behind
                 * `orders.view` — which `support` holds. A picking list is what
                 * the order screen needs; a member's supplier code is not, and
                 * the narrower answer is the one to publish when both will do.
                 */
                'set_contents' => \App\Support\SetContents::lines(\App\Support\SetContents::fromOrderItem($i)),
                'quantity' => $i->quantity,
                'unit_price_aed' => Money::toAed($i->unit_price),
                'total_aed' => Money::toAed($i->total),
                'image' => $i->product?->image,
                // (Lane IM2) `.odthumb img` is a 36px square (app.blade.php:486)
                // and an order with ten lines was pulling ten catalogue
                // originals to fill it. 200w covers 36px at device-pixel-ratio
                // 3 five times over, and variantUrl() returns the original
                // untouched when no copy is on disk. `image` is unchanged for
                // everything that means the file.
                'thumb' => ImageVariants::variantUrl((string) ($i->product?->image ?? ''), 200),
                'product_slug' => $i->product?->slug,
            ]),

            'shipping_method' => $order->shipping_method,
            'coupon_code' => $order->coupon_code,
            'customer_note' => $order->customer_note,
            'is_gift' => (bool) $order->is_gift,
            'gift_note' => $order->gift_note,
            'gift_fee_aed' => Money::toAed((int) $order->gift_fee),
            'whatsapp_optin' => $order->whatsapp_optin,

            'subtotal_aed' => Money::toAed($order->subtotal),
            'discount_total_aed' => Money::toAed($order->discount_total),
            // 2.60.360: the buy-together part of discount_total, so the order
            // screen can show it apart from the coupon. 0 on older orders.
            'bundle_discount_aed' => Money::toAed((int) ($order->bundle_discount ?? 0)),
            'shipping_total_aed' => Money::toAed($order->shipping_total),
            'fee_total_aed' => Money::toAed($order->fee_total),
            'total_aed' => Money::toAed($order->total),
            /*
             * THE ORDER'S OWN TAX RECORD, AND NOTHING ELSE — Lane CU, closed
             * by Lane DU.
             *
             * Lane CU made a recorded order read from its record but left the
             * pre-lane computation in place as a fallback for orders that have
             * none:
             *
             *     $line = $vat->line($order->total);
             *
             * That fallback is gone, for the reason written out at length in
             * InvoiceDocument::vatNote(). The short version, in the terms that
             * matter on THIS screen: the figure it produced was a function of
             * today's `vat_rate`, so a member of staff opening an old order the
             * day after the owner edited the rate would be shown a tax the
             * customer was never charged — and would read it out to that
             * customer on the phone, or refund against it. The invoice and the
             * receipt for the same order now say nothing about tax; an admin
             * screen that contradicted them would be worse than one that
             * agrees. Three readers of one record, one answer.
             *
             * null here means "this order has no tax record", which is the
             * truth for every order placed before the engine and every order
             * placed while the shop sits in `display` mode.
             */
            'vat' => (function () use ($order) {
                $recorded = \App\Support\OrderTax::recorded($order);

                if ($recorded === null || $recorded['fils'] <= 0) {
                    return null;
                }

                $rule = new \App\Support\TaxRule($recorded['rate'], $recorded['basis']);

                return [
                    'label' => $recorded['added']
                        ? 'VAT at ' . $rule->printableRate() . '% (added to the total)'
                        : 'VAT at ' . $rule->printableRate() . '% (included in the total)',
                    'amount_aed' => Money::toAed($recorded['fils']),
                ];
            })(),

            'invoice_number' => $order->invoice_number,
            'invoiced_at' => StoreTime::iso($order->invoiced_at),
            // Where the two printable documents live, built by the controller
            // that serves them so there is one definition of each path and the
            // admin console never has to assemble one out of string pieces.
            // Both are inside the admin-api group, i.e. behind auth:admin; see
            // the InvoiceController header for why there is no public link.
            // Opening the invoice URL is what allocates invoice_number above,
            // so an order that reads "Not yet invoiced" here has genuinely
            // never had one issued.
            'invoice_url' => \App\Http\Controllers\Admin\InvoiceController::invoiceUrl($order->id),
            'packing_slip_url' => \App\Http\Controllers\Admin\InvoiceController::packingSlipUrl($order->id),
            'delivery_note_url' => \App\Http\Controllers\Admin\InvoiceController::deliveryNoteUrl($order->id),
            'shipping_label_url' => \App\Http\Controllers\Admin\InvoiceController::shippingLabelUrl($order->id),

            'refunds' => $order->refunds()->latest()->get()->map(fn (Refund $r) => [
                'id' => $r->id,
                'amount_aed' => Money::toAed((int) $r->amount),
                'reason' => $r->reason,
                'refunded_by' => $r->refunded_by,
                // A failed refund is shown, not hidden. The screen greys it
                // and the merchant can see that an attempt was made and that
                // no money went back — which is the whole reason failures are
                // recorded rather than swallowed.
                'status' => $r->status,
                'failure_code' => $r->failure_code,
                'provider_ref' => $r->provider_ref,
                'created_at' => StoreTime::iso($r->created_at),
            ]),
            // Only refunds that hold money. Summing every row would count
            // failures, which would quietly reduce what can still be refunded.
            'refunded_total_aed' => Money::toAed($refundedFils),
            'refundable_aed' => Money::toAed($refundableFils),

            // Capture: whether this order's money has actually been taken.
            // Never calls a provider — see PaymentCapturer::status().
            'settlement' => $settlement + [
                'refundable_fils' => $refundableFils,
                /*
                 * THE THIRD VERB, ON THE PAYLOAD THE ORDER SCREEN ACTUALLY
                 * READS — and it was missing here alone.
                 *
                 * PaymentSettlementController::state() has carried this key
                 * since the release button shipped, with a note explaining that
                 * the screen needs to tell "this order's authorisation has been
                 * released" from "this order has been captured". But the order
                 * detail drawer renders its money panel from THIS endpoint, not
                 * that one, and here there was no `void` key at all. So the one
                 * screen the button lives on was the one screen that could not
                 * see the release: a released authorisation drew the ordinary
                 * "Not captured" panel, with the capture window counting down
                 * on a hold that no longer exists.
                 *
                 * Same nested shape and same source as the settlement endpoint,
                 * so the two cannot come to disagree, and calling no provider
                 * for the reason PaymentCapturer::status() does not — this is
                 * rendered with every order.
                 *
                 * ADDITIVE. Nothing reads `settlement.void` on this endpoint
                 * today, so no existing caller changes.
                 */
                'void' => app(\App\Services\Payments\PaymentVoider::class)->status($order),
            ],

            'notes' => $order->notes->map(fn (OrderNote $n) => [
                'id' => $n->id,
                'author' => $n->author,
                'is_customer_note' => $n->is_customer_note,
                'content' => $n->content,
                'created_at' => StoreTime::iso($n->created_at),
            ]),

            'customer_history' => $this->customerHistory($order->customer_id, $order->email),

            // Order attribution: the panel Rafi's reference shows, kept honest
            // rather than faked — none of source/device/session-views is
            // tracked by anything in this app yet (confirmed directly: the
            // `origin` column exists in the schema but nothing anywhere ever
            // writes to it, not even on new checkout orders today). Shown as
            // null so the page can render "Not tracked yet" instead of a
            // fabricated number.
            // Source (Lane AN): first and last touch, campaign, landing page
            // and days to order, from the columns analytics stamps at checkout.
            // Allowlisted by Attribution::panel(); "Unknown" when none.
            'source' => \App\Services\Analytics\Attribution::panel($order->src_channel, $order->src_campaign, $order->src_attr),

            'attribution' => [
                'origin' => $order->origin,
                'device_type' => null,
                'session_page_views' => null,
            ],

            'actions' => [
                /*
                 * "Send on-hold email" is offered only while the order IS on
                 * hold (Lane RL). The owner keeps that email off and sends it by
                 * hand; offering it on an order that is not on hold would offer
                 * an email that says something untrue.
                 */
                'real' => (string) $order->status === 'onhold'
                    ? [...self::REAL_ACTIONS, 'email_onhold']
                    : self::REAL_ACTIONS,
                'placeholder' => self::PLACEHOLDER_ACTIONS,
            ],

            /*
             * What the "Email the customer about this change" tick box beside
             * the status dropdown needs to draw itself: for every status, is
             * there a customer message at all, does the standing rule send it,
             * and if not, why not.
             *
             * Carried on the order payload rather than fetched separately
             * because the screen needs it at the same moment it needs the
             * order, and because one answer read once cannot disagree with
             * itself. It is store configuration, not a fact about this order —
             * the per-order part is the tick the operator makes, which travels
             * back on the status-change request as `notify` and is never
             * stored. See App\Services\Mail\OrderStatusMailPolicy.
             */
            'status_emails' => app(\App\Services\Mail\OrderStatusMailPolicy::class)->all(),

            /*
             * (Lane PU) The payment panel under the Items, decided on the
             * server -- see App\Support\OrderPaymentPanel for every state and
             * for why Capture survives only on Tabby and Tamara.
             */
            'payment' => \App\Support\OrderPaymentPanel::for($order, $refundedFils, $settlement),

            // (Lane TM) Placed -> session opened or refused (and why) -> came
            // back -> provider's notice. See App\Support\PaymentJourney.
            'payment_journey' => \App\Support\PaymentJourney::for($order),
            // (Lane OL) "Send order link": eligibility and the last send, off the notes already loaded.
            // Its two abilities ride here, not in `can`, which is pinned whole.
            'pay_link' => \App\Services\Orders\OrderPayLink::panel($order) + [
                'can' => self::may('orders.paylink'),
                'can_settings' => self::may('orders.paylink.settings'),
            ],
            // 2.60.562: "Ask for UAE number" beside the phone -- when it was last
            // sent, and whether the phone is a UAE mobile already. Its ability
            // rides here, not in `can`, which is pinned whole.
            'phone_request' => \App\Http\Controllers\Admin\OrderPhoneRequestController::panel($order) + [
                'can' => self::may('orders.manage'),
            ],
            // (Lane TM) what the shopper did before paying, and every email sent
            // for the order. One query each; see the two classes.
            'customer_journey' => \App\Support\CustomerJourney::for($order),
            'emails' => \App\Support\OrderEmails::for($order),

            /*
             * What the signed-in admin may do on this screen, so the console
             * draws only the controls the server will accept. The SERVER is
             * still the gate -- every one of these is its own rule in
             * AdminCapabilities and fails closed -- this only spares a support
             * account a modal that ends in a 403.
             */
            'can' => self::abilities(),

            // Store -> Orders -> (an order) -> Status -> "Mark as paid": the
            // methods its select offers. See ManualPayment::methodsFor().
            'payment_methods' => app(\App\Services\Orders\ManualPayment::class)->methodsFor($order),
            'unpaid_statuses' => \App\Support\OrderPaymentPanel::UNPAID_STATUSES,
            'paid_statuses' => \App\Support\OrderPaymentPanel::PAID_STATUSES,

            // The Billing / Shipping editor's two lists.
            'address_form' => [
                'countries' => \App\Support\Countries::NAMES,
                'emirates' => \App\Support\OrderAddress::EMIRATES,
            ],
        ]);
    }

    /** @return array<string, bool> */
    private static function may(string $capability): bool
    {
        $admin = auth('admin')->user();

        return $admin instanceof \App\Models\AdminUser && \App\Support\AdminRoles::can($admin, $capability);
    }

    private static function abilities(): array
    {
        $admin = auth('admin')->user();
        $can = fn (string $capability) => $admin instanceof \App\Models\AdminUser
            && \App\Support\AdminRoles::can($admin, $capability);

        return [
            'edit' => $can('orders.edit'),
            'customer' => $can('orders.customer'),
            'payment' => $can('orders.payment'),
            'money' => $can('orders.money'),
        ];
    }

    public function addNote(Request $request, int $id): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);

        $data = $request->validate(['content' => ['required', 'string', 'max:5000']]);

        $note = $order->notes()->create([
            'content' => $data['content'],
            'author' => auth('admin')->user()?->name ?? 'Admin',
            'is_customer_note' => false,
        ]);

        return response()->json(['ok' => true, 'note' => [
            'id' => $note->id, 'author' => $note->author, 'content' => $note->content,
            'is_customer_note' => false, 'created_at' => StoreTime::iso($note->created_at),
        ]]);
    }

    /**
     * Refund, full or partial — and now really a refund.
     *
     * This method used to write a `refunds` row and stop there, because no
     * gateway had a refund path to call: honestly partial, and documented as
     * such. It now hands the work to PaymentRefunder, which calls the gateway
     * and records the attempt either way. Three things moved OUT of here as a
     * result, and none of them by accident:
     *
     *   THE CEILING. It was `order.total` and it is now the CAPTURED amount
     *   minus what is already refunded, computed inside a locked transaction
     *   in the service. The old check used `$order->refunds()->sum('amount')`,
     *   which counts every row — including, once failures started being
     *   recorded, refunds that never happened. A failed attempt would have
     *   silently reduced what could still be refunded.
     *
     *   THE STATUS CHANGE. Moved for the same reason: a partial refund that
     *   fails at the gateway must not be what tips an order into `refunded`.
     *
     *   IDEMPOTENCY. The double-click guard is a unique index on
     *   `refunds.idempotency_key`, so it has to be applied by the code that
     *   writes the row. The screen sends a key per form render; a caller that
     *   sends none gets a derived one.
     *
     * What stays here is HTTP: validate, convert the screen's AED into fils
     * once, and translate the outcome into a status code. `amount_fils` is
     * accepted and preferred for a caller that has the integer already —
     * there is then no float on the path at all.
     */
    public function refund(Request $request, int $id, PaymentRefunder $refunder): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);

        $data = $request->validate([
            'amount_fils' => ['nullable', 'integer', 'min:1'],
            'amount_aed' => ['nullable', 'numeric', 'min:0.01'],
            'reason' => ['nullable', 'string', 'max:1000'],
            'idempotency_key' => ['nullable', 'string', 'max:191'],
        ]);

        if (($data['amount_fils'] ?? null) === null && ($data['amount_aed'] ?? null) === null) {
            return response()->json(['ok' => false, 'message' => 'Enter a refund amount.'], 422);
        }

        // One conversion, in one place, through the same helper the rest of
        // the app converts money with. Integer fils from here down.
        $amountFils = $data['amount_fils'] ?? Money::fromMajor($data['amount_aed']);

        $outcome = $refunder->refund(
            $order,
            (int) $amountFils,
            $data['reason'] ?? null,
            auth('admin')->user()?->name ?? 'Admin',
            $data['idempotency_key'] ?? null,
        );

        $order->refresh();

        // Read once each, AFTER the refresh, for the reason given on the pair
        // in show(): three reads of "how much has been refunded" inside one
        // response can disagree, and these two are the same quantity in two
        // units. They must be computed here rather than before the refund —
        // the refund is what changes them.
        $refundedFils = $refunder->refundedFils($order);
        $refundableFils = max(0, $refunder->capturedFils($order) - $refundedFils);

        return response()->json([
            'ok' => $outcome->ok,
            'code' => $outcome->code,
            // Written for the admin. Never an API body, a key or a buyer field.
            'message' => $outcome->message,
            'refund_id' => $outcome->refund?->id,
            'refund_status' => $outcome->refund?->status,
            'status' => $order->status,
            'refunded_total_aed' => Money::toAed($refundedFils),
            'refundable_aed' => Money::toAed($refundableFils),
        ], $outcome->ok ? 200 : $outcome->status);
    }

    public function trash(int $id): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);

        $order->delete();

        return response()->json(['ok' => true]);
    }

    public function restore(int $id): JsonResponse
    {
        $order = Order::withTrashed()->find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);

        $order->restore();

        return response()->json(['ok' => true]);
    }

    /**
     * PUT /admin-api/orders/{id}/address -- Store -> Orders -> (an order) ->
     * Billing / Shipping -> Edit. Capability `orders.edit`. (Lane PU)
     *
     * WHAT THIS WAS. `'address' => ['required', 'array']` and then the array,
     * whatever it held, written straight over the snapshot: any keys, any
     * values, any length, no record of who changed what. Its only caller was a
     * JSON textarea behind the Shipping "Edit"; Billing's "Edit" was an
     * `<a href="#">` with no handler at all, which is the "I can not edit the
     * address" the owner reported.
     *
     * NOW: the ten fields every writer in the shop uses (App\Support\
     * OrderAddress), each validated; billing also carries the order's email and
     * phone, because that is where the order screen shows them and where the
     * checkout wrote them from. Every save that changes something leaves an
     * order note naming the field, the old value, the new one and the admin.
     */
    public function updateAddress(Request $request, int $id): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);

        // "ae" is the same country as "AE"; the list is keyed upper-case.
        $input = $request->input('address');
        if (is_array($input) && isset($input['country']) && is_string($input['country'])) {
            $input['country'] = strtoupper(trim($input['country']));
            $request->merge(['address' => $input]);
        }

        $data = $request->validate([
            'type' => ['required', 'in:billing,shipping'],
            ...\App\Support\OrderAddress::rules('address'),
            'email' => ['sometimes', 'required', 'string', 'email:rfc', 'max:191'],
        ], [
            'address.*.regex' => 'That field contains characters an address cannot hold.',
            'address.country.in' => 'Choose a country from the list.',
        ]);

        $column = $data['type'] === 'billing' ? 'billing_address' : 'shipping_address';
        $old = $order->{$column};
        $new = \App\Support\OrderAddress::merge(is_array($old) ? $old : null, $data['address']);

        $changes = \App\Support\OrderAddress::changes(is_array($old) ? $old : null, $new);
        $write = [$column => $new];

        if ($data['type'] === 'billing') {
            if (array_key_exists('email', $data)) {
                $email = mb_strtolower(trim((string) $data['email']));
                if ($email !== (string) $order->email) {
                    $changes[] = 'Email: ' . $order->email . ' → ' . $email;
                    $write['email'] = $email;
                }
            }

            // The order's own phone is the billing phone -- the checkout writes
            // both from one field -- so they move together.
            $phone = $new['phone'] ?? null;
            if (array_key_exists('phone', $data['address']) && $phone !== $order->phone) {
                $write['phone'] = $phone;
            }
        }

        if ($changes === []) {
            return response()->json(['ok' => true, 'changed' => 0, 'message' => 'Nothing changed.']);
        }

        // Lane EM: the emirate Store -> Orders counts by, read again from the
        // edited address. Only when the row carries the column (find() selects
        // every column), so the edit still saves on the old schema.
        if (array_key_exists('ship_emirate', $order->getAttributes())) {
            $write['ship_emirate'] = \App\Support\OrderEmirate::read(
                $column === 'shipping_address' ? $new : $order->shipping_address,
                $column === 'billing_address' ? $new : $order->billing_address,
            );
        }

        $order->forceFill($write)->save();

        $by = auth('admin')->user()?->name ?? 'Admin';
        $order->notes()->create([
            'content' => ucfirst($data['type']) . ' details edited by ' . $by . ': ' . implode('; ', $changes) . '.',
            'author' => $by,
            'is_customer_note' => false,
        ]);

        return response()->json([
            'ok' => true,
            'changed' => count($changes),
            'message' => ucfirst($data['type']) . ' details saved',
        ]);
    }

    /**
     * Every action on this dropdown is now real.
     *
     * Cancel and duplicate always were. 'resend_confirmation' became real when
     * order email shipped but was never added back to REAL_ACTIONS, so the
     * screen stopped offering it at all — it is on the list again above.
     * 'email_invoice' is real as of this package: it allocates the order's
     * invoice number if it has none and mails the document.
     *
     * The placeholder branch below survives them, unused. It is the mechanism
     * for showing Rafi what the page is building toward without ever making a
     * button look like it worked when it did not, and deleting it would mean
     * the next half-built action invents its own way of saying so.
     */
    /**
     * Columns that describe what happened to the ORIGINAL order, and so must
     * not travel to a copy of it.
     *
     * ── WHAT THIS COST ─────────────────────────────────────────────────────
     *
     * The list was `['order_number', 'invoice_number', 'transaction_id',
     * 'paid_at', 'completed_at', 'deleted_at']`, and it is the six columns it
     * did NOT name that did the damage. `captured_at`, `captured_total` and
     * `capture_ref` are the record that this shop took a customer's money. A
     * duplicate carried all three, so pressing Duplicate on a captured AED
     * 250.00 order produced a brand-new `draft` order that:
     *
     *   - READ AS ALREADY PAID. PaymentCapturer::status() answers `captured:
     *     true`, `captured_total_aed: 250`, `capturable: false`, so the money
     *     panel printed "Captured · AED 250.00 · ref <the original's>" and the
     *     Capture button was not drawn at all. Measured, not read: see the
     *     first expectation below. That is precisely the failure PaymentCapturer
     *     was written to end — "the store shipped goods against authorisations
     *     that quietly expired, and the merchant was never paid" — arriving by
     *     a different door. The duplicate ships and nobody is ever charged.
     *
     *   - WAS REFUNDABLE FOR MONEY IT NEVER TOOK. PaymentRefunder's ceiling is
     *     `captured_total` whenever `captured_at` is set, and `refunds` rows are
     *     NOT replicated, so the copy read 250.00 captured and 0.00 refunded.
     *     A full refund on it was accepted: on cash on delivery that is a
     *     ledger line telling staff to hand back AED 250 in cash to somebody
     *     who never paid a fil, and the copy moved itself to `refunded`. On a
     *     gateway it is worse, because `capture_ref` is the ORIGINAL's capture
     *     reference and the original's own refunded total stays at zero — the
     *     same capture refunded twice, once from each order.
     *
     * `voided_at` and `void_ref` are the same mistake for the release button: a
     * copy of a released order reported its own authorisation already released.
     * `invoiced_at` went with them because `invoice_number` was already
     * excluded, and a copy that carries one half of that pair reads as invoiced
     * while carrying no invoice number.
     *
     * The rule this expresses: a duplicate inherits what was ORDERED — lines,
     * addresses, shipping method, coupon snapshot, the figures — and inherits
     * nothing about what was PAID, released or printed. Those are events, and
     * they happened to the other order.
     */
    private const NOT_DUPLICATED = [
        'order_number', 'invoice_number', 'invoiced_at',
        'transaction_id', 'paid_at', 'completed_at', 'deleted_at',
        'captured_at', 'captured_total', 'capture_ref',
        'voided_at', 'void_ref',
    ];

    public function runAction(Request $request, int $id): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);

        $data = $request->validate(['action' => ['required', 'string']]);
        $action = $data['action'];

        if ($action === 'resend_confirmation') {
            // The mailer answers honestly here rather than swallowing, because
            // somebody pressed a button and is waiting for the result. 422 on
            // failure so the screen shows the reason instead of a tick.
            $result = app(\App\Services\Mail\OrderMailer::class)->resendConfirmation($order);

            return response()->json($result, $result['ok'] ? 200 : 422);
        }

        if ($action === 'email_onhold') {
            /*
             * "Send on-hold email" (Lane RL). The owner's manual on-hold email,
             * with an optional sentence of his own ("What we need: ..."). Same
             * contract as the two buttons around it: the mailer reports, 422 on
             * failure so the screen prints the reason. Refused unless the order
             * is on hold. Rides this endpoint's capability, orders.manage, as
             * Resend confirmation does — it is the same kind of act.
             */
            $note = $request->validate(['message' => ['sometimes', 'nullable', 'string', 'max:500']])['message'] ?? '';

            $result = app(\App\Services\Mail\OrderMailer::class)->sendOnHold($order, (string) $note);

            if ($result['ok']) {
                try {
                    $order->notes()->create([
                        'author' => auth('admin')->user()?->name ?: 'Admin',
                        'is_customer_note' => false,
                        'content' => 'Emailed the customer that the order is on hold.'
                            . (trim((string) $note) !== '' ? ' Message: ' . trim((string) $note) : ''),
                    ]);
                } catch (\Throwable) {
                    // The note is a courtesy; the email has gone.
                }
            }

            return response()->json($result, $result['ok'] ? 200 : 422);
        }

        if ($action === 'email_invoice') {
            // Same contract as the resend above, and for the same reason: the
            // mailer reports instead of swallowing, because somebody pressed a
            // button and is waiting for the answer. 422 on failure so the screen
            // prints the reason rather than a tick. The response carries the
            // invoice number the send used, so the screen can show it without a
            // second round trip — and so the owner can see which document went.
            $result = app(\App\Services\Mail\OrderMailer::class)->emailInvoice($order);

            return response()->json($result, $result['ok'] ? 200 : 422);
        }

        if (in_array($action, self::PLACEHOLDER_ACTIONS, true)) {
            // The list is empty today. This stays as the shape of an honest
            // refusal for the next action that is visible before it is built:
            // the copy names what is missing rather than claiming the whole
            // feature is unbuilt, which is what the old invoice message did for
            // months after the sentence stopped being true.
            return response()->json([
                'ok' => false,
                'message' => 'That action is on the screen but not wired up yet.',
            ], 422);
        }

        if ($action === 'cancel') {
            // The same per-order decision the status dropdown carries, because
            // Cancel is a status change wearing a button. Recorded before the
            // save, which is what fires OrderMailObserver; absent means the
            // standing rule for `cancelled` decides.
            app(\App\Services\Mail\OrderStatusMailPolicy::class)->decideFor(
                $order,
                $request->has('notify') ? $request->boolean('notify') : null,
            );

            // Through the funnel, for the reason the dropdown goes through it:
            // Cancel is a status change wearing a button, and a cancelled order
            // has to give back the coupon use it is holding. See
            // App\Services\Orders\OrderStatus. Pressing Cancel twice returns
            // one use, not two — the second press is not a transition.
            //
            // The units this order was holding go back too. That call used to
            // stand here, one of five copies; it is inside the funnel now, so
            // Cancel here and Cancel on the orders list cannot come to mean
            // different things to the stock room — which is what
            // OrderTransitionStock's own header asked for.
            app(\App\Services\Orders\OrderStatus::class)->moveTo(
                $order,
                'cancelled',
                by: auth('admin')->user()?->name ?: 'Admin',
                reason: 'Cancelled on the order screen.',
            );

            return response()->json(['ok' => true, 'status' => 'cancelled']);
        }

        if ($action === 'duplicate') {
            $new = $order->replicate(self::NOT_DUPLICATED);
            $new->order_number = $this->nextOrderNumber();
            $new->status = 'draft';
            $new->save();

            foreach ($order->items as $item) {
                $new->items()->create($item->replicate()->toArray());
            }

            return response()->json(['ok' => true, 'new_order_id' => $new->id, 'new_order_number' => $new->order_number]);
        }

        return response()->json(['ok' => false, 'message' => 'Unknown action.'], 422);
    }

    /** Only orders that haven't shipped are safe to change the contents of — once packed, editing the line items doesn't reflect reality. */
    private const EDITABLE_STATUSES = ['draft', 'pending', 'processing', 'onhold'];

    /**
     * The ceiling on one line's quantity.
     *
     * Not a guess at what anyone would order: it is the largest quantity that
     * cannot on its own take a line past the money column at any unit price a
     * shop would charge, and it matches the 99 the storefront cart enforces in
     * CartService::add(). A back office that accepted a quantity the shop front
     * clamps would be two different products.
     */
    private const MAX_QUANTITY = 99;

    /**
     * Refuse a line whose money will not fit, before anything is written.
     *
     * order_items.unit_price, .subtotal and .total are all `$t->integer` —
     * signed 32-bit, so 2,147,483,647 fils (AED 21,474,836.47) is the ceiling.
     * Both the Phase 0 schema and 2026_09_15_020000_repair_order_tables declare
     * them that way.
     *
     * Bounding each factor on its own is not enough: a unit price and a
     * quantity can both be perfectly ordinary and their product still be past
     * the column. And the order's own subtotal is a sum across lines, so a
     * tenth line can overflow it while every line including that one fits.
     *
     * Both engines are wrong here, differently. MySQL in strict mode raises and
     * the operator sees a 500 on a save they had no reason to think would fail.
     * SQLite stores the wrapped number without a word — an order that reads as
     * placed, with a total that is negative or nonsense, which is the half that
     * reaches a customer.
     */
    private function refuseOverflowingLine(Order $order, int $unitPrice, int $quantity, ?int $ignoreItemId = null): ?JsonResponse
    {
        $ceiling = Money::plain(Fils::max());

        if (! Fils::productFits($unitPrice, $quantity)) {
            return response()->json([
                'ok' => false,
                'message' => 'That quantity at that unit price comes to more than an order line can hold (' . $ceiling . ').',
            ], 422);
        }

        $line = $unitPrice * $quantity;

        $others = (int) $order->items()
            ->when($ignoreItemId !== null, fn ($q) => $q->whereKeyNot($ignoreItemId))
            ->sum('total');

        if (! Fils::sumFits($others, $line, (int) $order->shipping_total, (int) $order->fee_total, (int) $order->tax_total)) {
            return response()->json([
                'ok' => false,
                'message' => 'That line would take the order total past what it can hold (' . $ceiling . ').',
            ], 422);
        }

        return null;
    }

    private function assertEditable(Order $order): ?JsonResponse
    {
        if (!in_array($order->status, self::EDITABLE_STATUSES, true)) {
            return response()->json(['ok' => false, 'message' => 'This order is no longer editable — it has already shipped or been closed out.'], 422);
        }

        return null;
    }

    /**
     * Recomputes subtotal, tax and total from the order's own line items after
     * any add/update/remove — never trusting a client-sent total.
     *
     * ── DOES EDITING AN ORDER RE-PRICE IT? YES, AND IT HAS TO ───────────────
     *
     * This method used to write
     *
     *     total = subtotal + shipping + fee + tax_total - discount
     *
     * with `tax_total` left exactly as the checkout wrote it. While `tax_total`
     * was always 0 that was harmless. It is not harmless now: App\Support\OrderTax
     * and the `tax_mode` switch mean an order can carry a real tax figure, and
     * an operator who adds a line to one of those left the tax describing a
     * subtotal that no longer exists — an invoice whose own column of figures
     * does not add up.
     *
     * The alternative — leave the tax alone, on the grounds that an edit must
     * never change what a customer was charged — was rejected, because it does
     * not achieve that. The subtotal and the total move either way; the only
     * thing not re-pricing preserves is a tax figure that has stopped describing
     * the goods. An operator who adds a bottle of toner has changed the supply,
     * and the document has to say so.
     *
     * ── AT THE ORDER'S OWN RATE AND BASIS, NEVER AT TODAY'S SETTINGS ────────
     *
     * The rule comes from OrderTax::recorded(), which reads `orders.tax_rate`
     * and `orders.tax_basis` — the figures snapshotted when the order was
     * placed. Nothing here consults VatDisplay or the settings table. That is
     * the whole point of OrderTax's existence: the invoice and the receipt both
     * used to recompute at print time, so raising a rate reprinted last year's
     * invoices at the new one. An edit screen that looked the rate up live would
     * be the same defect wearing different clothes.
     *
     * ── THE THREE BASES ARE THREE DIFFERENT SUMS ───────────────────────────
     *
     *   exclusive   tax is ADDED on top.       total = base + tax
     *   inclusive   tax is INSIDE the price.   total = base
     *   flat        printed, never charged.    total = base, tax_total 0
     *
     * TaxRule::grossOf() is the one place that distinction lives, so this asks
     * it rather than restating it. The old sum added `tax_total` unconditionally
     * and so was wrong for `inclusive` as well: the first edit of an inclusive
     * order inflated its total by the tax already contained in it.
     *
     * ── AN ORDER WITH NO TAX RECORD KEEPS THE SUM IT ALWAYS HAD ────────────
     *
     * recorded() answers null for every order placed before the tax engine,
     * every order placed in the shipped `display` mode and every imported
     * WooCommerce order. Those take the legacy branch byte for byte — which
     * matters most for the imported ones, because they carry a real Woo
     * `tax_total` with no rate beside it that has to keep being added exactly
     * as it always was.
     *
     * ── AND THE OPERATOR IS TOLD ───────────────────────────────────────────
     *
     * A tax figure that moves writes a private order note, into the history the
     * order screen already draws. Not a confirmation dialog: the re-price is a
     * consequence of the edit rather than a second decision, and a modal between
     * an operator and a line they are correcting is a modal they learn to click
     * through. A note is what is still there tomorrow when somebody asks why the
     * total changed.
     */
    private function recalcTotals(Order $order): void
    {
        $subtotal = (int) $order->items()->sum('total');
        $order->subtotal = $subtotal;

        $recorded = OrderTax::recorded($order);

        if ($recorded === null) {
            /*
             * THE SAME CLAMP THE TAXED BRANCH BELOW GETS FOR FREE.
             *
             * This was `$subtotal + shipping + fee + tax_total - discount`,
             * with nothing stopping the subtraction. `discount_total` is
             * whatever the coupon was worth against the basket AS PLACED and
             * no edit here re-evaluates it, so an operator who removes the
             * discounted line — or prices it down to zero — leaves a discount
             * larger than the order it is taken off, and the total went
             * NEGATIVE: a 150.00 order with a 100.00 coupon, minus its 100.00
             * line, wrote total = -50.00.
             *
             * A negative `orders.total` is not a display glitch. It is summed
             * as revenue on the dashboard and in customerHistory(), printed on
             * the invoice as the amount due, and read as the refund ceiling by
             * PaymentRefunder::capturedFils() for an order with no payment row
             * — where <= 0 means "nothing captured" and refunds are refused
             * outright.
             *
             * The taxed branch below never had this: it builds its base
             * through OrderTax::base(), which is `max(0, subtotal - discount)
             * + shipping`. Two branches of one method disagreeing about what
             * an over-large discount means is the defect; this uses the same
             * expression so they cannot disagree again. `tax_total` is still
             * added verbatim, exactly as before, because with no recorded rule
             * there is nothing to recompute it from.
             */
            $order->total = OrderTax::base($order) + (int) $order->fee_total + (int) $order->tax_total;
            $order->save();

            return;
        }

        $rule = new TaxRule($recorded['rate'], $recorded['basis']);

        // OrderTax::base() reads the columns just written, so this is the base
        // AFTER the edit: subtotal - discount + shipping, the identical
        // expression CartService::totals() taxes.
        $base = OrderTax::base($order);
        $was = (int) $order->tax_total;

        /*
         * `flat` charges nothing and contains nothing, so its column stays 0 —
         * exactly what the checkout writes for it. OrderTax::recorded()
         * recomputes the figure a flat order PRINTS from the rate, and does it
         * on demand, so there is nothing here to keep in step with it.
         */
        $order->tax_total = $rule->basis === TaxRule::FLAT ? 0 : $rule->taxOn($base);

        $order->total = $rule->grossOf($base) + (int) $order->fee_total;
        $order->save();

        if ((int) $order->tax_total !== $was) {
            $this->noteTaxRecalculated($order, $was, (int) $order->tax_total, $rule);
        }
    }

    /**
     * The order's own history, told that its tax moved and on what authority.
     *
     * Deliberately names the rate and the basis it used. "The tax changed" is
     * not something an operator can check; "recalculated at 15% exclusive, the
     * rate recorded on this order" is, and it is the sentence that makes it
     * obvious if the figure ever does come from somewhere else.
     *
     * THE TWO FIGURES ARE RENDERED AT Money::minorExponent(), NOT AT THE
     * STOREFRONT'S DISPLAY WIDTH. Money::plain() with no width follows
     * Money::displayDecimals(), which is 0 on this store, so every movement
     * smaller than half a dirham wrote itself down as
     *
     *     Tax recalculated after the items changed: AED 4 → AED 4 at 2% …
     *
     * an audit entry stating that a figure changed to the value it already
     * had. This note is only written BECAUSE the figure moved — the caller
     * checks `!==` first — so the rounded form contradicts the reason the row
     * exists. And `order_notes` has no edit path: there is no screen, no
     * endpoint and no command that can correct one, so a note that records
     * nothing records nothing permanently.
     *
     * Same rule, same reason as a receipt, and the argument is written out in
     * App\Services\Mail\OrderEmailPresenter's header: a document somebody
     * will act on may not round the figure it is about. The rate and the basis
     * were always exact; only the two amounts the sentence is ABOUT were not.
     */
    private function noteTaxRecalculated(Order $order, int $was, int $now, TaxRule $rule): void
    {
        OrderNote::create([
            'order_id' => $order->getKey(),
            'author' => auth('admin')->user()?->name ?: 'Admin',
            'is_customer_note' => false,
            'content' => sprintf(
                'Tax recalculated after the items changed: %s → %s at %s%% %s, the rate recorded on this order when it was placed.',
                Money::plain($was, Money::minorExponent()),
                Money::plain($now, Money::minorExponent()),
                $rule->printableRate(),
                $rule->basis,
            ),
        ]);
    }

    public function addItem(Request $request, int $id): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);
        if ($blocked = $this->assertEditable($order)) return $blocked;

        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            // Bounded. order_items.quantity is an unsignedInteger and the money
            // columns beside it are signed 32-bit; an unbounded quantity
            // overflows their product long before it overflows itself.
            'quantity' => ['required', 'integer', 'min:1', 'max:' . self::MAX_QUANTITY],
            // (Lane VPA) the option, for a product sold by its options.
            'variant_id' => ['nullable', 'integer'],
        ]);

        $product = \App\Models\Product::find($data['product_id']);
        $unitPrice = (int) ($product->sale_price ?: $product->price);
        $quantity = (int) $data['quantity'];

        /*
         * (Lane VPA) A VARIABLE PRODUCT IS ADDED AS ONE OF ITS OPTIONS, never
         * as itself. Its parent row carries no price, so this used to add the
         * line at AED 0 with nothing saying which shade went in the parcel.
         * Without a variant the answer is the list to choose from (the screen
         * draws it and sends the pick back); a variant from another product is
         * refused. The price is the variant's own, sale window included.
         */
        $variant = null;

        if (! empty($data['variant_id'])) {
            $variant = ProductVariant::query()->where('product_id', $product->id)
                ->with('attributeValues:id,attribute_id,name', 'attributeValues.attribute:id,name,position')
                ->find((int) $data['variant_id']);

            if ($variant === null) {
                return response()->json(['ok' => false, 'message' => 'That option does not belong to this product.'], 422);
            }

            $variant->setRelation('product', $product);
            $unitPrice = $variant->effectivePrice();
        } elseif ($product->requiresVariant()) {
            $options = ProductVariant::query()->where('product_id', $product->id)->orderBy('position')
                ->with('attributeValues:id,attribute_id,name', 'attributeValues.attribute:id,name,position')
                ->get()
                ->map(function (ProductVariant $v) use ($product) {
                    $v->setRelation('product', $product);

                    return [
                        'id' => (int) $v->id,
                        'label' => \App\Support\VariantText::line(\App\Support\VariantText::snapshot($v), ' · ') ?: ('Option #'.$v->id),
                        'price_aed' => Money::toAed($v->effectivePrice()),
                        'in_stock' => $v->inStock(),
                    ];
                })->values();

            return response()->json([
                'ok' => false,
                'needs_variant' => true,
                'message' => 'Choose which option of '.$product->name.' to add.',
                'options' => $options,
            ], 422);
        }

        if ($refusal = $this->refuseOverflowingLine($order, $unitPrice, $quantity)) {
            return $refusal;
        }

        $lineTotal = $unitPrice * $quantity;

        $item = $order->items()->create([
            'product_id' => $product->id,
            'product_variant_id' => $variant?->id,
            'name' => $product->name,
            'brand' => $product->brand?->name,
            'sku' => $variant?->sku ?: $product->sku,
            'variant_attributes' => $variant ? \App\Support\VariantText::snapshot($variant) : null,
            'quantity' => $quantity,
            'unit_price' => $unitPrice,
            'subtotal' => $lineTotal,
            'total' => $lineTotal,
        ]);

        $this->recalcTotals($order);

        return response()->json(['ok' => true, 'item_id' => $item->id, 'total_aed' => Money::toAed($order->total)]);
    }

    public function updateItem(Request $request, int $id, int $itemId): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);
        if ($blocked = $this->assertEditable($order)) return $blocked;

        $item = $order->items()->find($itemId);
        if ($item === null) return response()->json(['error' => 'not_found'], 404);

        $data = $request->validate([
            'quantity' => ['sometimes', 'integer', 'min:1', 'max:' . self::MAX_QUANTITY],
            /*
             * A STRING, not `numeric`, and parsed by Fils::parse().
             *
             * `numeric` accepts scientific notation and any number of decimals,
             * and the old `(int) round($value * 100)` then routed an operator's
             * keystrokes through a double: (int) (1.15 * 100) is 114. round()
             * happens to rescue two-decimal values at today's magnitudes, so
             * this was latent rather than wrong — the same class of defect the
             * product editor had, and worth removing for the same reason.
             *
             * Fils::parse() reads the digits one at a time, refuses more
             * precision than a fil can hold rather than silently dropping it,
             * and refuses anything past the 32-bit money column.
             */
            'unit_price_aed' => ['sometimes', 'string', 'max:24', function (string $attribute, $value, $fail) {
                $fils = Fils::parse((string) $value);

                if ($fils === null) {
                    $fail('Enter a plain amount with at most two decimals, up to '
                        . Money::plain(Fils::max()) . '.');

                    return;
                }

                if ($fils < 0) {
                    $fail('A unit price cannot be negative.');
                }
            }],
        ]);

        if (isset($data['quantity'])) {
            $item->quantity = (int) $data['quantity'];
        }

        if (isset($data['unit_price_aed'])) {
            $typed = (int) Fils::parse((string) $data['unit_price_aed']);

            /*
             * WHOLE DIRHAMS on a manual order line — Lane FA.
             *
             * The one money field an operator types on this screen, so it is
             * REFUSED rather than adjusted; App\Support\WholeDirhams carries
             * the rule. An order is where every other figure in this shop ends
             * up, and a line priced at AED 99.80 puts a fil into a subtotal, a
             * total, an invoice, a receipt and a payment capture at once.
             *
             * AGAINST THE STORED PRICE, so an order REVIVED from the
             * WooCommerce era — whose lines were priced before this policy —
             * can still have its quantity corrected without the line price
             * being refused alongside it. The screen posts quantity and unit
             * price together.
             *
             * Refused BEFORE the overflow check below rather than after,
             * because refuseOverflowingLine() reports on the product of two
             * figures and this reports on one of them; naming the wrong
             * problem first is how an operator ends up changing the quantity
             * to fix a price.
             */
            if ($typed !== (int) $item->unit_price && ! WholeDirhams::isWhole($typed)) {
                return response()->json([
                    'ok' => false,
                    'message' => WholeDirhams::message('Unit price', $typed),
                    'errors' => ['unit_price_aed' => ['Whole ' . WholeDirhams::plural() . ' only.']],
                ], 422);
            }

            $item->unit_price = $typed;
        }

        // Both factors are individually in range by now. Their PRODUCT is the
        // thing that actually overflows, and it is checked after both have been
        // applied rather than against whichever one this request happened to
        // change — a sane new quantity against an already-large unit price
        // overflows just as well as the other way round.
        if ($refusal = $this->refuseOverflowingLine($order, (int) $item->unit_price, (int) $item->quantity, $item->id)) {
            return $refusal;
        }

        $item->subtotal = $item->unit_price * $item->quantity;
        $item->total = $item->subtotal;
        $item->save();

        $this->recalcTotals($order);

        return response()->json(['ok' => true, 'total_aed' => Money::toAed($order->total)]);
    }

    public function removeItem(int $id, int $itemId): JsonResponse
    {
        $order = Order::find($id);
        if ($order === null) return response()->json(['error' => 'not_found'], 404);
        if ($blocked = $this->assertEditable($order)) return $blocked;

        $item = $order->items()->find($itemId);
        if ($item === null) return response()->json(['error' => 'not_found'], 404);
        if ($order->items()->count() <= 1) {
            return response()->json(['ok' => false, 'message' => 'An order needs at least one item — remove the whole order instead if it should not exist.'], 422);
        }

        $item->delete();
        $this->recalcTotals($order);

        return response()->json(['ok' => true, 'total_aed' => Money::toAed($order->total)]);
    }

    private function nextOrderNumber(): string
    {
        $max = (int) Order::withTrashed()->max('id');

        return 'KBB-' . str_pad((string) ($max + 1000), 5, '0', STR_PAD_LEFT);
    }

    /**
     * The Customer history card. (Lane PU) Moved, unchanged, into
     * App\Support\OrderCustomerHistory so the "Order history" popup beside the
     * Customer field counts the same orders the card does -- two copies of
     * "which orders are this customer's" is how the popup and the card would
     * come to disagree on the same screen.
     */
    private function customerHistory(?int $customerId, string $email): array
    {
        return \App\Support\OrderCustomerHistory::summary($customerId, $email);
    }

    /* ===================================================================
     | GET /admin-api/manual-orders/bootstrap
     |=================================================================== */

    /**
     * Everything the form needs to render: the real vocabularies, not invented
     * ones.
     *
     * A sibling lane found AdminController::updateProduct validating status as
     * in:active,draft,archived when the products column carries
     * publish|draft|private — a save through it hid the product from the whole
     * storefront. So every list below is read from the schema or from the
     * table that owns it, and the same constants feed both this endpoint and
     * the validator in store().
     */
    public function bootstrap(OrderMailer $mailer): JsonResponse
    {
        $countries = $this->shipping->coveredCountries();

        if ($countries === []) {
            // No zone configured at all — the same floor the storefront
            // checkout falls back to, so the two never offer different lists.
            $countries = ['AE' => 'United Arab Emirates'];
        }

        return response()->json([
            'statuses' => ManualOrderBuilder::STATUSES,
            'default_status' => ManualOrderBuilder::DEFAULT_STATUS,
            'channels' => ManualOrderBuilder::CHANNELS,
            'payment_methods' => $this->builder->paymentMethods(),
            'countries' => $countries,
            'default_country' => (string) $this->settings->get('store_country', 'AE'),
            // Free text on the live site, offered as suggestions only — the
            // addresses table does not constrain state.
            'emirates' => [
                'Abu Dhabi', 'Dubai', 'Sharjah', 'Ajman',
                'Umm Al Quwain', 'Ras Al Khaimah', 'Fujairah',
            ],
            'currency' => 'AED',
            'cod_fee_fils' => (int) $this->settings->get('cod_fee', 0),
            'email' => $this->confirmationEmailCapability($mailer),
        ]);
    }

    /* ===================================================================
     | GET /admin-api/manual-orders/customers?q=
     |=================================================================== */

    /** Search the customer list by name, email or phone. */
    public function customers(Request $request): JsonResponse
    {
        $data = $request->validate([
            'q' => ['nullable', 'string', 'max:120'],
            'page' => ['nullable', 'integer', 'min:1', 'max:5000'],
        ]);

        $term = trim((string) ($data['q'] ?? ''));
        $page = (int) ($data['page'] ?? 1);

        // Customer soft-deletes, so the model's global scope already excludes
        // removed rows; nothing extra is needed here.
        $query = Customer::query();

        if ($term !== '') {
            $like = '%' . $this->escapeLike($term) . '%';

            $query->where(function ($q) use ($like) {
                foreach (['name', 'first_name', 'last_name', 'email', 'phone'] as $column) {
                    $q->orWhereRaw(
                        $column . " LIKE ? ESCAPE '" . self::LIKE_ESCAPE . "'",
                        [$like],
                    );
                }
            });
        }

        // Through App\Support\AggregatesQueries, which strips the select list,
        // the ordering and the page window from a copy of the builder. Counting
        // $query as it stands — after the orderByDesc and forPage below — is
        // MySQL 1140 on the ordering and a silent zero from page two on the
        // offset. Both have shipped from this repo.
        $total = (int) ($this->aggregate($query, 'count(*) as aggregate')?->aggregate ?? 0);

        $rows = (clone $query)
            ->orderByDesc('id')
            ->forPage($page, self::PAGE)
            ->get();

        return response()->json([
            'total' => $total,
            'page' => $page,
            'per_page' => self::PAGE,
            'customers' => $rows->map(fn (Customer $c) => [
                'id' => $c->id,
                'name' => $c->displayName(),
                'email' => $c->email,
                'phone' => $c->phone,
                'orders_count' => (int) $c->orders_count,
                'total_spent_fils' => (int) $c->total_spent,
                'address' => $this->addressOf($c),
            ])->values(),
        ]);
    }

    /* ===================================================================
     | GET /admin-api/manual-orders/products?q=
     |=================================================================== */

    /** Search the real catalogue by name or SKU. */
    public function products(Request $request): JsonResponse
    {
        $data = $request->validate([
            'q' => ['nullable', 'string', 'max:120'],
            'page' => ['nullable', 'integer', 'min:1', 'max:5000'],
        ]);

        $term = trim((string) ($data['q'] ?? ''));
        $page = (int) ($data['page'] ?? 1);

        // Everything sellable, including products hidden from the catalogue:
        // staff take orders for things that are not on the shop grid. Drafts
        // are excluded — 'publish' and 'private' are the two live values in
        // this schema's products.status (publish | draft | private).
        $query = Product::query()->whereIn('status', ['publish', 'private']);

        if ($term !== '') {
            $like = '%' . $this->escapeLike($term) . '%';

            /*
             * BRAND AND SLUG TOO, not just name and sku.
             *
             * The owner typed "anua" and got "Nothing in the catalogue matches
             * that", while the same search on the order detail screen returned
             * three products. Anua is a BRAND: no product name contains it, so
             * a name-and-sku search finds nothing, and the two screens
             * disagreed about the same catalogue.
             *
             * This is the set CatalogProductsApiController already searches —
             * name, sku, slug, brand name — so the operator gets the same
             * answer wherever they type. A staff member taking an order on the
             * phone reaches for the brand at least as often as the product
             * name.
             *
             * whereHas rather than a join: this query is cloned for a count and
             * then again for the page, and a join would need the select list
             * below to disambiguate every column.
             */
            $query->where(function ($q) use ($like, $term) {
                $q->orWhereRaw("name LIKE ? ESCAPE '" . self::LIKE_ESCAPE . "'", [$like])
                    ->orWhereRaw("sku LIKE ? ESCAPE '" . self::LIKE_ESCAPE . "'", [$like])
                    ->orWhereRaw("slug LIKE ? ESCAPE '" . self::LIKE_ESCAPE . "'", [$like])
                    ->orWhereHas('brand', function ($b) use ($like) {
                        $b->whereRaw("name LIKE ? ESCAPE '" . self::LIKE_ESCAPE . "'", [$like]);
                    });

                // Typing an id finds that product, as it does on the catalogue
                // screen.
                if (ctype_digit($term)) {
                    $q->orWhere('id', '=', (int) $term);
                }
            });
        }

        $total = (int) ($this->aggregate($query, 'count(*) as aggregate')?->aggregate ?? 0);

        /*
         * An explicit allowlist, never the whole row.
         *
         * `products` also carries `description` — a page of HTML per row — plus
         * seo, seo_json, meta_feed and custom_tabs, none of which a suggestion
         * row shows. Selecting * shipped all of it, ten rows at a time, on every
         * keystroke of a type-ahead. The columns here are exactly what the
         * payload below reads: the five identity/display fields, `brand_id` for
         * the brand relation to hang off, and the four price columns
         * effectivePrice() needs to honour a sale window.
         */
        $rows = (clone $query)
            ->select([
                'id', 'name', 'sku', 'image', 'brand_id',
                'price', 'sale_price', 'sale_starts_at', 'sale_ends_at',
                'stock', 'stock_status',
                /*
                 * ▲ `type` AND THE THREE SET COLUMNS. (Lane SG) Without them
                 *   Product::isSet() fails closed here and `price_fils` below
                 *   quotes `products.price` for a set -- the stale snapshot,
                 *   not what the shop charges. The ORDER was always right
                 *   (ManualOrderBuilder loads whole rows); it is the figure the
                 *   operator reads while picking that was wrong. `type` changes
                 *   nothing else on this payload: it is read by isSet() and by
                 *   requiresVariant(), and this handler calls neither.
                 */
                'type', ...\App\Support\SetPricing::COLUMNS,
            ])
            // (Lane VPA) each option's name, so the picker can offer "Shade:
            // #21 Light Beige" rather than a bare id.
            ->with(['brand:id,name', 'variants', 'variants.attributeValues:id,attribute_id,name', 'variants.attributeValues.attribute:id,name,position'])
            // `id` after `name`, because forPage() below is LIMIT/OFFSET and
            // product names are not unique: two products sharing a name at a
            // page boundary can otherwise land on both pages of the picker,
            // or on neither.
            ->orderBy('name')
            ->orderBy('id')
            ->forPage($page, self::PAGE)
            ->get();

        /*
         * ONE STATEMENT FOR EVERY SET IN THIS PAGE OF THE PICKER, OR NONE.
         * (Lane SG) `price_fils` below asks every row what it costs; for a set
         * that is a parts total, and without this it would be fetched one set
         * at a time as the payload is built.
         */
        \App\Support\SetPricing::prime($rows);

        return response()->json([
            'total' => $total,
            'page' => $page,
            'per_page' => self::PAGE,
            'products' => $rows->map(fn (Product $p) => [
                'id' => $p->id,
                'name' => $p->name,
                'sku' => $p->sku,
                'brand' => $p->brand?->name,
                'image' => $p->image,
                // (Lane IM2) This endpoint feeds the shared product picker,
                // whose tile is a 36px square (.kpp-th). The picker already
                // reads `thumb` and falls back to `image`; without this field
                // it would go on drawing the original from THIS endpoint while
                // drawing a copy from the catalogue one, which is the kind of
                // half-fix that looks like a caching bug.
                'thumb' => ImageVariants::variantUrl((string) ($p->image ?? ''), 200),
                // effectivePrice() honours the sale window. The quantity-bundle
                // tier is applied later, by CartService, once a quantity exists.
                'price_fils' => $p->effectivePrice(),
                'stock' => $p->stock,
                'stock_status' => $p->stock_status,
                // (Lane VPA) the parent handed over, so effectivePrice() reads its sale
                // window from memory instead of fetching it once per option.
                'variants' => $p->variants->each(fn ($v) => $v->setRelation('product', $p))->map(fn ($v) => [
                    'id' => $v->id,
                    'sku' => $v->sku,
                    'price_fils' => $v->effectivePrice(),
                    'stock_status' => $v->stock_status,
                    'label' => \App\Support\VariantText::line(\App\Support\VariantText::snapshot($v), ' · '),
                    'image' => $v->image,
                ])->values(),
            ])->values(),
        ]);
    }

    /* ===================================================================
     | POST /admin-api/manual-orders/quote
     |=================================================================== */

    /**
     * Price a basket without saving anything.
     *
     * Fired whenever a line, quantity, destination or coupon changes, so the
     * operator sees the same total the customer will be charged before they
     * commit to it.
     */
    public function quote(Request $request): JsonResponse
    {
        $input = $this->validatedPayload($request, forCreate: false);

        $priced = $this->builder->quote($input);

        if (! $priced['ok']) {
            return response()->json(['ok' => false, 'error' => $priced['error']], 422);
        }

        return response()->json(['ok' => true] + $this->totalsPayload($priced));
    }

    /* ===================================================================
     | POST /admin-api/manual-orders
     |=================================================================== */

    /** Create the order. */
    public function store(Request $request, OrderMailer $mailer): JsonResponse
    {
        $input = $this->validatedPayload($request, forCreate: true);

        $result = $this->builder->create(
            $input,
            $request->user('admin')?->name ?: $request->user('admin')?->email,
        );

        if (! $result['ok']) {
            return response()->json(['ok' => false, 'error' => $result['error']], 422);
        }

        /** @var Order $order */
        $order = $result['order'];

        return response()->json([
            'ok' => true,
            'order' => [
                'id' => $order->id,
                'order_number' => $order->order_number,
                'status' => $order->status,
                'origin' => $order->origin,
                'email' => $order->email,
                'phone' => $order->phone,
                'currency' => $order->currency,
                'subtotal_fils' => (int) $order->subtotal,
                'discount_fils' => (int) $order->discount_total,
                'shipping_fils' => (int) $order->shipping_total,
                'fee_fils' => (int) $order->fee_total,
                'total_fils' => (int) $order->total,
                'coupon_code' => $order->coupon_code,
                'shipping_method' => $order->shipping_method,
                'payment_method' => $order->payment_method,
                'payment_method_title' => $order->payment_method_title,
                'shipping_address' => $order->shipping_address,
                'items' => $order->items->map(fn ($i) => [
                    'name' => $i->name,
                    'sku' => $i->sku,
                    /*
                     * (Lane SE) WHAT WAS IN THE BOX, as one line per member.
                     *
                     * ManualOrderBuilder already writes `set_contents` on a Set
                     * line it creates, so this receipt was the one place an
                     * operator could build a Set order BY HAND and be shown a
                     * single anonymous name back — on the very screen whose job
                     * is to read the order back to them before they act on it.
                     *
                     * The STRINGS and not the raw column, and an empty list for
                     * every ordinary line, exactly as the order-detail payload
                     * a few hundred lines above does it and for the same
                     * reasons: the raw snapshot carries each member's supplier
                     * code and unit price, and the narrower answer is the one to
                     * publish when both will do. It costs no query — it reads
                     * one JSON column already loaded on the row.
                     */
                    'set_contents' => \App\Support\SetContents::lines(\App\Support\SetContents::fromOrderItem($i)),
                    'quantity' => (int) $i->quantity,
                    'unit_price_fils' => (int) $i->unit_price,
                    'line_total_fils' => (int) $i->total,
                ])->values(),
            ],
            // Said plainly rather than left to be discovered.
            'email' => $this->sendConfirmation($order, (bool) ($input['send_confirmation'] ?? false), $mailer),
            'stock' => [
                'adjusted' => false,
                'reason' => 'No order path in this build moves stock — a website '
                    . 'order does not decrement it either. Adjust it in Catalog → Inventory.',
            ],
        ], 201);
    }

    /* ===================================================================
     | Validation
     |=================================================================== */

    /**
     * One validator for quote() and store(), so the two can never disagree
     * about what a valid order is — a quote that prices something the create
     * call then rejects is the worst possible version of this screen.
     */
    private function validatedPayload(Request $request, bool $forCreate): array
    {
        $paymentIds = $this->builder->paymentMethodIds();

        $rules = [
            // Either an existing customer, or enough to make one. The
            // required_without pair is what enforces "one or the other".
            'customer_id' => ['nullable', 'integer', 'required_without:new_customer', 'exists:customers,id'],
            'new_customer' => ['nullable', 'array', 'required_without:customer_id'],
            'new_customer.name' => ['required_with:new_customer', 'string', 'max:120'],
            'new_customer.email' => ['required_with:new_customer', 'email', 'max:160'],
            'new_customer.phone' => ['nullable', 'string', 'max:40'],

            'items' => ['required', 'array', 'min:1', 'max:60'],
            'items.*.product_id' => ['required', 'integer', 'exists:products,id'],
            'items.*.variant_id' => ['nullable', 'integer', 'exists:product_variants,id'],
            // 99 is CartService's own ceiling; asking for more silently becomes
            // 99 there, so it is refused here instead of quietly changed.
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:99'],

            'address' => ['required', 'array'],
            'address.line1' => ['required', 'string', 'max:255'],
            'address.city' => ['required', 'string', 'max:120'],
            // Free text on the live site, not a fixed list — the addresses
            // table does not constrain it either.
            'address.state' => ['required', 'string', 'max:120'],
            'address.country' => ['required', 'string', 'size:2'],
            'address.phone' => ['nullable', 'string', 'max:40'],

            'coupon_code' => ['nullable', 'string', 'max:60'],
            'shipping_method_id' => ['nullable', 'integer'],
            // Typed by the operator in AED. Parsed digit-by-digit below; the
            // rule only checks it is a shape Fils::parse can hold exactly.
            'shipping_override' => ['nullable', 'string', 'max:20', function (string $attribute, $value, $fail) {
                if ($value === null || $value === '') {
                    return;
                }

                if (! Fils::isValid($value)) {
                    $fail('Enter the delivery charge as a plain amount, with at most two decimals.');

                    return;
                }

                /*
                 * WHOLE DIRHAMS — Lane FA. A delivery charge typed by hand
                 * on the manual-order screen, so it is REFUSED rather than
                 * adjusted, like every other money box an operator fills in.
                 *
                 * NO STORED-VALUE EXEMPTION HERE, and the asymmetry with the
                 * line-price rule above is deliberate rather than an
                 * oversight. This box is blank unless the operator chooses to
                 * override the calculated rate: there is no previous value
                 * being posted back, so a value in it is always one somebody
                 * has just typed. Exempting "unchanged" would mean exempting
                 * a figure that was typed this minute.
                 */
                $fils = (int) Fils::parse((string) $value);

                if (! WholeDirhams::isWhole($fils)) {
                    $fail(WholeDirhams::message('Delivery charge', $fils));
                }
            }],

            // payment_providers.id is the vocabulary. Nothing invented.
            'payment_method' => ['required', 'string', Rule::in($paymentIds)],
            'channel' => ['nullable', 'string', Rule::in(ManualOrderBuilder::CHANNELS)],
            'customer_note' => ['nullable', 'string', 'max:2000'],
            'whatsapp_optin' => ['nullable', 'boolean'],
            'send_confirmation' => ['nullable', 'boolean'],
        ];

        if ($forCreate) {
            // orders.status is a free-form string so imported WooCommerce
            // statuses survive; the console's working vocabulary is these
            // seven, and AdminController::updateOrderStatus accepts exactly
            // the same set. An order created with anything else would be one
            // the Orders screen could never edit again.
            $rules['status'] = ['required', 'string', Rule::in(ManualOrderBuilder::STATUSES)];
        } else {
            $rules['status'] = ['nullable', 'string', Rule::in(ManualOrderBuilder::STATUSES)];
        }

        $data = $request->validate($rules);

        // The one operator-typed money field in this screen. Fils::parse reads
        // the string one character at a time and never multiplies by 100 —
        // (int) (1.15 * 100) is 114, and a one-fil error on a delivery charge
        // is exactly the kind nobody spots until it is on an invoice.
        $override = $data['shipping_override'] ?? null;
        $data['shipping_override_fils'] = ($override === null || $override === '')
            ? null
            : Fils::parse((string) $override);

        unset($data['shipping_override']);

        return $data;
    }

    /* ===================================================================
     | Helpers
     |=================================================================== */

    /**
     * Escape the LIKE wildcards in an operator's search term.
     *
     * The escape character itself has to go first, or "!%" would become "!!%"
     * the wrong way round and stop escaping anything.
     */
    private function escapeLike(string $term): string
    {
        return str_replace(
            [self::LIKE_ESCAPE, '%', '_'],
            [self::LIKE_ESCAPE . self::LIKE_ESCAPE, self::LIKE_ESCAPE . '%', self::LIKE_ESCAPE . '_'],
            $term,
        );
    }

    /** The shape the screen renders totals from. All amounts are fils. */
    private function totalsPayload(array $priced): array
    {
        $totals = $priced['totals'];

        return [
            'lines' => $priced['lines'],
            'rates' => $priced['rates'],
            'chosen_rate_id' => $priced['chosen_rate']['id'] ?? null,
            'totals' => [
                'subtotal_fils' => (int) $totals['subtotal'],
                'discount_fils' => (int) $totals['discount'],
                'shipping_fils' => (int) $totals['shipping'],
                'fee_fils' => (int) $priced['fee'],
                'total_fils' => (int) $priced['grand_total'],
                'coupon_code' => $totals['coupon_code'],
                'item_count' => (int) $totals['item_count'],
                'free_shipping_threshold_fils' => $totals['free_shipping_threshold'],
                'free_shipping_remaining_fils' => $totals['free_shipping_remaining'],
                // Display only — never added to the total (D-64).
                'vat' => $totals['vat'],
            ],
        ];
    }

    /**
     * Whether a confirmation email can be sent at all.
     *
     * There is a real one now: App\Mail\OrderConfirmation, sent through
     * App\Services\Mail\OrderMailer, which is also what the storefront
     * checkout fires on placement. The owner can switch it off in
     * Store -> Modules -> Order emails, and this reports that rather than
     * offering a checkbox that would be quietly overruled.
     */
    private function confirmationEmailCapability(OrderMailer $mailer): array
    {
        if (! $mailer->confirmationEnabled()) {
            return [
                'available' => false,
                'reason' => 'Order confirmation emails are switched off in '
                    . 'Store → Modules → Order emails, so nothing would be sent.',
            ];
        }

        return ['available' => true, 'reason' => null];
    }

    /**
     * Send the confirmation, or say why not.
     *
     * resendConfirmation() rather than placed(): placed() also fires the
     * merchant alert, and a "new order" landing in the owner's inbox for an
     * order the owner just keyed in by hand is a lie about what happened. It is
     * also the only method on OrderMailer that REPORTS rather than swallowing
     * the outcome, which is what an operator who ticked a box is owed.
     */
    private function sendConfirmation(Order $order, bool $requested, OrderMailer $mailer): array
    {
        if (! $requested) {
            return [
                'requested' => false,
                'sent' => false,
                'reason' => 'Not requested — the operator left the box unticked.',
            ];
        }

        $result = $mailer->resendConfirmation($order);

        return [
            'requested' => true,
            'sent' => (bool) $result['ok'],
            'reason' => (string) $result['message'],
        ];
    }

    /** The customer's saved address, for prefilling the form. */
    private function addressOf(Customer $customer): ?array
    {
        $address = $customer->defaultAddress('shipping') ?? $customer->defaultAddress('billing');

        if (! $address) {
            return null;
        }

        return [
            'line1' => $address->line1,
            'city' => $address->city,
            'state' => $address->state,
            'country' => $address->country,
            'phone' => $address->phone,
        ];
    }
}
