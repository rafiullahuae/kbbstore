<?php

declare(strict_types=1);

namespace App\Services\Update;

use App\Models\UpdateRelease;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Applies a verified package, and undoes it if anything goes wrong.
 *
 * The design principle is that the site must be running at every moment. There
 * are three layers of protection:
 *
 *   1. Nothing is written until the package has fully passed verification.
 *   2. Every file about to be replaced is backed up first. If the backup itself
 *      fails, the update stops before changing anything.
 *   3. After the files land, the site is asked whether it still works. If it
 *      does not answer correctly, everything is rolled back automatically.
 *
 * A fatal error in newly installed code is the case that worries people most, so
 * it is handled specifically: a shutdown handler catches it and rolls back even
 * though normal execution has stopped.
 */
final class UpdateRunner
{
    private ?string $activeBackupId = null;

    private bool $completed = false;

    public function __construct(
        private BackupService $backups,
        private string $appRoot,
    ) {}

    public function apply(UpdatePackage $package, int $adminId): UpdateRelease
    {
        $release = UpdateRelease::create([
            'name' => (string) ($package->manifest['name'] ?? 'Update'),
            'version' => $package->version(),
            'status' => 'running',
            'notes' => $package->notes(),
            'applied_by' => $adminId,
            'file_count' => count($package->files),
        ]);

        // If PHP dies inside this request — a parse error in a new file, a memory
        // limit, a timeout — this still runs.
        register_shutdown_function(function () use ($release) {
            if ($this->completed) {
                return;
            }

            $error = error_get_last();

            if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
                $this->emergencyRollback($release, 'Fatal error during update: ' . $error['message']);
            }
        });

        try {
            $paths = array_keys($package->files);

            // 1. Maintenance mode, so nobody sees a half-applied site.
            $this->down();

            // 2. Back up before touching anything.
            $snapshot = $this->backups->snapshotFiles($paths);
            $this->activeBackupId = $snapshot['id'];
            $release->update(['backup_id' => $snapshot['id']]);

            // 3. Database dump, only when migrations will run. Migrations are the
            //    one part that cannot be undone by copying files back.
            if ($package->hasMigrations()) {
                $this->backups->dumpDatabase($snapshot['path']);
            }

            // 4. Copy the files.
            $this->copyFiles($package);

            // 5. Clear compiled caches so the new code is actually used.
            $this->clearCaches();

            // 6. Migrations.
            if ($package->hasMigrations()) {
                Artisan::call('migrate', ['--force' => true]);
                $release->update(['migration_output' => Artisan::output()]);
            }

            // 7. Ask the site whether it still works.
            $health = $this->healthCheck();

            if (! $health['ok']) {
                $this->rollback($release, 'Health check failed after update: ' . $health['reason']);

                return $release->fresh();
            }

            $this->up();

            $release->update(['status' => 'applied', 'completed_at' => now()]);
            $this->completed = true;

            $this->backups->prune(5);

            return $release->fresh();
        } catch (\Throwable $e) {
            $this->rollback($release, $e->getMessage());

            return $release->fresh();
        }
    }

    private function copyFiles(UpdatePackage $package): void
    {
        foreach ($package->files as $relative => $source) {
            $target = $this->appRoot . '/' . $relative;

            if (! is_dir(dirname($target)) && ! mkdir(dirname($target), 0755, true) && ! is_dir(dirname($target))) {
                throw new \RuntimeException("Could not create directory for {$relative}.");
            }

            if (! copy($source, $target)) {
                throw new \RuntimeException("Could not write {$relative}. Check file permissions.");
            }
        }
    }

    /**
     * Requests the health endpoint over HTTP.
     *
     * This is deliberately a real request rather than an internal call: it boots
     * the application from scratch in a separate process, which is the only way
     * to find out whether the newly written files actually parse and run.
     */
    private function healthCheck(): array
    {
        $token = (string) config('kbb.health_token', '');
        $url = rtrim((string) config('app.url'), '/') . '/_kbb-health';

        if ($token === '') {
            return ['ok' => true, 'reason' => 'skipped: no health token configured'];
        }

        try {
            $response = Http::timeout(20)->get($url, ['token' => $token]);

            if (! $response->successful()) {
                return ['ok' => false, 'reason' => 'HTTP ' . $response->status()];
            }

            return ($response->json('ok') === true)
                ? ['ok' => true, 'reason' => 'ok']
                : ['ok' => false, 'reason' => 'unexpected response body'];
        } catch (\Throwable $e) {
            return ['ok' => false, 'reason' => $e->getMessage()];
        }
    }

    private function rollback(UpdateRelease $release, string $reason): void
    {
        Log::error('KBB update rolled back', ['release' => $release->id, 'reason' => $reason]);

        try {
            if ($this->activeBackupId) {
                $this->backups->restoreFiles($this->activeBackupId);
                $this->clearCaches();
            }

            $release->update([
                'status' => 'rolled_back',
                'error' => $reason,
                'completed_at' => now(),
            ]);
        } catch (\Throwable $e) {
            // Restoring failed too. Say so loudly and point at the standalone
            // recovery script, which does not need Laravel to boot.
            $release->update([
                'status' => 'failed',
                'error' => $reason . ' — AND the automatic rollback failed: ' . $e->getMessage()
                    . ' Use public/kbb-recover.php to restore manually.',
                'completed_at' => now(),
            ]);
        } finally {
            $this->completed = true;
            $this->up();
        }
    }

    /** Called from the shutdown handler, where exceptions cannot be thrown. */
    private function emergencyRollback(UpdateRelease $release, string $reason): void
    {
        try {
            if ($this->activeBackupId) {
                $this->backups->restoreFiles($this->activeBackupId);
            }

            @unlink($this->appRoot . '/storage/framework/down');

            $release->update(['status' => 'rolled_back', 'error' => $reason, 'completed_at' => now()]);
        } catch (\Throwable) {
            // Nothing further can be done from inside a dying request. The
            // recovery script exists for exactly this case.
        }
    }

    private function clearCaches(): void
    {
        foreach (['config:clear', 'route:clear', 'view:clear', 'cache:clear'] as $command) {
            try {
                Artisan::call($command);
            } catch (\Throwable) {
                // A cache that will not clear must not stop an update.
            }
        }

        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
    }

    private function down(): void
    {
        try {
            Artisan::call('down', ['--render' => 'errors::503', '--retry' => 60]);
        } catch (\Throwable) {
            @file_put_contents($this->appRoot . '/storage/framework/down', json_encode(['retry' => 60]));
        }
    }

    private function up(): void
    {
        try {
            Artisan::call('up');
        } catch (\Throwable) {
            @unlink($this->appRoot . '/storage/framework/down');
        }
    }
}
